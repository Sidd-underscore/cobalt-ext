// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"1dmY8":[function(require,module,exports) {
var _logger = require("../common/logger");
var _utils = require("../common/utils");
(0, _logger.logger).log("YouTube detected!");
const downloadIcon = (classNames)=>{
    // Use the meta theme color to determine if the user is using dark mode
    var isDarkMode = document.head.querySelector('meta[name="theme-color"]').getAttribute("content") != "rgba(255, 255, 255, 0.98)";
    return `
    <svg viewBox="0 0 48 48" class="${classNames}">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M38 44H10V42H38V44Z" fill="${isDarkMode ? "white" : "black"}" fill-rule="evenodd" clip-rule="evenodd"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M23 34.5V4.5H25V34.5H23Z" fill="${isDarkMode ? "white" : "black"}" fill-rule="evenodd" clip-rule="evenodd"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M24 35.4142L10.5858 22L12 20.5858L24 32.5858L36 20.5858L37.4142 22L24 35.4142Z" fill="${isDarkMode ? "white" : "black"}" fill-rule="evenodd" clip-rule="evenodd"></path>
    </svg>
    `;
};
function addDownloadButton() {
    const isLiveVideo = document.querySelector('[should-stamp-chat=""]');
    const isShortsVideo = window.location.href.includes("/shorts/");
    if (!isLiveVideo) {
        if (!isShortsVideo) {
            var toolBar = document.querySelector("ytd-watch-flexy #top-level-buttons-computed");
            if (toolBar) {
                // Get a template, normal button (usually the share button) and the we clone it and modify it to our liking
                const templateButton = toolBar.querySelector('yt-button-view-model button-view-model button[aria-label="Share"]').parentElement.parentElement;
                if (!templateButton.parentElement.querySelector('[cobalt-ext="youtube"]')) {
                    const downloadButton = templateButton.cloneNode(true);
                    console.log(downloadButton);
                    const downloadButtonInner = downloadButton.querySelector("button");
                    toolBar.insertAdjacentElement("beforeend", downloadButton);
                    downloadButton.setAttribute("cobalt-ext", "youtube");
                    downloadButton.querySelector("yt-icon").parentElement.innerHTML = downloadIcon(downloadButton.querySelector("yt-icon").classList.toString());
                    downloadButtonInner.title = "download with cobalt";
                    downloadButtonInner.setAttribute("aria-label", "download with cobalt");
                    downloadButton.querySelector(".yt-spec-button-shape-next__button-text-content").textContent = "Download";
                    const styles = document.createElement("style");
                    styles.innerHTML = `
            @media screen and (max-width: 1448px) {
              [cobalt-ext="youtube"] .yt-spec-button-shape-next__button-text-content {
                  display: none;
              }

              [cobalt-ext="youtube"] .yt-spec-button-shape-next__icon {
                  margin: -6px !important;
              }
            }`;
                    document.head.appendChild(styles);
                    toolBar.insertAdjacentElement("beforeend", downloadButton);
                    // Let YouTube compute the overflow menu
                    document.dispatchEvent(new Event("yt-rendererstamper-finished"));
                    document.dispatchEvent(new Event("yt-renderidom-finished"));
                    document.dispatchEvent(new Event("yt-masthead-height-changed"));
                    downloadButton.addEventListener("click", (e)=>{
                        (0, _utils.getResource)(window.location.href);
                    });
                }
            }
        } else {
            const toolBars = document.querySelectorAll(".action-container");
            if (toolBars) toolBars.forEach((toolBar)=>{
                if (!toolBar.querySelector('[cobalt-ext="youtube"]')) {
                    // Get a template, normal button (the share button)
                    const template = toolBar.querySelectorAll("div.button-container")[2];
                    // Apply all necessary styles and accessibility features to the button wrapper
                    const downloadButton = document.createElement("div"); // cloneNode() doesn't work in the scenario because of YouTube rendering system. I hate it here too.
                    downloadButton.classList.add(...template.classList);
                    downloadButton.setAttribute("cobalt-ext", "youtube");
                    downloadButton.title = "Download short with cobalt";
                    downloadButton.style.paddingTop = "16px";
                    // Create the elements that reside inside the button but don't have any specific properties we need to change
                    const downloadButtonInner = document.createElement("ytd-cobalt-button-renderer");
                    downloadButtonInner.classList.add(...document.querySelector("#share-button ytd-button-renderer").classList);
                    downloadButtonInner.setAttribute("vertically-aligned", "");
                    const buttonShape = document.createElement("yt-cobalt-button-shape");
                    const buttonLabel = document.createElement("label");
                    buttonLabel.classList.add(...template.querySelector("yt-button-shape > label").classList);
                    // This is the actual button inside of the button wrapper
                    const buttonLabelInner = document.createElement("button");
                    buttonLabelInner.classList.add(...template.querySelector("yt-button-shape > label > button").classList);
                    buttonLabelInner.setAttribute("aria-label", "Download video with cobalt");
                    buttonLabelInner.setAttribute("type", "button");
                    buttonLabelInner.title = "Download video with cobalt";
                    // Feedback shape is responsible for some niche mobile/touch UI response
                    const buttonFeedbackShape = document.createElement("yt-touch-feedback-shape");
                    buttonFeedbackShape.style.borderRadius = "inherit";
                    const buttonFeedbackShapeInner = document.createElement("div");
                    buttonFeedbackShapeInner.classList.add(...template.querySelector("yt-button-shape label yt-touch-feedback-shape div").classList);
                    buttonFeedbackShapeInner.setAttribute("aria-hidden", true);
                    const buttonFeedbackShapeInnerInner1 = document.createElement("div");
                    buttonFeedbackShapeInnerInner1.classList.add(...template.querySelectorAll("yt-button-shape label yt-touch-feedback-shape div div")[0].classList);
                    const buttonFeedbackShapeInnerInner2 = document.createElement("div");
                    buttonFeedbackShapeInnerInner2.classList.add(...template.querySelectorAll("yt-button-shape label yt-touch-feedback-shape div div")[1].classList);
                    // Put the feedback shape together
                    buttonFeedbackShapeInnerInner1.insertAdjacentElement("afterend", buttonFeedbackShapeInnerInner2);
                    buttonFeedbackShapeInner.appendChild(buttonFeedbackShapeInnerInner1);
                    buttonFeedbackShape.appendChild(buttonFeedbackShapeInner);
                    buttonLabelInner.appendChild(buttonFeedbackShape);
                    // Create the download icon
                    const buttonLabelIconOuter = document.createElement("div");
                    buttonLabelIconOuter.classList.add(...template.querySelector("yt-button-shape > label > button > div").classList, "yt-cobalt-button-icon");
                    buttonLabelIconOuter.setAttribute("aria-hidden", true);
                    const buttonLabelIconInner = document.createElement("yt-cobalt-icon");
                    buttonLabelIconInner.classList.add(...template.querySelector("yt-button-shape > label > button > div > yt-icon").classList);
                    buttonLabelIconInner.classList.add("yt-icon", "yt-icon-shape", "yt-spec-icon-shape");
                    buttonLabelIconInner.style.width = "24px";
                    buttonLabelIconInner.style.height = "24px";
                    buttonLabelIconInner.style.display = "block";
                    buttonLabelIconInner.innerHTML = downloadIcon(buttonLabelIconInner.classList.toString());
                    const buttonIconLabelOuter = document.createElement("div");
                    buttonIconLabelOuter.classList.add(...template.querySelector("yt-button-shape > label > div").classList);
                    buttonIconLabelOuter.setAttribute("aria-hidden", true);
                    const buttonIconLabelInner = document.createElement("span");
                    buttonIconLabelInner.classList.add(...template.querySelector("yt-button-shape > label > div > span").classList);
                    buttonIconLabelInner.setAttribute("role", "text");
                    buttonIconLabelInner.innerText = "Save"; // "Save" instead of "Download" because "Download" is too long lol
                    // Put everything together (I hate this so much)
                    buttonIconLabelOuter.appendChild(buttonIconLabelInner);
                    buttonLabelIconOuter.appendChild(buttonLabelIconInner);
                    buttonLabelInner.appendChild(buttonLabelIconOuter);
                    buttonLabel.appendChild(buttonLabelInner);
                    buttonLabel.appendChild(buttonIconLabelOuter);
                    buttonShape.appendChild(buttonLabel);
                    downloadButtonInner.appendChild(buttonShape);
                    downloadButton.appendChild(downloadButtonInner);
                    downloadButton.addEventListener("click", (e)=>{
                        (0, _utils.getResource)(window.location.href);
                    });
                    toolBar?.querySelector("#share-button").insertAdjacentElement("afterend", downloadButton);
                    // YouTube slightly changes the look of the action buttons (like, comment, etc) when the description and comment section panels are expanded
                    // Both of these event listeners run in parallel to ensure that the correct button styles are applied even when simply toggling between the panels
                    // Reverse-engineering YouTue's code is a pain, but this is the best I could come up with
                    document.addEventListener("yt-action", (e)=>{
                        if (e.detail && e.detail.args && e?.detail?.args[1] === "ENGAGEMENT_PANEL_VISIBILITY_EXPANDED" && (e?.detail?.args[2] === "engagement-panel-comments-section" || e?.detail?.args[2] === "engagement-panel-structured-description")) {
                            (0, _logger.logger).log("engagement panel shown", e);
                            buttonLabelInner.classList.add("yt-spec-button-shape-next--overlay-dark");
                            downloadButton.style.paddingTop = "0px";
                        }
                    });
                    document.addEventListener("yt-action", (e)=>{
                        if (e.detail && e.detail.args && e?.detail?.args[1] === "ENGAGEMENT_PANEL_VISIBILITY_HIDDEN" && (e?.detail?.args[2] === "engagement-panel-comments-section" || e?.detail?.args[2] === "engagement-panel-structured-description")) {
                            (0, _logger.logger).log("engagement panel hidden", e);
                            buttonLabelInner.classList.remove("yt-spec-button-shape-next--overlay-dark");
                            downloadButton.style.paddingTop = "16px";
                        }
                    });
                }
            });
        }
    }
}
(0, _utils.watchPage)(addDownloadButton);

},{"../common/logger":"73tk1","../common/utils":"39Pbd"}],"73tk1":[function(require,module,exports) {
// This is a modified version of the "echo" logger concept from https://www.bennadel.com/blog/3941-styling-console-log-output-formatting-with-css.htm
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "logger", ()=>logger);
var _utilsJs = require("./utils.js");
const logger = function() {
    var queue = [];
    var logger_TOKEN = {};
    var RESET_INPUT = "%c ";
    var RESET_CSS = "";
    function alertFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: #e0005a ; color: #ffffff ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function warningFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: gold ; color: black ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function titleFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: black ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    // I provide an logger-based proxy to the given Console Function. This uses an
    // internal queue to aggregate values before calling the given Console
    // Function with the desired formatting.
    function using(consoleFunction) {
        function consoleFunctionProxy() {
            // As we loop over the arguments, we're going to aggregate a set of
            // inputs and modifiers. The Inputs will ultimately be collapsed down
            // into a single string that acts as the first console.log parameter
            // while the modifiers are then SPREAD into console.log as 2...N.
            // --
            // NOTE: After each input/modifier pair, I'm adding a RESET pairing.
            // This implicitly resets the CSS after every formatted pairing.
            var inputs = [];
            var modifiers = [];
            // Add the cobalt-ext header
            inputs.push("%ccobalt-ext@" + (0, _utilsJs.version), RESET_INPUT);
            modifiers.push("display: inline-block; background-color: black; color: white; font-weight: bold; padding: 3px 7px; border-radius: 3px;", RESET_CSS);
            for(var i = 0; i < arguments.length; i++)// When the formatting utility methods are called, they return
            // a special token. This indicates that we should pull the
            // corresponding value out of the QUEUE instead of trying to
            // output the given argument directly.
            if (arguments[i] === logger_TOKEN) {
                var item = queue.shift();
                inputs.push("%c" + item.value, RESET_INPUT);
                modifiers.push(item.css, RESET_CSS);
            // For every other argument type, output the value directly.
            } else {
                var arg = arguments[i];
                if (typeof arg === "object" || typeof arg === "function") {
                    inputs.push("%o", RESET_INPUT);
                    modifiers.push(arg, RESET_CSS);
                } else {
                    inputs.push("%c" + arg, RESET_INPUT);
                    modifiers.push(RESET_CSS, RESET_CSS);
                }
            }
            consoleFunction(inputs.join(""), ...modifiers);
            // Once we output the aggregated value, reset the queue. This should have
            // already been emptied by the .shift() calls; but the explicit reset
            // here acts as both a marker of intention as well as a fail-safe.
            queue = [];
        }
        return consoleFunctionProxy;
    }
    return {
        log: using(console.log),
        warn: using(console.warn),
        error: using(console.error),
        trace: using(console.trace),
        asAlert: alertFormatting,
        asWarning: warningFormatting,
        asTitle: titleFormatting
    };
}();

},{"@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS","./utils.js":"39Pbd"}],"aNjyS":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"39Pbd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "version", ()=>version);
parcelHelpers.export(exports, "getResource", ()=>getResource);
parcelHelpers.export(exports, "watchPage", ()=>watchPage);
var _logger = require("./logger");
const version = "1.0.0";
async function getResource(url) {
    (0, _logger.logger).log("redirecting to cobalt website for " + url + "...");
    return new Promise((resolve, reject)=>{
        window.open("https://cobalt.tools/#" + url, "_blank");
        resolve(true);
    });
}
function watchPage(callback) {
    let scheduled = false;
    const observerCallback = ()=>{
        if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(()=>{
                callback();
                scheduled = false;
            });
        }
    };
    const observer = new MutationObserver((mutationsList)=>{
        for (const mutation of mutationsList)if (mutation.type === "childList") {
            observerCallback();
            break;
        }
    });
    observer.observe(document, {
        childList: true,
        subtree: true
    });
}

},{"./logger":"73tk1","@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS"}]},["1dmY8"], "1dmY8", "parcelRequirea3c5")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQSxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDO0FBRVgsTUFBTSxlQUFlLENBQUM7SUFDcEIsdUVBQXVFO0lBQ3ZFLElBQUksYUFDRixTQUFTLElBQUksQ0FDVixhQUFhLENBQUMsNEJBQ2QsWUFBWSxDQUFDLGNBQWM7SUFFaEMsT0FBTyxDQUFDO29DQUMwQixFQUFFLFdBQVc7b0ZBQ21DLEVBQzFFLGFBQWEsVUFBVSxRQUN4Qjt5RkFDZ0YsRUFDL0UsYUFBYSxVQUFVLFFBQ3hCOytJQUNzSSxFQUNySSxhQUFhLFVBQVUsUUFDeEI7O0lBRUwsQ0FBQztBQUNMO0FBRUEsU0FBUztJQUNQLE1BQU0sY0FBYyxTQUFTLGFBQWEsQ0FBQztJQUMzQyxNQUFNLGdCQUFnQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBRXBELElBQUksQ0FBQztRQUNILElBQUksQ0FBQyxlQUFlO1lBQ2xCLElBQUksVUFBVSxTQUFTLGFBQWEsQ0FDbEM7WUFFRixJQUFJLFNBQVM7Z0JBQ1gsMkdBQTJHO2dCQUMzRyxNQUFNLGlCQUFpQixRQUFRLGFBQWEsQ0FDMUMscUVBQ0EsYUFBYSxDQUFDLGFBQWE7Z0JBRTdCLElBQ0UsQ0FBQyxlQUFlLGFBQWEsQ0FBQyxhQUFhLENBQUMsMkJBQzVDO29CQUNBLE1BQU0saUJBQWlCLGVBQWUsU0FBUyxDQUFDO29CQUNoRCxRQUFRLEdBQUcsQ0FBQztvQkFDWixNQUFNLHNCQUFzQixlQUFlLGFBQWEsQ0FBQztvQkFDekQsUUFBUSxxQkFBcUIsQ0FBQyxhQUFhO29CQUUzQyxlQUFlLFlBQVksQ0FBQyxjQUFjO29CQUMxQyxlQUFlLGFBQWEsQ0FBQyxXQUFXLGFBQWEsQ0FBQyxTQUFTLEdBQzdELGFBQ0UsZUFBZSxhQUFhLENBQUMsV0FBVyxTQUFTLENBQUMsUUFBUTtvQkFHOUQsb0JBQW9CLEtBQUssR0FBRztvQkFDNUIsb0JBQW9CLFlBQVksQ0FDOUIsY0FDQTtvQkFHRixlQUFlLGFBQWEsQ0FDMUIsbURBQ0EsV0FBVyxHQUFHO29CQUVoQixNQUFNLFNBQVMsU0FBUyxhQUFhLENBQUM7b0JBQ3RDLE9BQU8sU0FBUyxHQUFHLENBQUM7Ozs7Ozs7OzthQVNqQixDQUFDO29CQUVKLFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFFMUIsUUFBUSxxQkFBcUIsQ0FBQyxhQUFhO29CQUUzQyx3Q0FBd0M7b0JBQ3hDLFNBQVMsYUFBYSxDQUFDLElBQUksTUFBTTtvQkFDakMsU0FBUyxhQUFhLENBQUMsSUFBSSxNQUFNO29CQUNqQyxTQUFTLGFBQWEsQ0FBQyxJQUFJLE1BQU07b0JBRWpDLGVBQWUsZ0JBQWdCLENBQUMsU0FBUyxDQUFDO3dCQUN4QyxDQUFBLEdBQUEsa0JBQVcsQUFBRCxFQUFFLE9BQU8sUUFBUSxDQUFDLElBQUk7b0JBQ2xDO2dCQUNGO1lBQ0Y7UUFDRixPQUFPO1lBQ0wsTUFBTSxXQUFXLFNBQVMsZ0JBQWdCLENBQUM7WUFDM0MsSUFBSSxVQUNGLFNBQVMsT0FBTyxDQUFDLENBQUM7Z0JBQ2hCLElBQUksQ0FBQyxRQUFRLGFBQWEsQ0FBQywyQkFBMkI7b0JBQ3BELG1EQUFtRDtvQkFDbkQsTUFBTSxXQUFXLFFBQVEsZ0JBQWdCLENBQ3ZDLHVCQUNELENBQUMsRUFBRTtvQkFFSiw4RUFBOEU7b0JBQzlFLE1BQU0saUJBQWlCLFNBQVMsYUFBYSxDQUFDLFFBQVEsb0dBQW9HO29CQUMxSixlQUFlLFNBQVMsQ0FBQyxHQUFHLElBQUksU0FBUyxTQUFTO29CQUNsRCxlQUFlLFlBQVksQ0FBQyxjQUFjO29CQUMxQyxlQUFlLEtBQUssR0FBRztvQkFDdkIsZUFBZSxLQUFLLENBQUMsVUFBVSxHQUFHO29CQUVsQyw2R0FBNkc7b0JBQzdHLE1BQU0sc0JBQXNCLFNBQVMsYUFBYSxDQUNoRDtvQkFFRixvQkFBb0IsU0FBUyxDQUFDLEdBQUcsSUFDNUIsU0FBUyxhQUFhLENBQUMscUNBQ3ZCLFNBQVM7b0JBRWQsb0JBQW9CLFlBQVksQ0FBQyxzQkFBc0I7b0JBQ3ZELE1BQU0sY0FBYyxTQUFTLGFBQWEsQ0FDeEM7b0JBR0YsTUFBTSxjQUFjLFNBQVMsYUFBYSxDQUFDO29CQUMzQyxZQUFZLFNBQVMsQ0FBQyxHQUFHLElBQ3BCLFNBQVMsYUFBYSxDQUFDLDJCQUEyQixTQUFTO29CQUdoRSx5REFBeUQ7b0JBQ3pELE1BQU0sbUJBQW1CLFNBQVMsYUFBYSxDQUFDO29CQUNoRCxpQkFBaUIsU0FBUyxDQUFDLEdBQUcsSUFDekIsU0FBUyxhQUFhLENBQUMsb0NBQ3ZCLFNBQVM7b0JBRWQsaUJBQWlCLFlBQVksQ0FDM0IsY0FDQTtvQkFFRixpQkFBaUIsWUFBWSxDQUFDLFFBQVE7b0JBQ3RDLGlCQUFpQixLQUFLLEdBQUc7b0JBRXpCLHdFQUF3RTtvQkFDeEUsTUFBTSxzQkFBc0IsU0FBUyxhQUFhLENBQ2hEO29CQUVGLG9CQUFvQixLQUFLLENBQUMsWUFBWSxHQUFHO29CQUV6QyxNQUFNLDJCQUEyQixTQUFTLGFBQWEsQ0FBQztvQkFDeEQseUJBQXlCLFNBQVMsQ0FBQyxHQUFHLElBQ2pDLFNBQVMsYUFBYSxDQUN2QixxREFDQSxTQUFTO29CQUViLHlCQUF5QixZQUFZLENBQUMsZUFBZTtvQkFFckQsTUFBTSxpQ0FDSixTQUFTLGFBQWEsQ0FBQztvQkFDekIsK0JBQStCLFNBQVMsQ0FBQyxHQUFHLElBQ3ZDLFNBQVMsZ0JBQWdCLENBQzFCLHdEQUNELENBQUMsRUFBRSxDQUFDLFNBQVM7b0JBR2hCLE1BQU0saUNBQ0osU0FBUyxhQUFhLENBQUM7b0JBQ3pCLCtCQUErQixTQUFTLENBQUMsR0FBRyxJQUN2QyxTQUFTLGdCQUFnQixDQUMxQix3REFDRCxDQUFDLEVBQUUsQ0FBQyxTQUFTO29CQUdoQixrQ0FBa0M7b0JBQ2xDLCtCQUErQixxQkFBcUIsQ0FDbEQsWUFDQTtvQkFFRix5QkFBeUIsV0FBVyxDQUNsQztvQkFFRixvQkFBb0IsV0FBVyxDQUFDO29CQUNoQyxpQkFBaUIsV0FBVyxDQUFDO29CQUU3QiwyQkFBMkI7b0JBQzNCLE1BQU0sdUJBQXVCLFNBQVMsYUFBYSxDQUFDO29CQUNwRCxxQkFBcUIsU0FBUyxDQUFDLEdBQUcsSUFDN0IsU0FBUyxhQUFhLENBQ3ZCLDBDQUNBLFNBQVMsRUFDWDtvQkFFRixxQkFBcUIsWUFBWSxDQUFDLGVBQWU7b0JBRWpELE1BQU0sdUJBQ0osU0FBUyxhQUFhLENBQUM7b0JBQ3pCLHFCQUFxQixTQUFTLENBQUMsR0FBRyxJQUM3QixTQUFTLGFBQWEsQ0FDdkIsb0RBQ0EsU0FBUztvQkFFYixxQkFBcUIsU0FBUyxDQUFDLEdBQUcsQ0FDaEMsV0FDQSxpQkFDQTtvQkFFRixxQkFBcUIsS0FBSyxDQUFDLEtBQUssR0FBRztvQkFDbkMscUJBQXFCLEtBQUssQ0FBQyxNQUFNLEdBQUc7b0JBQ3BDLHFCQUFxQixLQUFLLENBQUMsT0FBTyxHQUFHO29CQUNyQyxxQkFBcUIsU0FBUyxHQUFHLGFBQy9CLHFCQUFxQixTQUFTLENBQUMsUUFBUTtvQkFHekMsTUFBTSx1QkFBdUIsU0FBUyxhQUFhLENBQUM7b0JBQ3BELHFCQUFxQixTQUFTLENBQUMsR0FBRyxJQUM3QixTQUFTLGFBQWEsQ0FBQyxpQ0FDdkIsU0FBUztvQkFHZCxxQkFBcUIsWUFBWSxDQUFDLGVBQWU7b0JBRWpELE1BQU0sdUJBQXVCLFNBQVMsYUFBYSxDQUFDO29CQUNwRCxxQkFBcUIsU0FBUyxDQUFDLEdBQUcsSUFDN0IsU0FBUyxhQUFhLENBQUMsd0NBQ3ZCLFNBQVM7b0JBR2QscUJBQXFCLFlBQVksQ0FBQyxRQUFRO29CQUMxQyxxQkFBcUIsU0FBUyxHQUFHLFFBQVEsa0VBQWtFO29CQUUzRyxnREFBZ0Q7b0JBQ2hELHFCQUFxQixXQUFXLENBQUM7b0JBQ2pDLHFCQUFxQixXQUFXLENBQUM7b0JBQ2pDLGlCQUFpQixXQUFXLENBQUM7b0JBQzdCLFlBQVksV0FBVyxDQUFDO29CQUN4QixZQUFZLFdBQVcsQ0FBQztvQkFDeEIsWUFBWSxXQUFXLENBQUM7b0JBQ3hCLG9CQUFvQixXQUFXLENBQUM7b0JBQ2hDLGVBQWUsV0FBVyxDQUFDO29CQUUzQixlQUFlLGdCQUFnQixDQUFDLFNBQVMsQ0FBQzt3QkFDeEMsQ0FBQSxHQUFBLGtCQUFXLEFBQUQsRUFBRSxPQUFPLFFBQVEsQ0FBQyxJQUFJO29CQUNsQztvQkFFQSxTQUNJLGNBQWMsaUJBQ2Ysc0JBQXNCLFlBQVk7b0JBRXJDLDRJQUE0STtvQkFDNUksa0pBQWtKO29CQUNsSix5RkFBeUY7b0JBQ3pGLFNBQVMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO3dCQUN0QyxJQUNFLEVBQUUsTUFBTSxJQUNSLEVBQUUsTUFBTSxDQUFDLElBQUksSUFDYixHQUFHLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FBSywwQ0FDdEIsQ0FBQSxHQUFHLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FBSyx1Q0FDdEIsR0FBRyxRQUFRLElBQUksQ0FBQyxFQUFFLEtBQ2hCLHlDQUF3QyxHQUM1Qzs0QkFDQSxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDLDBCQUEwQjs0QkFDckMsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHLENBQzVCOzRCQUVGLGVBQWUsS0FBSyxDQUFDLFVBQVUsR0FBRzt3QkFDcEM7b0JBQ0Y7b0JBQ0EsU0FBUyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUM7d0JBQ3RDLElBQ0UsRUFBRSxNQUFNLElBQ1IsRUFBRSxNQUFNLENBQUMsSUFBSSxJQUNiLEdBQUcsUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLHdDQUN0QixDQUFBLEdBQUcsUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLHVDQUN0QixHQUFHLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FDaEIseUNBQXdDLEdBQzVDOzRCQUNBLENBQUEsR0FBQSxjQUFNLEFBQUQsRUFBRSxHQUFHLENBQUMsMkJBQTJCOzRCQUN0QyxpQkFBaUIsU0FBUyxDQUFDLE1BQU0sQ0FDL0I7NEJBRUYsZUFBZSxLQUFLLENBQUMsVUFBVSxHQUFHO3dCQUNwQztvQkFDRjtnQkFDRjtZQUNGO1FBRUo7O0FBRUo7QUFFQSxDQUFBLEdBQUEsZ0JBQVMsQUFBRCxFQUFFOzs7QUMvUlYscUpBQXFKOzs7NENBSXhJO0FBRmI7QUFFTyxNQUFNLFNBQVMsQUFBQztJQUNyQixJQUFJLFFBQVEsRUFBRTtJQUNkLElBQUksZUFBZSxDQUFDO0lBQ3BCLElBQUksY0FBYztJQUNsQixJQUFJLFlBQVk7SUFFaEIsU0FBUyxnQkFBZ0IsS0FBSztRQUM1QixNQUFNLElBQUksQ0FBQztZQUNULE9BQU87WUFDUCxLQUFLO1FBQ1A7UUFFQSxPQUFPO0lBQ1Q7SUFFQSxTQUFTLGtCQUFrQixLQUFLO1FBQzlCLE1BQU0sSUFBSSxDQUFDO1lBQ1QsT0FBTztZQUNQLEtBQUs7UUFDUDtRQUVBLE9BQU87SUFDVDtJQUVBLFNBQVMsZ0JBQWdCLEtBQUs7UUFDNUIsTUFBTSxJQUFJLENBQUM7WUFDVCxPQUFPO1lBQ1AsS0FBSztRQUNQO1FBRUEsT0FBTztJQUNUO0lBRUEsOEVBQThFO0lBQzlFLHNFQUFzRTtJQUN0RSx3Q0FBd0M7SUFDeEMsU0FBUyxNQUFNLGVBQWU7UUFDNUIsU0FBUztZQUNQLG1FQUFtRTtZQUNuRSxxRUFBcUU7WUFDckUsb0VBQW9FO1lBQ3BFLGlFQUFpRTtZQUNqRSxLQUFLO1lBQ0wsb0VBQW9FO1lBQ3BFLGdFQUFnRTtZQUNoRSxJQUFJLFNBQVMsRUFBRTtZQUNmLElBQUksWUFBWSxFQUFFO1lBRWxCLDRCQUE0QjtZQUM1QixPQUFPLElBQUksQ0FBQyxrQkFBdUIsQ0FBQSxHQUFBLGdCQUFPLEFBQUQsR0FBRztZQUM1QyxVQUFVLElBQUksQ0FDWiwwSEFDQTtZQUdGLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLE1BQU0sRUFBRSxJQUNwQyw4REFBOEQ7WUFDOUQsMERBQTBEO1lBQzFELDREQUE0RDtZQUM1RCxzQ0FBc0M7WUFDdEMsSUFBSSxTQUFTLENBQUMsRUFBRSxLQUFLLGNBQWM7Z0JBQ2pDLElBQUksT0FBTyxNQUFNLEtBQUs7Z0JBRXRCLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQUU7Z0JBQy9CLFVBQVUsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFO1lBRXpCLDREQUE0RDtZQUM5RCxPQUFPO2dCQUNMLElBQUksTUFBTSxTQUFTLENBQUMsRUFBRTtnQkFFdEIsSUFBSSxPQUFPLFFBQVEsWUFBWSxPQUFPLFFBQVEsWUFBWTtvQkFDeEQsT0FBTyxJQUFJLENBQUMsTUFBTTtvQkFDbEIsVUFBVSxJQUFJLENBQUMsS0FBSztnQkFDdEIsT0FBTztvQkFDTCxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUs7b0JBQ3hCLFVBQVUsSUFBSSxDQUFDLFdBQVc7Z0JBQzVCO1lBQ0Y7WUFHRixnQkFBZ0IsT0FBTyxJQUFJLENBQUMsUUFBUTtZQUVwQyx5RUFBeUU7WUFDekUscUVBQXFFO1lBQ3JFLGtFQUFrRTtZQUNsRSxRQUFRLEVBQUU7UUFDWjtRQUVBLE9BQU87SUFDVDtJQUVBLE9BQU87UUFDTCxLQUFLLE1BQU0sUUFBUSxHQUFHO1FBQ3RCLE1BQU0sTUFBTSxRQUFRLElBQUk7UUFDeEIsT0FBTyxNQUFNLFFBQVEsS0FBSztRQUMxQixPQUFPLE1BQU0sUUFBUSxLQUFLO1FBRTFCLFNBQVM7UUFDVCxXQUFXO1FBQ1gsU0FBUztJQUNYO0FBQ0Y7OztBQ3pHQSxRQUFRLGNBQWMsR0FBRyxTQUFVLENBQUM7SUFDbEMsT0FBTyxLQUFLLEVBQUUsVUFBVSxHQUFHLElBQUk7UUFBQyxTQUFTO0lBQUM7QUFDNUM7QUFFQSxRQUFRLGlCQUFpQixHQUFHLFNBQVUsQ0FBQztJQUNyQyxPQUFPLGNBQWMsQ0FBQyxHQUFHLGNBQWM7UUFBQyxPQUFPO0lBQUk7QUFDckQ7QUFFQSxRQUFRLFNBQVMsR0FBRyxTQUFVLE1BQU0sRUFBRSxJQUFJO0lBQ3hDLE9BQU8sSUFBSSxDQUFDLFFBQVEsT0FBTyxDQUFDLFNBQVUsR0FBRztRQUN2QyxJQUNFLFFBQVEsYUFDUixRQUFRLGdCQUNSLE9BQU8sU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxNQUUzQztRQUdGLE9BQU8sY0FBYyxDQUFDLE1BQU0sS0FBSztZQUMvQixZQUFZO1lBQ1osS0FBSztnQkFDSCxPQUFPLE1BQU0sQ0FBQyxJQUFJO1lBQ3BCO1FBQ0Y7SUFDRjtJQUVBLE9BQU87QUFDVDtBQUVBLFFBQVEsTUFBTSxHQUFHLFNBQVUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHO0lBQzVDLE9BQU8sY0FBYyxDQUFDLE1BQU0sVUFBVTtRQUNwQyxZQUFZO1FBQ1osS0FBSztJQUNQO0FBQ0Y7Ozs7OzZDQ2hDYTtBQUViLGlEQUFzQjtBQVN0QiwrQ0FBZ0I7QUFiaEI7QUFFTyxNQUFNLFVBQVU7QUFFaEIsZUFBZSxZQUFZLEdBQUc7SUFDbkMsQ0FBQSxHQUFBLGNBQU0sQUFBRCxFQUFFLEdBQUcsQ0FBQyx1Q0FBdUMsTUFBTTtJQUV4RCxPQUFPLElBQUksUUFBUSxDQUFDLFNBQVM7UUFDM0IsT0FBTyxJQUFJLENBQUMsMkJBQTJCLEtBQUs7UUFDNUMsUUFBUTtJQUNWO0FBQ0Y7QUFFTyxTQUFTLFVBQVUsUUFBUTtJQUNoQyxJQUFJLFlBQVk7SUFFaEIsTUFBTSxtQkFBbUI7UUFDdkIsSUFBSSxDQUFDLFdBQVc7WUFDZCxZQUFZO1lBQ1osc0JBQXNCO2dCQUNwQjtnQkFDQSxZQUFZO1lBQ2Q7UUFDRjtJQUNGO0lBRUEsTUFBTSxXQUFXLElBQUksaUJBQWlCLENBQUM7UUFDckMsS0FBSyxNQUFNLFlBQVksY0FDckIsSUFBSSxTQUFTLElBQUksS0FBSyxhQUFhO1lBQ2pDO1lBQ0E7UUFDRjtJQUVKO0lBRUEsU0FBUyxPQUFPLENBQUMsVUFBVTtRQUN6QixXQUFXO1FBQ1gsU0FBUztJQUNYO0FBQ0YiLCJzb3VyY2VzIjpbInNyYy9zZXJ2aWNlcy95b3V0dWJlLmpzIiwic3JjL2NvbW1vbi9sb2dnZXIuanMiLCJub2RlX21vZHVsZXMvQHBhcmNlbC9jb25maWctd2ViZXh0ZW5zaW9uL25vZGVfbW9kdWxlcy9AcGFyY2VsL3RyYW5zZm9ybWVyLWpzL3NyYy9lc21vZHVsZS1oZWxwZXJzLmpzIiwic3JjL2NvbW1vbi91dGlscy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBsb2dnZXIgfSBmcm9tIFwiLi4vY29tbW9uL2xvZ2dlclwiO1xyXG5pbXBvcnQgeyBnZXRSZXNvdXJjZSwgd2F0Y2hQYWdlIH0gZnJvbSBcIi4uL2NvbW1vbi91dGlsc1wiO1xyXG5cclxubG9nZ2VyLmxvZyhcIllvdVR1YmUgZGV0ZWN0ZWQhXCIpO1xyXG5cclxuY29uc3QgZG93bmxvYWRJY29uID0gKGNsYXNzTmFtZXMpID0+IHtcclxuICAvLyBVc2UgdGhlIG1ldGEgdGhlbWUgY29sb3IgdG8gZGV0ZXJtaW5lIGlmIHRoZSB1c2VyIGlzIHVzaW5nIGRhcmsgbW9kZVxyXG4gIHZhciBpc0RhcmtNb2RlID1cclxuICAgIGRvY3VtZW50LmhlYWRcclxuICAgICAgLnF1ZXJ5U2VsZWN0b3IoJ21ldGFbbmFtZT1cInRoZW1lLWNvbG9yXCJdJylcclxuICAgICAgLmdldEF0dHJpYnV0ZShcImNvbnRlbnRcIikgIT0gXCJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuOTgpXCI7XHJcblxyXG4gIHJldHVybiBgXHJcbiAgICA8c3ZnIHZpZXdCb3g9XCIwIDAgNDggNDhcIiBjbGFzcz1cIiR7Y2xhc3NOYW1lc31cIj5cclxuICAgICAgICA8cGF0aCBmaWxsLXJ1bGU9XCJldmVub2RkXCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiIGQ9XCJNMzggNDRIMTBWNDJIMzhWNDRaXCIgZmlsbD1cIiR7XHJcbiAgICAgICAgICBpc0RhcmtNb2RlID8gXCJ3aGl0ZVwiIDogXCJibGFja1wiXHJcbiAgICAgICAgfVwiIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBjbGlwLXJ1bGU9XCJldmVub2RkXCI+PC9wYXRoPlxyXG4gICAgICAgIDxwYXRoIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBjbGlwLXJ1bGU9XCJldmVub2RkXCIgZD1cIk0yMyAzNC41VjQuNUgyNVYzNC41SDIzWlwiIGZpbGw9XCIke1xyXG4gICAgICAgICAgaXNEYXJrTW9kZSA/IFwid2hpdGVcIiA6IFwiYmxhY2tcIlxyXG4gICAgICAgIH1cIiBmaWxsLXJ1bGU9XCJldmVub2RkXCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiPjwvcGF0aD5cclxuICAgICAgICA8cGF0aCBmaWxsLXJ1bGU9XCJldmVub2RkXCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiIGQ9XCJNMjQgMzUuNDE0MkwxMC41ODU4IDIyTDEyIDIwLjU4NThMMjQgMzIuNTg1OEwzNiAyMC41ODU4TDM3LjQxNDIgMjJMMjQgMzUuNDE0MlpcIiBmaWxsPVwiJHtcclxuICAgICAgICAgIGlzRGFya01vZGUgPyBcIndoaXRlXCIgOiBcImJsYWNrXCJcclxuICAgICAgICB9XCIgZmlsbC1ydWxlPVwiZXZlbm9kZFwiIGNsaXAtcnVsZT1cImV2ZW5vZGRcIj48L3BhdGg+XHJcbiAgICA8L3N2Zz5cclxuICAgIGA7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBhZGREb3dubG9hZEJ1dHRvbigpIHtcclxuICBjb25zdCBpc0xpdmVWaWRlbyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tzaG91bGQtc3RhbXAtY2hhdD1cIlwiXScpO1xyXG4gIGNvbnN0IGlzU2hvcnRzVmlkZW8gPSB3aW5kb3cubG9jYXRpb24uaHJlZi5pbmNsdWRlcyhcIi9zaG9ydHMvXCIpO1xyXG5cclxuICBpZiAoIWlzTGl2ZVZpZGVvKSB7XHJcbiAgICBpZiAoIWlzU2hvcnRzVmlkZW8pIHtcclxuICAgICAgdmFyIHRvb2xCYXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgIFwieXRkLXdhdGNoLWZsZXh5ICN0b3AtbGV2ZWwtYnV0dG9ucy1jb21wdXRlZFwiXHJcbiAgICAgICk7XHJcbiAgICAgIGlmICh0b29sQmFyKSB7XHJcbiAgICAgICAgLy8gR2V0IGEgdGVtcGxhdGUsIG5vcm1hbCBidXR0b24gKHVzdWFsbHkgdGhlIHNoYXJlIGJ1dHRvbikgYW5kIHRoZSB3ZSBjbG9uZSBpdCBhbmQgbW9kaWZ5IGl0IHRvIG91ciBsaWtpbmdcclxuICAgICAgICBjb25zdCB0ZW1wbGF0ZUJ1dHRvbiA9IHRvb2xCYXIucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICd5dC1idXR0b24tdmlldy1tb2RlbCBidXR0b24tdmlldy1tb2RlbCBidXR0b25bYXJpYS1sYWJlbD1cIlNoYXJlXCJdJ1xyXG4gICAgICAgICkucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50O1xyXG5cclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICAhdGVtcGxhdGVCdXR0b24ucGFyZW50RWxlbWVudC5xdWVyeVNlbGVjdG9yKCdbY29iYWx0LWV4dD1cInlvdXR1YmVcIl0nKVxyXG4gICAgICAgICkge1xyXG4gICAgICAgICAgY29uc3QgZG93bmxvYWRCdXR0b24gPSB0ZW1wbGF0ZUJ1dHRvbi5jbG9uZU5vZGUodHJ1ZSk7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhkb3dubG9hZEJ1dHRvbik7XHJcbiAgICAgICAgICBjb25zdCBkb3dubG9hZEJ1dHRvbklubmVyID0gZG93bmxvYWRCdXR0b24ucXVlcnlTZWxlY3RvcihcImJ1dHRvblwiKTtcclxuICAgICAgICAgIHRvb2xCYXIuaW5zZXJ0QWRqYWNlbnRFbGVtZW50KFwiYmVmb3JlZW5kXCIsIGRvd25sb2FkQnV0dG9uKTtcclxuXHJcbiAgICAgICAgICBkb3dubG9hZEJ1dHRvbi5zZXRBdHRyaWJ1dGUoXCJjb2JhbHQtZXh0XCIsIFwieW91dHViZVwiKTtcclxuICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnF1ZXJ5U2VsZWN0b3IoXCJ5dC1pY29uXCIpLnBhcmVudEVsZW1lbnQuaW5uZXJIVE1MID1cclxuICAgICAgICAgICAgZG93bmxvYWRJY29uKFxyXG4gICAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnF1ZXJ5U2VsZWN0b3IoXCJ5dC1pY29uXCIpLmNsYXNzTGlzdC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci50aXRsZSA9IFwiZG93bmxvYWQgd2l0aCBjb2JhbHRcIjtcclxuICAgICAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuc2V0QXR0cmlidXRlKFxyXG4gICAgICAgICAgICBcImFyaWEtbGFiZWxcIixcclxuICAgICAgICAgICAgXCJkb3dubG9hZCB3aXRoIGNvYmFsdFwiXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgICAgIFwiLnl0LXNwZWMtYnV0dG9uLXNoYXBlLW5leHRfX2J1dHRvbi10ZXh0LWNvbnRlbnRcIlxyXG4gICAgICAgICAgKS50ZXh0Q29udGVudCA9IFwiRG93bmxvYWRcIjtcclxuXHJcbiAgICAgICAgICBjb25zdCBzdHlsZXMgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XHJcbiAgICAgICAgICBzdHlsZXMuaW5uZXJIVE1MID0gYFxyXG4gICAgICAgICAgICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxNDQ4cHgpIHtcclxuICAgICAgICAgICAgICBbY29iYWx0LWV4dD1cInlvdXR1YmVcIl0gLnl0LXNwZWMtYnV0dG9uLXNoYXBlLW5leHRfX2J1dHRvbi10ZXh0LWNvbnRlbnQge1xyXG4gICAgICAgICAgICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgW2NvYmFsdC1leHQ9XCJ5b3V0dWJlXCJdIC55dC1zcGVjLWJ1dHRvbi1zaGFwZS1uZXh0X19pY29uIHtcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luOiAtNnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9YDtcclxuXHJcbiAgICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlcyk7XHJcblxyXG4gICAgICAgICAgdG9vbEJhci5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJiZWZvcmVlbmRcIiwgZG93bmxvYWRCdXR0b24pO1xyXG5cclxuICAgICAgICAgIC8vIExldCBZb3VUdWJlIGNvbXB1dGUgdGhlIG92ZXJmbG93IG1lbnVcclxuICAgICAgICAgIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwieXQtcmVuZGVyZXJzdGFtcGVyLWZpbmlzaGVkXCIpKTtcclxuICAgICAgICAgIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwieXQtcmVuZGVyaWRvbS1maW5pc2hlZFwiKSk7XHJcbiAgICAgICAgICBkb2N1bWVudC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcInl0LW1hc3RoZWFkLWhlaWdodC1jaGFuZ2VkXCIpKTtcclxuXHJcbiAgICAgICAgICBkb3dubG9hZEJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcclxuICAgICAgICAgICAgZ2V0UmVzb3VyY2Uod2luZG93LmxvY2F0aW9uLmhyZWYpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zdCB0b29sQmFycyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuYWN0aW9uLWNvbnRhaW5lclwiKTtcclxuICAgICAgaWYgKHRvb2xCYXJzKSB7XHJcbiAgICAgICAgdG9vbEJhcnMuZm9yRWFjaCgodG9vbEJhcikgPT4ge1xyXG4gICAgICAgICAgaWYgKCF0b29sQmFyLnF1ZXJ5U2VsZWN0b3IoJ1tjb2JhbHQtZXh0PVwieW91dHViZVwiXScpKSB7XHJcbiAgICAgICAgICAgIC8vIEdldCBhIHRlbXBsYXRlLCBub3JtYWwgYnV0dG9uICh0aGUgc2hhcmUgYnV0dG9uKVxyXG4gICAgICAgICAgICBjb25zdCB0ZW1wbGF0ZSA9IHRvb2xCYXIucXVlcnlTZWxlY3RvckFsbChcclxuICAgICAgICAgICAgICBcImRpdi5idXR0b24tY29udGFpbmVyXCJcclxuICAgICAgICAgICAgKVsyXTtcclxuXHJcbiAgICAgICAgICAgIC8vIEFwcGx5IGFsbCBuZWNlc3Nhcnkgc3R5bGVzIGFuZCBhY2Nlc3NpYmlsaXR5IGZlYXR1cmVzIHRvIHRoZSBidXR0b24gd3JhcHBlclxyXG4gICAgICAgICAgICBjb25zdCBkb3dubG9hZEJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7IC8vIGNsb25lTm9kZSgpIGRvZXNuJ3Qgd29yayBpbiB0aGUgc2NlbmFyaW8gYmVjYXVzZSBvZiBZb3VUdWJlIHJlbmRlcmluZyBzeXN0ZW0uIEkgaGF0ZSBpdCBoZXJlIHRvby5cclxuICAgICAgICAgICAgZG93bmxvYWRCdXR0b24uY2xhc3NMaXN0LmFkZCguLi50ZW1wbGF0ZS5jbGFzc0xpc3QpO1xyXG4gICAgICAgICAgICBkb3dubG9hZEJ1dHRvbi5zZXRBdHRyaWJ1dGUoXCJjb2JhbHQtZXh0XCIsIFwieW91dHViZVwiKTtcclxuICAgICAgICAgICAgZG93bmxvYWRCdXR0b24udGl0bGUgPSBcIkRvd25sb2FkIHNob3J0IHdpdGggY29iYWx0XCI7XHJcbiAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnN0eWxlLnBhZGRpbmdUb3AgPSBcIjE2cHhcIjtcclxuXHJcbiAgICAgICAgICAgIC8vIENyZWF0ZSB0aGUgZWxlbWVudHMgdGhhdCByZXNpZGUgaW5zaWRlIHRoZSBidXR0b24gYnV0IGRvbid0IGhhdmUgYW55IHNwZWNpZmljIHByb3BlcnRpZXMgd2UgbmVlZCB0byBjaGFuZ2VcclxuICAgICAgICAgICAgY29uc3QgZG93bmxvYWRCdXR0b25Jbm5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXHJcbiAgICAgICAgICAgICAgXCJ5dGQtY29iYWx0LWJ1dHRvbi1yZW5kZXJlclwiXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiI3NoYXJlLWJ1dHRvbiB5dGQtYnV0dG9uLXJlbmRlcmVyXCIpXHJcbiAgICAgICAgICAgICAgICAuY2xhc3NMaXN0XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuc2V0QXR0cmlidXRlKFwidmVydGljYWxseS1hbGlnbmVkXCIsIFwiXCIpO1xyXG4gICAgICAgICAgICBjb25zdCBidXR0b25TaGFwZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXHJcbiAgICAgICAgICAgICAgXCJ5dC1jb2JhbHQtYnV0dG9uLXNoYXBlXCJcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImxhYmVsXCIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbC5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLnRlbXBsYXRlLnF1ZXJ5U2VsZWN0b3IoXCJ5dC1idXR0b24tc2hhcGUgPiBsYWJlbFwiKS5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIC8vIFRoaXMgaXMgdGhlIGFjdHVhbCBidXR0b24gaW5zaWRlIG9mIHRoZSBidXR0b24gd3JhcHBlclxyXG4gICAgICAgICAgICBjb25zdCBidXR0b25MYWJlbElubmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJbm5lci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLnRlbXBsYXRlLnF1ZXJ5U2VsZWN0b3IoXCJ5dC1idXR0b24tc2hhcGUgPiBsYWJlbCA+IGJ1dHRvblwiKVxyXG4gICAgICAgICAgICAgICAgLmNsYXNzTGlzdFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbElubmVyLnNldEF0dHJpYnV0ZShcclxuICAgICAgICAgICAgICBcImFyaWEtbGFiZWxcIixcclxuICAgICAgICAgICAgICBcIkRvd25sb2FkIHZpZGVvIHdpdGggY29iYWx0XCJcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJbm5lci5zZXRBdHRyaWJ1dGUoXCJ0eXBlXCIsIFwiYnV0dG9uXCIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbElubmVyLnRpdGxlID0gXCJEb3dubG9hZCB2aWRlbyB3aXRoIGNvYmFsdFwiO1xyXG5cclxuICAgICAgICAgICAgLy8gRmVlZGJhY2sgc2hhcGUgaXMgcmVzcG9uc2libGUgZm9yIHNvbWUgbmljaGUgbW9iaWxlL3RvdWNoIFVJIHJlc3BvbnNlXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkZlZWRiYWNrU2hhcGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFxyXG4gICAgICAgICAgICAgIFwieXQtdG91Y2gtZmVlZGJhY2stc2hhcGVcIlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlLnN0eWxlLmJvcmRlclJhZGl1cyA9IFwiaW5oZXJpdFwiO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVyLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgICAgICAgLi4udGVtcGxhdGUucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICAgICAgIFwieXQtYnV0dG9uLXNoYXBlIGxhYmVsIHl0LXRvdWNoLWZlZWRiYWNrLXNoYXBlIGRpdlwiXHJcbiAgICAgICAgICAgICAgKS5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVyLnNldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIsIHRydWUpO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVySW5uZXIxID1cclxuICAgICAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlSW5uZXJJbm5lcjEuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi50ZW1wbGF0ZS5xdWVyeVNlbGVjdG9yQWxsKFxyXG4gICAgICAgICAgICAgICAgXCJ5dC1idXR0b24tc2hhcGUgbGFiZWwgeXQtdG91Y2gtZmVlZGJhY2stc2hhcGUgZGl2IGRpdlwiXHJcbiAgICAgICAgICAgICAgKVswXS5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkZlZWRiYWNrU2hhcGVJbm5lcklubmVyMiA9XHJcbiAgICAgICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVySW5uZXIyLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgICAgICAgLi4udGVtcGxhdGUucXVlcnlTZWxlY3RvckFsbChcclxuICAgICAgICAgICAgICAgIFwieXQtYnV0dG9uLXNoYXBlIGxhYmVsIHl0LXRvdWNoLWZlZWRiYWNrLXNoYXBlIGRpdiBkaXZcIlxyXG4gICAgICAgICAgICAgIClbMV0uY2xhc3NMaXN0XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAvLyBQdXQgdGhlIGZlZWRiYWNrIHNoYXBlIHRvZ2V0aGVyXHJcbiAgICAgICAgICAgIGJ1dHRvbkZlZWRiYWNrU2hhcGVJbm5lcklubmVyMS5pbnNlcnRBZGphY2VudEVsZW1lbnQoXHJcbiAgICAgICAgICAgICAgXCJhZnRlcmVuZFwiLFxyXG4gICAgICAgICAgICAgIGJ1dHRvbkZlZWRiYWNrU2hhcGVJbm5lcklubmVyMlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlSW5uZXIuYXBwZW5kQ2hpbGQoXHJcbiAgICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVySW5uZXIxXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGJ1dHRvbkZlZWRiYWNrU2hhcGUuYXBwZW5kQ2hpbGQoYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVyKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJbm5lci5hcHBlbmRDaGlsZChidXR0b25GZWVkYmFja1NoYXBlKTtcclxuXHJcbiAgICAgICAgICAgIC8vIENyZWF0ZSB0aGUgZG93bmxvYWQgaWNvblxyXG4gICAgICAgICAgICBjb25zdCBidXR0b25MYWJlbEljb25PdXRlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSWNvbk91dGVyLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgICAgICAgLi4udGVtcGxhdGUucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICAgICAgIFwieXQtYnV0dG9uLXNoYXBlID4gbGFiZWwgPiBidXR0b24gPiBkaXZcIlxyXG4gICAgICAgICAgICAgICkuY2xhc3NMaXN0LFxyXG4gICAgICAgICAgICAgIFwieXQtY29iYWx0LWJ1dHRvbi1pY29uXCJcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uT3V0ZXIuc2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBidXR0b25MYWJlbEljb25Jbm5lciA9XHJcbiAgICAgICAgICAgICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInl0LWNvYmFsdC1pY29uXCIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbEljb25Jbm5lci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLnRlbXBsYXRlLnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgICAgICAgICBcInl0LWJ1dHRvbi1zaGFwZSA+IGxhYmVsID4gYnV0dG9uID4gZGl2ID4geXQtaWNvblwiXHJcbiAgICAgICAgICAgICAgKS5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uSW5uZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICBcInl0LWljb25cIixcclxuICAgICAgICAgICAgICBcInl0LWljb24tc2hhcGVcIixcclxuICAgICAgICAgICAgICBcInl0LXNwZWMtaWNvbi1zaGFwZVwiXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSWNvbklubmVyLnN0eWxlLndpZHRoID0gXCIyNHB4XCI7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSWNvbklubmVyLnN0eWxlLmhlaWdodCA9IFwiMjRweFwiO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbEljb25Jbm5lci5zdHlsZS5kaXNwbGF5ID0gXCJibG9ja1wiO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbEljb25Jbm5lci5pbm5lckhUTUwgPSBkb3dubG9hZEljb24oXHJcbiAgICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uSW5uZXIuY2xhc3NMaXN0LnRvU3RyaW5nKClcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkljb25MYWJlbE91dGVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgICAgICAgYnV0dG9uSWNvbkxhYmVsT3V0ZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi50ZW1wbGF0ZS5xdWVyeVNlbGVjdG9yKFwieXQtYnV0dG9uLXNoYXBlID4gbGFiZWwgPiBkaXZcIilcclxuICAgICAgICAgICAgICAgIC5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGJ1dHRvbkljb25MYWJlbE91dGVyLnNldEF0dHJpYnV0ZShcImFyaWEtaGlkZGVuXCIsIHRydWUpO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uSWNvbkxhYmVsSW5uZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtcclxuICAgICAgICAgICAgYnV0dG9uSWNvbkxhYmVsSW5uZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi50ZW1wbGF0ZS5xdWVyeVNlbGVjdG9yKFwieXQtYnV0dG9uLXNoYXBlID4gbGFiZWwgPiBkaXYgPiBzcGFuXCIpXHJcbiAgICAgICAgICAgICAgICAuY2xhc3NMaXN0XHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICBidXR0b25JY29uTGFiZWxJbm5lci5zZXRBdHRyaWJ1dGUoXCJyb2xlXCIsIFwidGV4dFwiKTtcclxuICAgICAgICAgICAgYnV0dG9uSWNvbkxhYmVsSW5uZXIuaW5uZXJUZXh0ID0gXCJTYXZlXCI7IC8vIFwiU2F2ZVwiIGluc3RlYWQgb2YgXCJEb3dubG9hZFwiIGJlY2F1c2UgXCJEb3dubG9hZFwiIGlzIHRvbyBsb25nIGxvbFxyXG5cclxuICAgICAgICAgICAgLy8gUHV0IGV2ZXJ5dGhpbmcgdG9nZXRoZXIgKEkgaGF0ZSB0aGlzIHNvIG11Y2gpXHJcbiAgICAgICAgICAgIGJ1dHRvbkljb25MYWJlbE91dGVyLmFwcGVuZENoaWxkKGJ1dHRvbkljb25MYWJlbElubmVyKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uT3V0ZXIuYXBwZW5kQ2hpbGQoYnV0dG9uTGFiZWxJY29uSW5uZXIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbElubmVyLmFwcGVuZENoaWxkKGJ1dHRvbkxhYmVsSWNvbk91dGVyKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWwuYXBwZW5kQ2hpbGQoYnV0dG9uTGFiZWxJbm5lcik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsLmFwcGVuZENoaWxkKGJ1dHRvbkljb25MYWJlbE91dGVyKTtcclxuICAgICAgICAgICAgYnV0dG9uU2hhcGUuYXBwZW5kQ2hpbGQoYnV0dG9uTGFiZWwpO1xyXG4gICAgICAgICAgICBkb3dubG9hZEJ1dHRvbklubmVyLmFwcGVuZENoaWxkKGJ1dHRvblNoYXBlKTtcclxuICAgICAgICAgICAgZG93bmxvYWRCdXR0b24uYXBwZW5kQ2hpbGQoZG93bmxvYWRCdXR0b25Jbm5lcik7XHJcblxyXG4gICAgICAgICAgICBkb3dubG9hZEJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcclxuICAgICAgICAgICAgICBnZXRSZXNvdXJjZSh3aW5kb3cubG9jYXRpb24uaHJlZik7XHJcbiAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgdG9vbEJhclxyXG4gICAgICAgICAgICAgID8ucXVlcnlTZWxlY3RvcihcIiNzaGFyZS1idXR0b25cIilcclxuICAgICAgICAgICAgICAuaW5zZXJ0QWRqYWNlbnRFbGVtZW50KFwiYWZ0ZXJlbmRcIiwgZG93bmxvYWRCdXR0b24pO1xyXG5cclxuICAgICAgICAgICAgLy8gWW91VHViZSBzbGlnaHRseSBjaGFuZ2VzIHRoZSBsb29rIG9mIHRoZSBhY3Rpb24gYnV0dG9ucyAobGlrZSwgY29tbWVudCwgZXRjKSB3aGVuIHRoZSBkZXNjcmlwdGlvbiBhbmQgY29tbWVudCBzZWN0aW9uIHBhbmVscyBhcmUgZXhwYW5kZWRcclxuICAgICAgICAgICAgLy8gQm90aCBvZiB0aGVzZSBldmVudCBsaXN0ZW5lcnMgcnVuIGluIHBhcmFsbGVsIHRvIGVuc3VyZSB0aGF0IHRoZSBjb3JyZWN0IGJ1dHRvbiBzdHlsZXMgYXJlIGFwcGxpZWQgZXZlbiB3aGVuIHNpbXBseSB0b2dnbGluZyBiZXR3ZWVuIHRoZSBwYW5lbHNcclxuICAgICAgICAgICAgLy8gUmV2ZXJzZS1lbmdpbmVlcmluZyBZb3VUdWUncyBjb2RlIGlzIGEgcGFpbiwgYnV0IHRoaXMgaXMgdGhlIGJlc3QgSSBjb3VsZCBjb21lIHVwIHdpdGhcclxuICAgICAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInl0LWFjdGlvblwiLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIGUuZGV0YWlsICYmXHJcbiAgICAgICAgICAgICAgICBlLmRldGFpbC5hcmdzICYmXHJcbiAgICAgICAgICAgICAgICBlPy5kZXRhaWw/LmFyZ3NbMV0gPT09IFwiRU5HQUdFTUVOVF9QQU5FTF9WSVNJQklMSVRZX0VYUEFOREVEXCIgJiZcclxuICAgICAgICAgICAgICAgIChlPy5kZXRhaWw/LmFyZ3NbMl0gPT09IFwiZW5nYWdlbWVudC1wYW5lbC1jb21tZW50cy1zZWN0aW9uXCIgfHxcclxuICAgICAgICAgICAgICAgICAgZT8uZGV0YWlsPy5hcmdzWzJdID09PVxyXG4gICAgICAgICAgICAgICAgICAgIFwiZW5nYWdlbWVudC1wYW5lbC1zdHJ1Y3R1cmVkLWRlc2NyaXB0aW9uXCIpXHJcbiAgICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgICBsb2dnZXIubG9nKFwiZW5nYWdlbWVudCBwYW5lbCBzaG93blwiLCBlKTtcclxuICAgICAgICAgICAgICAgIGJ1dHRvbkxhYmVsSW5uZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAgICAgXCJ5dC1zcGVjLWJ1dHRvbi1zaGFwZS1uZXh0LS1vdmVybGF5LWRhcmtcIlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnN0eWxlLnBhZGRpbmdUb3AgPSBcIjBweFwiO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ5dC1hY3Rpb25cIiwgKGUpID0+IHtcclxuICAgICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgICBlLmRldGFpbCAmJlxyXG4gICAgICAgICAgICAgICAgZS5kZXRhaWwuYXJncyAmJlxyXG4gICAgICAgICAgICAgICAgZT8uZGV0YWlsPy5hcmdzWzFdID09PSBcIkVOR0FHRU1FTlRfUEFORUxfVklTSUJJTElUWV9ISURERU5cIiAmJlxyXG4gICAgICAgICAgICAgICAgKGU/LmRldGFpbD8uYXJnc1syXSA9PT0gXCJlbmdhZ2VtZW50LXBhbmVsLWNvbW1lbnRzLXNlY3Rpb25cIiB8fFxyXG4gICAgICAgICAgICAgICAgICBlPy5kZXRhaWw/LmFyZ3NbMl0gPT09XHJcbiAgICAgICAgICAgICAgICAgICAgXCJlbmdhZ2VtZW50LXBhbmVsLXN0cnVjdHVyZWQtZGVzY3JpcHRpb25cIilcclxuICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIGxvZ2dlci5sb2coXCJlbmdhZ2VtZW50IHBhbmVsIGhpZGRlblwiLCBlKTtcclxuICAgICAgICAgICAgICAgIGJ1dHRvbkxhYmVsSW5uZXIuY2xhc3NMaXN0LnJlbW92ZShcclxuICAgICAgICAgICAgICAgICAgXCJ5dC1zcGVjLWJ1dHRvbi1zaGFwZS1uZXh0LS1vdmVybGF5LWRhcmtcIlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnN0eWxlLnBhZGRpbmdUb3AgPSBcIjE2cHhcIjtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG53YXRjaFBhZ2UoYWRkRG93bmxvYWRCdXR0b24pO1xyXG4iLCIvLyBUaGlzIGlzIGEgbW9kaWZpZWQgdmVyc2lvbiBvZiB0aGUgXCJlY2hvXCIgbG9nZ2VyIGNvbmNlcHQgZnJvbSBodHRwczovL3d3dy5iZW5uYWRlbC5jb20vYmxvZy8zOTQxLXN0eWxpbmctY29uc29sZS1sb2ctb3V0cHV0LWZvcm1hdHRpbmctd2l0aC1jc3MuaHRtXHJcblxyXG5pbXBvcnQgeyB2ZXJzaW9uIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBsb2dnZXIgPSAoZnVuY3Rpb24gKCkge1xyXG4gIHZhciBxdWV1ZSA9IFtdO1xyXG4gIHZhciBsb2dnZXJfVE9LRU4gPSB7fTtcclxuICB2YXIgUkVTRVRfSU5QVVQgPSBcIiVjIFwiO1xyXG4gIHZhciBSRVNFVF9DU1MgPSBcIlwiO1xyXG5cclxuICBmdW5jdGlvbiBhbGVydEZvcm1hdHRpbmcodmFsdWUpIHtcclxuICAgIHF1ZXVlLnB1c2goe1xyXG4gICAgICB2YWx1ZTogdmFsdWUsXHJcbiAgICAgIGNzczogXCJkaXNwbGF5OiBpbmxpbmUtYmxvY2sgOyBiYWNrZ3JvdW5kLWNvbG9yOiAjZTAwMDVhIDsgY29sb3I6ICNmZmZmZmYgOyBmb250LXdlaWdodDogYm9sZCA7IHBhZGRpbmc6IDNweCA3cHggM3B4IDdweCA7IGJvcmRlci1yYWRpdXM6IDNweCAzcHggM3B4IDNweCA7XCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9nZ2VyX1RPS0VOO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gd2FybmluZ0Zvcm1hdHRpbmcodmFsdWUpIHtcclxuICAgIHF1ZXVlLnB1c2goe1xyXG4gICAgICB2YWx1ZTogdmFsdWUsXHJcbiAgICAgIGNzczogXCJkaXNwbGF5OiBpbmxpbmUtYmxvY2sgOyBiYWNrZ3JvdW5kLWNvbG9yOiBnb2xkIDsgY29sb3I6IGJsYWNrIDsgZm9udC13ZWlnaHQ6IGJvbGQgOyBwYWRkaW5nOiAzcHggN3B4IDNweCA3cHggOyBib3JkZXItcmFkaXVzOiAzcHggM3B4IDNweCAzcHggO1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGxvZ2dlcl9UT0tFTjtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHRpdGxlRm9ybWF0dGluZyh2YWx1ZSkge1xyXG4gICAgcXVldWUucHVzaCh7XHJcbiAgICAgIHZhbHVlOiB2YWx1ZSxcclxuICAgICAgY3NzOiBcImRpc3BsYXk6IGlubGluZS1ibG9jayA7IGJhY2tncm91bmQtY29sb3I6IGJsYWNrIDsgY29sb3I6IHdoaXRlIDsgZm9udC13ZWlnaHQ6IGJvbGQgOyBwYWRkaW5nOiAzcHggN3B4IDNweCA3cHggOyBib3JkZXItcmFkaXVzOiAzcHggM3B4IDNweCAzcHggO1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGxvZ2dlcl9UT0tFTjtcclxuICB9XHJcblxyXG4gIC8vIEkgcHJvdmlkZSBhbiBsb2dnZXItYmFzZWQgcHJveHkgdG8gdGhlIGdpdmVuIENvbnNvbGUgRnVuY3Rpb24uIFRoaXMgdXNlcyBhblxyXG4gIC8vIGludGVybmFsIHF1ZXVlIHRvIGFnZ3JlZ2F0ZSB2YWx1ZXMgYmVmb3JlIGNhbGxpbmcgdGhlIGdpdmVuIENvbnNvbGVcclxuICAvLyBGdW5jdGlvbiB3aXRoIHRoZSBkZXNpcmVkIGZvcm1hdHRpbmcuXHJcbiAgZnVuY3Rpb24gdXNpbmcoY29uc29sZUZ1bmN0aW9uKSB7XHJcbiAgICBmdW5jdGlvbiBjb25zb2xlRnVuY3Rpb25Qcm94eSgpIHtcclxuICAgICAgLy8gQXMgd2UgbG9vcCBvdmVyIHRoZSBhcmd1bWVudHMsIHdlJ3JlIGdvaW5nIHRvIGFnZ3JlZ2F0ZSBhIHNldCBvZlxyXG4gICAgICAvLyBpbnB1dHMgYW5kIG1vZGlmaWVycy4gVGhlIElucHV0cyB3aWxsIHVsdGltYXRlbHkgYmUgY29sbGFwc2VkIGRvd25cclxuICAgICAgLy8gaW50byBhIHNpbmdsZSBzdHJpbmcgdGhhdCBhY3RzIGFzIHRoZSBmaXJzdCBjb25zb2xlLmxvZyBwYXJhbWV0ZXJcclxuICAgICAgLy8gd2hpbGUgdGhlIG1vZGlmaWVycyBhcmUgdGhlbiBTUFJFQUQgaW50byBjb25zb2xlLmxvZyBhcyAyLi4uTi5cclxuICAgICAgLy8gLS1cclxuICAgICAgLy8gTk9URTogQWZ0ZXIgZWFjaCBpbnB1dC9tb2RpZmllciBwYWlyLCBJJ20gYWRkaW5nIGEgUkVTRVQgcGFpcmluZy5cclxuICAgICAgLy8gVGhpcyBpbXBsaWNpdGx5IHJlc2V0cyB0aGUgQ1NTIGFmdGVyIGV2ZXJ5IGZvcm1hdHRlZCBwYWlyaW5nLlxyXG4gICAgICB2YXIgaW5wdXRzID0gW107XHJcbiAgICAgIHZhciBtb2RpZmllcnMgPSBbXTtcclxuXHJcbiAgICAgIC8vIEFkZCB0aGUgY29iYWx0LWV4dCBoZWFkZXJcclxuICAgICAgaW5wdXRzLnB1c2goXCIlY1wiICsgXCJjb2JhbHQtZXh0QFwiICsgdmVyc2lvbiwgUkVTRVRfSU5QVVQpO1xyXG4gICAgICBtb2RpZmllcnMucHVzaChcclxuICAgICAgICBcImRpc3BsYXk6IGlubGluZS1ibG9jazsgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7IGNvbG9yOiB3aGl0ZTsgZm9udC13ZWlnaHQ6IGJvbGQ7IHBhZGRpbmc6IDNweCA3cHg7IGJvcmRlci1yYWRpdXM6IDNweDtcIixcclxuICAgICAgICBSRVNFVF9DU1NcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgLy8gV2hlbiB0aGUgZm9ybWF0dGluZyB1dGlsaXR5IG1ldGhvZHMgYXJlIGNhbGxlZCwgdGhleSByZXR1cm5cclxuICAgICAgICAvLyBhIHNwZWNpYWwgdG9rZW4uIFRoaXMgaW5kaWNhdGVzIHRoYXQgd2Ugc2hvdWxkIHB1bGwgdGhlXHJcbiAgICAgICAgLy8gY29ycmVzcG9uZGluZyB2YWx1ZSBvdXQgb2YgdGhlIFFVRVVFIGluc3RlYWQgb2YgdHJ5aW5nIHRvXHJcbiAgICAgICAgLy8gb3V0cHV0IHRoZSBnaXZlbiBhcmd1bWVudCBkaXJlY3RseS5cclxuICAgICAgICBpZiAoYXJndW1lbnRzW2ldID09PSBsb2dnZXJfVE9LRU4pIHtcclxuICAgICAgICAgIHZhciBpdGVtID0gcXVldWUuc2hpZnQoKTtcclxuXHJcbiAgICAgICAgICBpbnB1dHMucHVzaChcIiVjXCIgKyBpdGVtLnZhbHVlLCBSRVNFVF9JTlBVVCk7XHJcbiAgICAgICAgICBtb2RpZmllcnMucHVzaChpdGVtLmNzcywgUkVTRVRfQ1NTKTtcclxuXHJcbiAgICAgICAgICAvLyBGb3IgZXZlcnkgb3RoZXIgYXJndW1lbnQgdHlwZSwgb3V0cHV0IHRoZSB2YWx1ZSBkaXJlY3RseS5cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdmFyIGFyZyA9IGFyZ3VtZW50c1tpXTtcclxuXHJcbiAgICAgICAgICBpZiAodHlwZW9mIGFyZyA9PT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgYXJnID09PSBcImZ1bmN0aW9uXCIpIHtcclxuICAgICAgICAgICAgaW5wdXRzLnB1c2goXCIlb1wiLCBSRVNFVF9JTlBVVCk7XHJcbiAgICAgICAgICAgIG1vZGlmaWVycy5wdXNoKGFyZywgUkVTRVRfQ1NTKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlucHV0cy5wdXNoKFwiJWNcIiArIGFyZywgUkVTRVRfSU5QVVQpO1xyXG4gICAgICAgICAgICBtb2RpZmllcnMucHVzaChSRVNFVF9DU1MsIFJFU0VUX0NTUyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zb2xlRnVuY3Rpb24oaW5wdXRzLmpvaW4oXCJcIiksIC4uLm1vZGlmaWVycyk7XHJcblxyXG4gICAgICAvLyBPbmNlIHdlIG91dHB1dCB0aGUgYWdncmVnYXRlZCB2YWx1ZSwgcmVzZXQgdGhlIHF1ZXVlLiBUaGlzIHNob3VsZCBoYXZlXHJcbiAgICAgIC8vIGFscmVhZHkgYmVlbiBlbXB0aWVkIGJ5IHRoZSAuc2hpZnQoKSBjYWxsczsgYnV0IHRoZSBleHBsaWNpdCByZXNldFxyXG4gICAgICAvLyBoZXJlIGFjdHMgYXMgYm90aCBhIG1hcmtlciBvZiBpbnRlbnRpb24gYXMgd2VsbCBhcyBhIGZhaWwtc2FmZS5cclxuICAgICAgcXVldWUgPSBbXTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY29uc29sZUZ1bmN0aW9uUHJveHk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgbG9nOiB1c2luZyhjb25zb2xlLmxvZyksXHJcbiAgICB3YXJuOiB1c2luZyhjb25zb2xlLndhcm4pLFxyXG4gICAgZXJyb3I6IHVzaW5nKGNvbnNvbGUuZXJyb3IpLFxyXG4gICAgdHJhY2U6IHVzaW5nKGNvbnNvbGUudHJhY2UpLFxyXG5cclxuICAgIGFzQWxlcnQ6IGFsZXJ0Rm9ybWF0dGluZyxcclxuICAgIGFzV2FybmluZzogd2FybmluZ0Zvcm1hdHRpbmcsXHJcbiAgICBhc1RpdGxlOiB0aXRsZUZvcm1hdHRpbmcsXHJcbiAgfTtcclxufSkoKTtcclxuIiwiZXhwb3J0cy5pbnRlcm9wRGVmYXVsdCA9IGZ1bmN0aW9uIChhKSB7XG4gIHJldHVybiBhICYmIGEuX19lc01vZHVsZSA/IGEgOiB7ZGVmYXVsdDogYX07XG59O1xuXG5leHBvcnRzLmRlZmluZUludGVyb3BGbGFnID0gZnVuY3Rpb24gKGEpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGEsICdfX2VzTW9kdWxlJywge3ZhbHVlOiB0cnVlfSk7XG59O1xuXG5leHBvcnRzLmV4cG9ydEFsbCA9IGZ1bmN0aW9uIChzb3VyY2UsIGRlc3QpIHtcbiAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBpZiAoXG4gICAgICBrZXkgPT09ICdkZWZhdWx0JyB8fFxuICAgICAga2V5ID09PSAnX19lc01vZHVsZScgfHxcbiAgICAgIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkZXN0LCBrZXkpXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGtleSwge1xuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc291cmNlW2tleV07XG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICByZXR1cm4gZGVzdDtcbn07XG5cbmV4cG9ydHMuZXhwb3J0ID0gZnVuY3Rpb24gKGRlc3QsIGRlc3ROYW1lLCBnZXQpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGRlc3ROYW1lLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGdldCxcbiAgfSk7XG59O1xuIiwiaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSBcIi4vbG9nZ2VyXCI7XHJcblxyXG5leHBvcnQgY29uc3QgdmVyc2lvbiA9IFwiMS4wLjBcIjtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZXNvdXJjZSh1cmwpIHtcclxuICBsb2dnZXIubG9nKFwicmVkaXJlY3RpbmcgdG8gY29iYWx0IHdlYnNpdGUgZm9yIFwiICsgdXJsICsgXCIuLi5cIik7XHJcblxyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICB3aW5kb3cub3BlbihcImh0dHBzOi8vY29iYWx0LnRvb2xzLyNcIiArIHVybCwgXCJfYmxhbmtcIik7XHJcbiAgICByZXNvbHZlKHRydWUpO1xyXG4gIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gd2F0Y2hQYWdlKGNhbGxiYWNrKSB7XHJcbiAgbGV0IHNjaGVkdWxlZCA9IGZhbHNlO1xyXG5cclxuICBjb25zdCBvYnNlcnZlckNhbGxiYWNrID0gKCkgPT4ge1xyXG4gICAgaWYgKCFzY2hlZHVsZWQpIHtcclxuICAgICAgc2NoZWR1bGVkID0gdHJ1ZTtcclxuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcclxuICAgICAgICBjYWxsYmFjaygpO1xyXG4gICAgICAgIHNjaGVkdWxlZCA9IGZhbHNlO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKChtdXRhdGlvbnNMaXN0KSA9PiB7XHJcbiAgICBmb3IgKGNvbnN0IG11dGF0aW9uIG9mIG11dGF0aW9uc0xpc3QpIHtcclxuICAgICAgaWYgKG11dGF0aW9uLnR5cGUgPT09ICdjaGlsZExpc3QnKSB7XHJcbiAgICAgICAgb2JzZXJ2ZXJDYWxsYmFjaygpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIG9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQsIHtcclxuICAgIGNoaWxkTGlzdDogdHJ1ZSxcclxuICAgIHN1YnRyZWU6IHRydWUsXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwidmVyc2lvbiI6MywiZmlsZSI6InlvdXR1YmUuSEFTSF9SRUZfNGI5OTk4MDAyMjBiNTUxMC5qcy5tYXAifQ==
