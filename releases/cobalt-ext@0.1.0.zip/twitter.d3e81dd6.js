// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"ha9yT":[function(require,module,exports) {
var _logger = require("../common/logger");
var _utils = require("../common/utils");
(0, _logger.logger).log("Twitter detected!");
const downloadIcon = (classNames)=>{
    return `
      <svg width="24" height="24" viewBox="0 0 428 428" fill="white" stroke="white" style="width:28px;height:28px;" class="${classNames}">
        <path d="M231 94.0805C231.044 86.3486 224.812 80.0447 217.08 80.0002C209.348 79.9558 203.044 86.1877 203 93.9195L231 94.0805ZM203 93.9195L202 267.92L230 268.08L231 94.0805L203 93.9195Z" />
        <path d="M156.841 207.962C151.342 202.527 142.478 202.579 137.043 208.078C131.607 213.577 131.659 222.442 137.159 227.877L156.841 207.962ZM137.159 227.877L216.159 305.957L235.841 286.043L156.841 207.962L137.159 227.877Z" />
        <path d="M295.779 227.939C301.312 222.538 301.42 213.674 296.019 208.141C290.618 202.608 281.755 202.5 276.221 207.901L295.779 227.939ZM276.221 207.901L196.221 285.981L215.779 306.019L295.779 227.939L276.221 207.901Z" />
        <path d="M295.779 227.939C301.312 222.538 301.42 213.674 296.019 208.141C290.618 202.608 281.755 202.5 276.221 207.901L295.779 227.939ZM276.221 207.901L196.221 285.981L215.779 306.019L295.779 227.939L276.221 207.901Z" />
        <path d="M105 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M105 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M105 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M105 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M105 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M105 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M324 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M324 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M324 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M324 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M324 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M324 288.92V332.92" stroke-width="28" stroke-linecap="round"/>
        <path d="M105 333.92H324" stroke-width="28" stroke-linecap="round"/>
      </svg>
    `;
};
// You have to use the timestamp of the tweet to get the URL of the tweet for some reason
function findHomePageTweetURL(button) {
    function findTheURL(parentElement) {
        if (!parentElement || parentElement === document) return null;
        const timeElements = Array.from(parentElement.getElementsByTagName("time"));
        const timeElement = timeElements.find((time)=>time.parentElement.href?.includes("/status/"));
        if (timeElement) return timeElement.parentElement.href;
        return findTheURL(parentElement.parentElement);
    }
    return findTheURL(button.parentElement);
}
// There's a little span element inside every quote tweet that says "Quote"
function isTweetAQuoteTweet(button) {
    function findTheURL(parentElement) {
        if (!parentElement || parentElement === document) return null;
        // the highest tag in an individual tweet (even a quote tweet) is an article tag
        if (parentElement.tagName === "ARTICLE") return null;
        const spanElements = Array.from(parentElement.getElementsByTagName("span"));
        const spanElement = spanElements.find((span)=>span.innerText === "Quote");
        if (spanElement) return true;
        return findTheURL(parentElement.parentElement);
    }
    return findTheURL(button.parentElement);
}
function addDownloadButton() {
    const templateButtons = document.querySelectorAll('button[aria-label="Video Settings"]');
    templateButtons.forEach((button)=>{
        const templateButton = button.parentElement.parentElement;
        if (!templateButton.parentElement.querySelector('[cobalt-ext="twitter"]')) {
            var tweetURL = isTweetAQuoteTweet(templateButton) ? undefined : window.location.href.includes("/status/") ? window.location.href : findHomePageTweetURL(templateButton);
            const downloadButton = templateButton.cloneNode(true);
            const downloadButtonInner = downloadButton.querySelector("button");
            downloadButton.setAttribute("cobalt-ext", "twitter");
            downloadButton.querySelector("svg").parentElement.innerHTML = downloadIcon(downloadButton.querySelector("svg").classList.toString());
            downloadButtonInner.style.borderRadius = "50%";
            downloadButton.title = tweetURL ? "download with cobalt" : "cannot find the link associated to this video. if this is a quote tweet, try click on the quote itself and try again.";
            downloadButtonInner.setAttribute("aria-label", tweetURL ? "download with cobalt" : "cannot find the link associated to this video. if this is a quote tweet, try click on the quote itself and try again.");
            downloadButtonInner.style.opacity = tweetURL ? "1" : "0.5";
            downloadButtonInner.style.pointerEvents = tweetURL ? "auto" : "none";
            if (!tweetURL) downloadButtonInner.disabled = true;
            downloadButton.addEventListener("click", (e)=>{
                (0, _utils.getResource)(tweetURL);
            });
            downloadButtonInner.addEventListener("mouseover", ()=>{
                downloadButtonInner.style.backgroundColor = "rgba(255,255,255,0.1)";
            });
            // Emulate focus behavior
            downloadButtonInner.addEventListener("focus", (e)=>{
                downloadButtonInner.style.boxShadow = "rgba(255,255,255,1) 0px 0px 0px 2px";
                downloadButtonInner.style.backgroundColor = "rgba(255,255,255,0.1)";
            });
            downloadButtonInner.addEventListener("blur", ()=>{
                downloadButtonInner.style.boxShadow = "none";
                downloadButtonInner.style.backgroundColor = "transparent";
            });
            downloadButton.addEventListener("mouseout", ()=>{
                downloadButtonInner.style.backgroundColor = "transparent";
            });
            templateButton.parentElement.appendChild(downloadButton);
        }
    });
}
(0, _utils.watchPage)(addDownloadButton);

},{"../common/logger":"73tk1","../common/utils":"39Pbd"}],"73tk1":[function(require,module,exports) {
// This is a modified version of the "echo" logger concept from https://www.bennadel.com/blog/3941-styling-console-log-output-formatting-with-css.htm
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "logger", ()=>logger);
var _manifestJson = require("../manifest.json");
const logger = function() {
    var queue = [];
    var logger_TOKEN = {};
    var RESET_INPUT = "%c ";
    var RESET_CSS = "";
    function alertFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: #e0005a ; color: #ffffff ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function warningFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: gold ; color: black ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function titleFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: black ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    // I provide an logger-based proxy to the given Console Function. This uses an
    // internal queue to aggregate values before calling the given Console
    // Function with the desired formatting.
    function using(consoleFunction) {
        function consoleFunctionProxy() {
            // As we loop over the arguments, we're going to aggregate a set of
            // inputs and modifiers. The Inputs will ultimately be collapsed down
            // into a single string that acts as the first console.log parameter
            // while the modifiers are then SPREAD into console.log as 2...N.
            // --
            // NOTE: After each input/modifier pair, I'm adding a RESET pairing.
            // This implicitly resets the CSS after every formatted pairing.
            var inputs = [];
            var modifiers = [];
            // Add the cobalt-ext header
            inputs.push("%ccobalt-ext@" + (0, _manifestJson.version), RESET_INPUT);
            modifiers.push("display: inline-block; background-color: black; color: white; font-weight: bold; padding: 3px 7px; border-radius: 3px;", RESET_CSS);
            for(var i = 0; i < arguments.length; i++)// When the formatting utility methods are called, they return
            // a special token. This indicates that we should pull the
            // corresponding value out of the QUEUE instead of trying to
            // output the given argument directly.
            if (arguments[i] === logger_TOKEN) {
                var item = queue.shift();
                inputs.push("%c" + item.value, RESET_INPUT);
                modifiers.push(item.css, RESET_CSS);
            // For every other argument type, output the value directly.
            } else {
                var arg = arguments[i];
                if (typeof arg === "object" || typeof arg === "function") {
                    inputs.push("%o", RESET_INPUT);
                    modifiers.push(arg, RESET_CSS);
                } else {
                    inputs.push("%c" + arg, RESET_INPUT);
                    modifiers.push(RESET_CSS, RESET_CSS);
                }
            }
            consoleFunction(inputs.join(""), ...modifiers);
            // Once we output the aggregated value, reset the queue. This should have
            // already been emptied by the .shift() calls; but the explicit reset
            // here acts as both a marker of intention as well as a fail-safe.
            queue = [];
        }
        return consoleFunctionProxy;
    }
    return {
        log: using(console.log),
        warn: using(console.warn),
        error: using(console.error),
        trace: using(console.trace),
        asAlert: alertFormatting,
        asWarning: warningFormatting,
        asTitle: titleFormatting
    };
}();

},{"@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS","./utils.js":"39Pbd"}],"aNjyS":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"39Pbd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "getResource", ()=>getResource);
parcelHelpers.export(exports, "watchPage", ()=>watchPage);
var _logger = require("./logger");
async function getResource(url) {
    (0, _logger.logger).log("redirecting to cobalt website for " + url + "...");
    return new Promise((resolve, reject)=>{
        window.open("https://cobalt.tools/#" + url, "_blank");
        resolve(true);
    });
}
function watchPage(callback) {
    let scheduled = false;
    const observerCallback = ()=>{
        if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(()=>{
                callback();
                scheduled = false;
            });
        }
    };
    const observer = new MutationObserver((mutationsList)=>{
        for (const mutation of mutationsList)if (mutation.type === "childList") {
            observerCallback();
            break;
        }
    });
    observer.observe(document, {
        childList: true,
        subtree: true
    });
}

},{"./logger":"73tk1","@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS"}]},["ha9yT"], "ha9yT", "parcelRequirea3c5")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQSxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDO0FBRVgsTUFBTSxlQUFlLENBQUM7SUFDcEIsT0FBTyxDQUFDOzJIQUNpSCxFQUFFLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUFtQnBJLENBQUM7QUFDTDtBQUVBLHlGQUF5RjtBQUN6RixTQUFTLHFCQUFxQixNQUFNO0lBQ2xDLFNBQVMsV0FBVyxhQUFhO1FBQy9CLElBQUksQ0FBQyxpQkFBaUIsa0JBQWtCLFVBQ3RDLE9BQU87UUFHVCxNQUFNLGVBQWUsTUFBTSxJQUFJLENBQUMsY0FBYyxvQkFBb0IsQ0FBQztRQUVuRSxNQUFNLGNBQWMsYUFBYSxJQUFJLENBQUMsQ0FBQyxPQUNyQyxLQUFLLGFBQWEsQ0FBQyxJQUFJLEVBQUUsU0FBUztRQUVwQyxJQUFJLGFBQ0YsT0FBTyxZQUFZLGFBQWEsQ0FBQyxJQUFJO1FBR3ZDLE9BQU8sV0FBVyxjQUFjLGFBQWE7SUFDL0M7SUFFQSxPQUFPLFdBQVcsT0FBTyxhQUFhO0FBQ3hDO0FBRUEsMkVBQTJFO0FBQzNFLFNBQVMsbUJBQW1CLE1BQU07SUFDaEMsU0FBUyxXQUFXLGFBQWE7UUFDL0IsSUFBSSxDQUFDLGlCQUFpQixrQkFBa0IsVUFDdEMsT0FBTztRQUdULGdGQUFnRjtRQUNoRixJQUFJLGNBQWMsT0FBTyxLQUFLLFdBQzVCLE9BQU87UUFHVCxNQUFNLGVBQWUsTUFBTSxJQUFJLENBQUMsY0FBYyxvQkFBb0IsQ0FBQztRQUVuRSxNQUFNLGNBQWMsYUFBYSxJQUFJLENBQUMsQ0FBQyxPQUFTLEtBQUssU0FBUyxLQUFLO1FBQ25FLElBQUksYUFDRixPQUFPO1FBR1QsT0FBTyxXQUFXLGNBQWMsYUFBYTtJQUMvQztJQUVBLE9BQU8sV0FBVyxPQUFPLGFBQWE7QUFDeEM7QUFFQSxTQUFTO0lBQ1AsTUFBTSxrQkFBa0IsU0FBUyxnQkFBZ0IsQ0FBQztJQUVsRCxnQkFBZ0IsT0FBTyxDQUFDLENBQUM7UUFDdkIsTUFBTSxpQkFBaUIsT0FBTyxhQUFhLENBQUMsYUFBYTtRQUV6RCxJQUFJLENBQUMsZUFBZSxhQUFhLENBQUMsYUFBYSxDQUFDLDJCQUEyQjtZQUN6RSxJQUFJLFdBQVcsbUJBQW1CLGtCQUM5QixZQUNBLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsY0FDNUIsT0FBTyxRQUFRLENBQUMsSUFBSSxHQUNwQixxQkFBcUI7WUFFM0IsTUFBTSxpQkFBaUIsZUFBZSxTQUFTLENBQUM7WUFDaEQsTUFBTSxzQkFBc0IsZUFBZSxhQUFhLENBQUM7WUFFekQsZUFBZSxZQUFZLENBQUMsY0FBYztZQUMxQyxlQUFlLGFBQWEsQ0FBQyxPQUFPLGFBQWEsQ0FBQyxTQUFTLEdBQ3pELGFBQWEsZUFBZSxhQUFhLENBQUMsT0FBTyxTQUFTLENBQUMsUUFBUTtZQUNyRSxvQkFBb0IsS0FBSyxDQUFDLFlBQVksR0FBRztZQUV6QyxlQUFlLEtBQUssR0FBRyxXQUNuQix5QkFDQTtZQUVKLG9CQUFvQixZQUFZLENBQzlCLGNBQ0EsV0FDSSx5QkFDQTtZQUdOLG9CQUFvQixLQUFLLENBQUMsT0FBTyxHQUFHLFdBQVcsTUFBTTtZQUNyRCxvQkFBb0IsS0FBSyxDQUFDLGFBQWEsR0FBRyxXQUFXLFNBQVM7WUFDOUQsSUFBSSxDQUFDLFVBQVUsb0JBQW9CLFFBQVEsR0FBRztZQUU5QyxlQUFlLGdCQUFnQixDQUFDLFNBQVMsQ0FBQztnQkFDeEMsQ0FBQSxHQUFBLGtCQUFXLEFBQUQsRUFBRTtZQUNkO1lBRUEsb0JBQW9CLGdCQUFnQixDQUFDLGFBQWE7Z0JBQ2hELG9CQUFvQixLQUFLLENBQUMsZUFBZSxHQUFHO1lBQzlDO1lBRUEseUJBQXlCO1lBQ3pCLG9CQUFvQixnQkFBZ0IsQ0FBQyxTQUFTLENBQUM7Z0JBQzdDLG9CQUFvQixLQUFLLENBQUMsU0FBUyxHQUNqQztnQkFDRixvQkFBb0IsS0FBSyxDQUFDLGVBQWUsR0FBRztZQUM5QztZQUVBLG9CQUFvQixnQkFBZ0IsQ0FBQyxRQUFRO2dCQUMzQyxvQkFBb0IsS0FBSyxDQUFDLFNBQVMsR0FBRztnQkFDdEMsb0JBQW9CLEtBQUssQ0FBQyxlQUFlLEdBQUc7WUFDOUM7WUFFQSxlQUFlLGdCQUFnQixDQUFDLFlBQVk7Z0JBQzFDLG9CQUFvQixLQUFLLENBQUMsZUFBZSxHQUFHO1lBQzlDO1lBRUEsZUFBZSxhQUFhLENBQUMsV0FBVyxDQUFDO1FBQzNDO0lBQ0Y7QUFDRjtBQUVBLENBQUEsR0FBQSxnQkFBUyxBQUFELEVBQUU7OztBQzdJVixxSkFBcUo7Ozs0Q0FJeEk7QUFGYjtBQUVPLE1BQU0sU0FBUyxBQUFDO0lBQ3JCLElBQUksUUFBUSxFQUFFO0lBQ2QsSUFBSSxlQUFlLENBQUM7SUFDcEIsSUFBSSxjQUFjO0lBQ2xCLElBQUksWUFBWTtJQUVoQixTQUFTLGdCQUFnQixLQUFLO1FBQzVCLE1BQU0sSUFBSSxDQUFDO1lBQ1QsT0FBTztZQUNQLEtBQUs7UUFDUDtRQUVBLE9BQU87SUFDVDtJQUVBLFNBQVMsa0JBQWtCLEtBQUs7UUFDOUIsTUFBTSxJQUFJLENBQUM7WUFDVCxPQUFPO1lBQ1AsS0FBSztRQUNQO1FBRUEsT0FBTztJQUNUO0lBRUEsU0FBUyxnQkFBZ0IsS0FBSztRQUM1QixNQUFNLElBQUksQ0FBQztZQUNULE9BQU87WUFDUCxLQUFLO1FBQ1A7UUFFQSxPQUFPO0lBQ1Q7SUFFQSw4RUFBOEU7SUFDOUUsc0VBQXNFO0lBQ3RFLHdDQUF3QztJQUN4QyxTQUFTLE1BQU0sZUFBZTtRQUM1QixTQUFTO1lBQ1AsbUVBQW1FO1lBQ25FLHFFQUFxRTtZQUNyRSxvRUFBb0U7WUFDcEUsaUVBQWlFO1lBQ2pFLEtBQUs7WUFDTCxvRUFBb0U7WUFDcEUsZ0VBQWdFO1lBQ2hFLElBQUksU0FBUyxFQUFFO1lBQ2YsSUFBSSxZQUFZLEVBQUU7WUFFbEIsNEJBQTRCO1lBQzVCLE9BQU8sSUFBSSxDQUFDLGtCQUF1QixDQUFBLEdBQUEscUJBQU8sQUFBRCxHQUFHO1lBQzVDLFVBQVUsSUFBSSxDQUNaLDBIQUNBO1lBR0YsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsTUFBTSxFQUFFLElBQ3BDLDhEQUE4RDtZQUM5RCwwREFBMEQ7WUFDMUQsNERBQTREO1lBQzVELHNDQUFzQztZQUN0QyxJQUFJLFNBQVMsQ0FBQyxFQUFFLEtBQUssY0FBYztnQkFDakMsSUFBSSxPQUFPLE1BQU0sS0FBSztnQkFFdEIsT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLEtBQUssRUFBRTtnQkFDL0IsVUFBVSxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUU7WUFFekIsNERBQTREO1lBQzlELE9BQU87Z0JBQ0wsSUFBSSxNQUFNLFNBQVMsQ0FBQyxFQUFFO2dCQUV0QixJQUFJLE9BQU8sUUFBUSxZQUFZLE9BQU8sUUFBUSxZQUFZO29CQUN4RCxPQUFPLElBQUksQ0FBQyxNQUFNO29CQUNsQixVQUFVLElBQUksQ0FBQyxLQUFLO2dCQUN0QixPQUFPO29CQUNMLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSztvQkFDeEIsVUFBVSxJQUFJLENBQUMsV0FBVztnQkFDNUI7WUFDRjtZQUdGLGdCQUFnQixPQUFPLElBQUksQ0FBQyxRQUFRO1lBRXBDLHlFQUF5RTtZQUN6RSxxRUFBcUU7WUFDckUsa0VBQWtFO1lBQ2xFLFFBQVEsRUFBRTtRQUNaO1FBRUEsT0FBTztJQUNUO0lBRUEsT0FBTztRQUNMLEtBQUssTUFBTSxRQUFRLEdBQUc7UUFDdEIsTUFBTSxNQUFNLFFBQVEsSUFBSTtRQUN4QixPQUFPLE1BQU0sUUFBUSxLQUFLO1FBQzFCLE9BQU8sTUFBTSxRQUFRLEtBQUs7UUFFMUIsU0FBUztRQUNULFdBQVc7UUFDWCxTQUFTO0lBQ1g7QUFDRjs7O0FDekdBLFFBQVEsY0FBYyxHQUFHLFNBQVUsQ0FBQztJQUNsQyxPQUFPLEtBQUssRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUFDLFNBQVM7SUFBQztBQUM1QztBQUVBLFFBQVEsaUJBQWlCLEdBQUcsU0FBVSxDQUFDO0lBQ3JDLE9BQU8sY0FBYyxDQUFDLEdBQUcsY0FBYztRQUFDLE9BQU87SUFBSTtBQUNyRDtBQUVBLFFBQVEsU0FBUyxHQUFHLFNBQVUsTUFBTSxFQUFFLElBQUk7SUFDeEMsT0FBTyxJQUFJLENBQUMsUUFBUSxPQUFPLENBQUMsU0FBVSxHQUFHO1FBQ3ZDLElBQ0UsUUFBUSxhQUNSLFFBQVEsZ0JBQ1IsT0FBTyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLE1BRTNDO1FBR0YsT0FBTyxjQUFjLENBQUMsTUFBTSxLQUFLO1lBQy9CLFlBQVk7WUFDWixLQUFLO2dCQUNILE9BQU8sTUFBTSxDQUFDLElBQUk7WUFDcEI7UUFDRjtJQUNGO0lBRUEsT0FBTztBQUNUO0FBRUEsUUFBUSxNQUFNLEdBQUcsU0FBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFDNUMsT0FBTyxjQUFjLENBQUMsTUFBTSxVQUFVO1FBQ3BDLFlBQVk7UUFDWixLQUFLO0lBQ1A7QUFDRjs7Ozs7QUNoQ0EsaURBQXNCO0FBU3RCLCtDQUFnQjtBQVhoQjtBQUVPLGVBQWUsWUFBWSxHQUFHO0lBQ25DLENBQUEsR0FBQSxjQUFNLEFBQUQsRUFBRSxHQUFHLENBQUMsdUNBQXVDLE1BQU07SUFFeEQsT0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTO1FBQzNCLE9BQU8sSUFBSSxDQUFDLDJCQUEyQixLQUFLO1FBQzVDLFFBQVE7SUFDVjtBQUNGO0FBRU8sU0FBUyxVQUFVLFFBQVE7SUFDaEMsSUFBSSxZQUFZO0lBRWhCLE1BQU0sbUJBQW1CO1FBQ3ZCLElBQUksQ0FBQyxXQUFXO1lBQ2QsWUFBWTtZQUNaLHNCQUFzQjtnQkFDcEI7Z0JBQ0EsWUFBWTtZQUNkO1FBQ0Y7SUFDRjtJQUVBLE1BQU0sV0FBVyxJQUFJLGlCQUFpQixDQUFDO1FBQ3JDLEtBQUssTUFBTSxZQUFZLGNBQ3JCLElBQUksU0FBUyxJQUFJLEtBQUssYUFBYTtZQUNqQztZQUNBO1FBQ0Y7SUFFSjtJQUVBLFNBQVMsT0FBTyxDQUFDLFVBQVU7UUFDekIsV0FBVztRQUNYLFNBQVM7SUFDWDtBQUNGIiwic291cmNlcyI6WyJzcmMvc2VydmljZXMvdHdpdHRlci5qcyIsInNyYy9jb21tb24vbG9nZ2VyLmpzIiwibm9kZV9tb2R1bGVzL0BwYXJjZWwvY29uZmlnLXdlYmV4dGVuc2lvbi9ub2RlX21vZHVsZXMvQHBhcmNlbC90cmFuc2Zvcm1lci1qcy9zcmMvZXNtb2R1bGUtaGVscGVycy5qcyIsInNyYy9jb21tb24vdXRpbHMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSBcIi4uL2NvbW1vbi9sb2dnZXJcIjtcclxuaW1wb3J0IHsgZ2V0UmVzb3VyY2UsIHdhdGNoUGFnZSB9IGZyb20gXCIuLi9jb21tb24vdXRpbHNcIjtcclxuXHJcbmxvZ2dlci5sb2coXCJUd2l0dGVyIGRldGVjdGVkIVwiKTtcclxuXHJcbmNvbnN0IGRvd25sb2FkSWNvbiA9IChjbGFzc05hbWVzKSA9PiB7XHJcbiAgcmV0dXJuIGBcclxuICAgICAgPHN2ZyB3aWR0aD1cIjI0XCIgaGVpZ2h0PVwiMjRcIiB2aWV3Qm94PVwiMCAwIDQyOCA0MjhcIiBmaWxsPVwid2hpdGVcIiBzdHJva2U9XCJ3aGl0ZVwiIHN0eWxlPVwid2lkdGg6MjhweDtoZWlnaHQ6MjhweDtcIiBjbGFzcz1cIiR7Y2xhc3NOYW1lc31cIj5cclxuICAgICAgICA8cGF0aCBkPVwiTTIzMSA5NC4wODA1QzIzMS4wNDQgODYuMzQ4NiAyMjQuODEyIDgwLjA0NDcgMjE3LjA4IDgwLjAwMDJDMjA5LjM0OCA3OS45NTU4IDIwMy4wNDQgODYuMTg3NyAyMDMgOTMuOTE5NUwyMzEgOTQuMDgwNVpNMjAzIDkzLjkxOTVMMjAyIDI2Ny45MkwyMzAgMjY4LjA4TDIzMSA5NC4wODA1TDIwMyA5My45MTk1WlwiIC8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0xNTYuODQxIDIwNy45NjJDMTUxLjM0MiAyMDIuNTI3IDE0Mi40NzggMjAyLjU3OSAxMzcuMDQzIDIwOC4wNzhDMTMxLjYwNyAyMTMuNTc3IDEzMS42NTkgMjIyLjQ0MiAxMzcuMTU5IDIyNy44NzdMMTU2Ljg0MSAyMDcuOTYyWk0xMzcuMTU5IDIyNy44NzdMMjE2LjE1OSAzMDUuOTU3TDIzNS44NDEgMjg2LjA0M0wxNTYuODQxIDIwNy45NjJMMTM3LjE1OSAyMjcuODc3WlwiIC8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0yOTUuNzc5IDIyNy45MzlDMzAxLjMxMiAyMjIuNTM4IDMwMS40MiAyMTMuNjc0IDI5Ni4wMTkgMjA4LjE0MUMyOTAuNjE4IDIwMi42MDggMjgxLjc1NSAyMDIuNSAyNzYuMjIxIDIwNy45MDFMMjk1Ljc3OSAyMjcuOTM5Wk0yNzYuMjIxIDIwNy45MDFMMTk2LjIyMSAyODUuOTgxTDIxNS43NzkgMzA2LjAxOUwyOTUuNzc5IDIyNy45MzlMMjc2LjIyMSAyMDcuOTAxWlwiIC8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0yOTUuNzc5IDIyNy45MzlDMzAxLjMxMiAyMjIuNTM4IDMwMS40MiAyMTMuNjc0IDI5Ni4wMTkgMjA4LjE0MUMyOTAuNjE4IDIwMi42MDggMjgxLjc1NSAyMDIuNSAyNzYuMjIxIDIwNy45MDFMMjk1Ljc3OSAyMjcuOTM5Wk0yNzYuMjIxIDIwNy45MDFMMTk2LjIyMSAyODUuOTgxTDIxNS43NzkgMzA2LjAxOUwyOTUuNzc5IDIyNy45MzlMMjc2LjIyMSAyMDcuOTAxWlwiIC8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0xMDUgMjg4LjkyVjMzMi45MlwiIHN0cm9rZS13aWR0aD1cIjI4XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiLz5cclxuICAgICAgICA8cGF0aCBkPVwiTTEwNSAyODguOTJWMzMyLjkyXCIgc3Ryb2tlLXdpZHRoPVwiMjhcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDxwYXRoIGQ9XCJNMTA1IDI4OC45MlYzMzIuOTJcIiBzdHJva2Utd2lkdGg9XCIyOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIi8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0xMDUgMjg4LjkyVjMzMi45MlwiIHN0cm9rZS13aWR0aD1cIjI4XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiLz5cclxuICAgICAgICA8cGF0aCBkPVwiTTEwNSAyODguOTJWMzMyLjkyXCIgc3Ryb2tlLXdpZHRoPVwiMjhcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDxwYXRoIGQ9XCJNMTA1IDI4OC45MlYzMzIuOTJcIiBzdHJva2Utd2lkdGg9XCIyOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIi8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0zMjQgMjg4LjkyVjMzMi45MlwiIHN0cm9rZS13aWR0aD1cIjI4XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiLz5cclxuICAgICAgICA8cGF0aCBkPVwiTTMyNCAyODguOTJWMzMyLjkyXCIgc3Ryb2tlLXdpZHRoPVwiMjhcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDxwYXRoIGQ9XCJNMzI0IDI4OC45MlYzMzIuOTJcIiBzdHJva2Utd2lkdGg9XCIyOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIi8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0zMjQgMjg4LjkyVjMzMi45MlwiIHN0cm9rZS13aWR0aD1cIjI4XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiLz5cclxuICAgICAgICA8cGF0aCBkPVwiTTMyNCAyODguOTJWMzMyLjkyXCIgc3Ryb2tlLXdpZHRoPVwiMjhcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIvPlxyXG4gICAgICAgIDxwYXRoIGQ9XCJNMzI0IDI4OC45MlYzMzIuOTJcIiBzdHJva2Utd2lkdGg9XCIyOFwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIi8+XHJcbiAgICAgICAgPHBhdGggZD1cIk0xMDUgMzMzLjkySDMyNFwiIHN0cm9rZS13aWR0aD1cIjI4XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiLz5cclxuICAgICAgPC9zdmc+XHJcbiAgICBgO1xyXG59O1xyXG5cclxuLy8gWW91IGhhdmUgdG8gdXNlIHRoZSB0aW1lc3RhbXAgb2YgdGhlIHR3ZWV0IHRvIGdldCB0aGUgVVJMIG9mIHRoZSB0d2VldCBmb3Igc29tZSByZWFzb25cclxuZnVuY3Rpb24gZmluZEhvbWVQYWdlVHdlZXRVUkwoYnV0dG9uKSB7XHJcbiAgZnVuY3Rpb24gZmluZFRoZVVSTChwYXJlbnRFbGVtZW50KSB7XHJcbiAgICBpZiAoIXBhcmVudEVsZW1lbnQgfHwgcGFyZW50RWxlbWVudCA9PT0gZG9jdW1lbnQpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgdGltZUVsZW1lbnRzID0gQXJyYXkuZnJvbShwYXJlbnRFbGVtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwidGltZVwiKSk7XHJcblxyXG4gICAgY29uc3QgdGltZUVsZW1lbnQgPSB0aW1lRWxlbWVudHMuZmluZCgodGltZSkgPT5cclxuICAgICAgdGltZS5wYXJlbnRFbGVtZW50LmhyZWY/LmluY2x1ZGVzKFwiL3N0YXR1cy9cIilcclxuICAgICk7XHJcbiAgICBpZiAodGltZUVsZW1lbnQpIHtcclxuICAgICAgcmV0dXJuIHRpbWVFbGVtZW50LnBhcmVudEVsZW1lbnQuaHJlZjtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gZmluZFRoZVVSTChwYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGZpbmRUaGVVUkwoYnV0dG9uLnBhcmVudEVsZW1lbnQpO1xyXG59XHJcblxyXG4vLyBUaGVyZSdzIGEgbGl0dGxlIHNwYW4gZWxlbWVudCBpbnNpZGUgZXZlcnkgcXVvdGUgdHdlZXQgdGhhdCBzYXlzIFwiUXVvdGVcIlxyXG5mdW5jdGlvbiBpc1R3ZWV0QVF1b3RlVHdlZXQoYnV0dG9uKSB7XHJcbiAgZnVuY3Rpb24gZmluZFRoZVVSTChwYXJlbnRFbGVtZW50KSB7XHJcbiAgICBpZiAoIXBhcmVudEVsZW1lbnQgfHwgcGFyZW50RWxlbWVudCA9PT0gZG9jdW1lbnQpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gdGhlIGhpZ2hlc3QgdGFnIGluIGFuIGluZGl2aWR1YWwgdHdlZXQgKGV2ZW4gYSBxdW90ZSB0d2VldCkgaXMgYW4gYXJ0aWNsZSB0YWdcclxuICAgIGlmIChwYXJlbnRFbGVtZW50LnRhZ05hbWUgPT09IFwiQVJUSUNMRVwiKSB7XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHNwYW5FbGVtZW50cyA9IEFycmF5LmZyb20ocGFyZW50RWxlbWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcInNwYW5cIikpO1xyXG5cclxuICAgIGNvbnN0IHNwYW5FbGVtZW50ID0gc3BhbkVsZW1lbnRzLmZpbmQoKHNwYW4pID0+IHNwYW4uaW5uZXJUZXh0ID09PSBcIlF1b3RlXCIpO1xyXG4gICAgaWYgKHNwYW5FbGVtZW50KSB7XHJcbiAgICAgIHJldHVybiB0cnVlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBmaW5kVGhlVVJMKHBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZmluZFRoZVVSTChidXR0b24ucGFyZW50RWxlbWVudCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFkZERvd25sb2FkQnV0dG9uKCkge1xyXG4gIGNvbnN0IHRlbXBsYXRlQnV0dG9ucyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJidXR0b25bYXJpYS1sYWJlbD1cXFwiVmlkZW8gU2V0dGluZ3NcXFwiXVwiKTtcclxuXHJcbiAgdGVtcGxhdGVCdXR0b25zLmZvckVhY2goKGJ1dHRvbikgPT4ge1xyXG4gICAgY29uc3QgdGVtcGxhdGVCdXR0b24gPSBidXR0b24ucGFyZW50RWxlbWVudC5wYXJlbnRFbGVtZW50O1xyXG5cclxuICAgIGlmICghdGVtcGxhdGVCdXR0b24ucGFyZW50RWxlbWVudC5xdWVyeVNlbGVjdG9yKCdbY29iYWx0LWV4dD1cInR3aXR0ZXJcIl0nKSkge1xyXG4gICAgICB2YXIgdHdlZXRVUkwgPSBpc1R3ZWV0QVF1b3RlVHdlZXQodGVtcGxhdGVCdXR0b24pXHJcbiAgICAgICAgPyB1bmRlZmluZWRcclxuICAgICAgICA6IHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluY2x1ZGVzKFwiL3N0YXR1cy9cIilcclxuICAgICAgICAgID8gd2luZG93LmxvY2F0aW9uLmhyZWZcclxuICAgICAgICAgIDogZmluZEhvbWVQYWdlVHdlZXRVUkwodGVtcGxhdGVCdXR0b24pO1xyXG5cclxuICAgICAgY29uc3QgZG93bmxvYWRCdXR0b24gPSB0ZW1wbGF0ZUJ1dHRvbi5jbG9uZU5vZGUodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IGRvd25sb2FkQnV0dG9uSW5uZXIgPSBkb3dubG9hZEJ1dHRvbi5xdWVyeVNlbGVjdG9yKFwiYnV0dG9uXCIpO1xyXG5cclxuICAgICAgZG93bmxvYWRCdXR0b24uc2V0QXR0cmlidXRlKFwiY29iYWx0LWV4dFwiLCBcInR3aXR0ZXJcIik7XHJcbiAgICAgIGRvd25sb2FkQnV0dG9uLnF1ZXJ5U2VsZWN0b3IoXCJzdmdcIikucGFyZW50RWxlbWVudC5pbm5lckhUTUwgPVxyXG4gICAgICAgIGRvd25sb2FkSWNvbihkb3dubG9hZEJ1dHRvbi5xdWVyeVNlbGVjdG9yKFwic3ZnXCIpLmNsYXNzTGlzdC50b1N0cmluZygpKTtcclxuICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zdHlsZS5ib3JkZXJSYWRpdXMgPSBcIjUwJVwiO1xyXG5cclxuICAgICAgZG93bmxvYWRCdXR0b24udGl0bGUgPSB0d2VldFVSTFxyXG4gICAgICAgID8gXCJkb3dubG9hZCB3aXRoIGNvYmFsdFwiXHJcbiAgICAgICAgOiBcImNhbm5vdCBmaW5kIHRoZSBsaW5rIGFzc29jaWF0ZWQgdG8gdGhpcyB2aWRlby4gaWYgdGhpcyBpcyBhIHF1b3RlIHR3ZWV0LCB0cnkgY2xpY2sgb24gdGhlIHF1b3RlIGl0c2VsZiBhbmQgdHJ5IGFnYWluLlwiO1xyXG5cclxuICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zZXRBdHRyaWJ1dGUoXHJcbiAgICAgICAgXCJhcmlhLWxhYmVsXCIsXHJcbiAgICAgICAgdHdlZXRVUkxcclxuICAgICAgICAgID8gXCJkb3dubG9hZCB3aXRoIGNvYmFsdFwiXHJcbiAgICAgICAgICA6IFwiY2Fubm90IGZpbmQgdGhlIGxpbmsgYXNzb2NpYXRlZCB0byB0aGlzIHZpZGVvLiBpZiB0aGlzIGlzIGEgcXVvdGUgdHdlZXQsIHRyeSBjbGljayBvbiB0aGUgcXVvdGUgaXRzZWxmIGFuZCB0cnkgYWdhaW4uXCJcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuc3R5bGUub3BhY2l0eSA9IHR3ZWV0VVJMID8gXCIxXCIgOiBcIjAuNVwiO1xyXG4gICAgICBkb3dubG9hZEJ1dHRvbklubmVyLnN0eWxlLnBvaW50ZXJFdmVudHMgPSB0d2VldFVSTCA/IFwiYXV0b1wiIDogXCJub25lXCI7XHJcbiAgICAgIGlmICghdHdlZXRVUkwpIGRvd25sb2FkQnV0dG9uSW5uZXIuZGlzYWJsZWQgPSB0cnVlO1xyXG5cclxuICAgICAgZG93bmxvYWRCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChlKSA9PiB7XHJcbiAgICAgICAgZ2V0UmVzb3VyY2UodHdlZXRVUkwpO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3ZlclwiLCAoKSA9PiB7XHJcbiAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcInJnYmEoMjU1LDI1NSwyNTUsMC4xKVwiO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIEVtdWxhdGUgZm9jdXMgYmVoYXZpb3JcclxuICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNcIiwgKGUpID0+IHtcclxuICAgICAgICBkb3dubG9hZEJ1dHRvbklubmVyLnN0eWxlLmJveFNoYWRvdyA9XHJcbiAgICAgICAgICBcInJnYmEoMjU1LDI1NSwyNTUsMSkgMHB4IDBweCAwcHggMnB4XCI7XHJcbiAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcInJnYmEoMjU1LDI1NSwyNTUsMC4xKVwiO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuYWRkRXZlbnRMaXN0ZW5lcihcImJsdXJcIiwgKCkgPT4ge1xyXG4gICAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuc3R5bGUuYm94U2hhZG93ID0gXCJub25lXCI7XHJcbiAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcInRyYW5zcGFyZW50XCI7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgZG93bmxvYWRCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3V0XCIsICgpID0+IHtcclxuICAgICAgICBkb3dubG9hZEJ1dHRvbklubmVyLnN0eWxlLmJhY2tncm91bmRDb2xvciA9IFwidHJhbnNwYXJlbnRcIjtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICB0ZW1wbGF0ZUJ1dHRvbi5wYXJlbnRFbGVtZW50LmFwcGVuZENoaWxkKGRvd25sb2FkQnV0dG9uKTtcclxuICAgIH1cclxuICB9KTtcclxufVxyXG5cclxud2F0Y2hQYWdlKGFkZERvd25sb2FkQnV0dG9uKTsiLCIvLyBUaGlzIGlzIGEgbW9kaWZpZWQgdmVyc2lvbiBvZiB0aGUgXCJlY2hvXCIgbG9nZ2VyIGNvbmNlcHQgZnJvbSBodHRwczovL3d3dy5iZW5uYWRlbC5jb20vYmxvZy8zOTQxLXN0eWxpbmctY29uc29sZS1sb2ctb3V0cHV0LWZvcm1hdHRpbmctd2l0aC1jc3MuaHRtXHJcblxyXG5pbXBvcnQgeyB2ZXJzaW9uIH0gZnJvbSBcIi4uL21hbmlmZXN0Lmpzb25cIjtcclxuXHJcbmV4cG9ydCBjb25zdCBsb2dnZXIgPSAoZnVuY3Rpb24gKCkge1xyXG4gIHZhciBxdWV1ZSA9IFtdO1xyXG4gIHZhciBsb2dnZXJfVE9LRU4gPSB7fTtcclxuICB2YXIgUkVTRVRfSU5QVVQgPSBcIiVjIFwiO1xyXG4gIHZhciBSRVNFVF9DU1MgPSBcIlwiO1xyXG5cclxuICBmdW5jdGlvbiBhbGVydEZvcm1hdHRpbmcodmFsdWUpIHtcclxuICAgIHF1ZXVlLnB1c2goe1xyXG4gICAgICB2YWx1ZTogdmFsdWUsXHJcbiAgICAgIGNzczogXCJkaXNwbGF5OiBpbmxpbmUtYmxvY2sgOyBiYWNrZ3JvdW5kLWNvbG9yOiAjZTAwMDVhIDsgY29sb3I6ICNmZmZmZmYgOyBmb250LXdlaWdodDogYm9sZCA7IHBhZGRpbmc6IDNweCA3cHggM3B4IDdweCA7IGJvcmRlci1yYWRpdXM6IDNweCAzcHggM3B4IDNweCA7XCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9nZ2VyX1RPS0VOO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gd2FybmluZ0Zvcm1hdHRpbmcodmFsdWUpIHtcclxuICAgIHF1ZXVlLnB1c2goe1xyXG4gICAgICB2YWx1ZTogdmFsdWUsXHJcbiAgICAgIGNzczogXCJkaXNwbGF5OiBpbmxpbmUtYmxvY2sgOyBiYWNrZ3JvdW5kLWNvbG9yOiBnb2xkIDsgY29sb3I6IGJsYWNrIDsgZm9udC13ZWlnaHQ6IGJvbGQgOyBwYWRkaW5nOiAzcHggN3B4IDNweCA3cHggOyBib3JkZXItcmFkaXVzOiAzcHggM3B4IDNweCAzcHggO1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGxvZ2dlcl9UT0tFTjtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHRpdGxlRm9ybWF0dGluZyh2YWx1ZSkge1xyXG4gICAgcXVldWUucHVzaCh7XHJcbiAgICAgIHZhbHVlOiB2YWx1ZSxcclxuICAgICAgY3NzOiBcImRpc3BsYXk6IGlubGluZS1ibG9jayA7IGJhY2tncm91bmQtY29sb3I6IGJsYWNrIDsgY29sb3I6IHdoaXRlIDsgZm9udC13ZWlnaHQ6IGJvbGQgOyBwYWRkaW5nOiAzcHggN3B4IDNweCA3cHggOyBib3JkZXItcmFkaXVzOiAzcHggM3B4IDNweCAzcHggO1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGxvZ2dlcl9UT0tFTjtcclxuICB9XHJcblxyXG4gIC8vIEkgcHJvdmlkZSBhbiBsb2dnZXItYmFzZWQgcHJveHkgdG8gdGhlIGdpdmVuIENvbnNvbGUgRnVuY3Rpb24uIFRoaXMgdXNlcyBhblxyXG4gIC8vIGludGVybmFsIHF1ZXVlIHRvIGFnZ3JlZ2F0ZSB2YWx1ZXMgYmVmb3JlIGNhbGxpbmcgdGhlIGdpdmVuIENvbnNvbGVcclxuICAvLyBGdW5jdGlvbiB3aXRoIHRoZSBkZXNpcmVkIGZvcm1hdHRpbmcuXHJcbiAgZnVuY3Rpb24gdXNpbmcoY29uc29sZUZ1bmN0aW9uKSB7XHJcbiAgICBmdW5jdGlvbiBjb25zb2xlRnVuY3Rpb25Qcm94eSgpIHtcclxuICAgICAgLy8gQXMgd2UgbG9vcCBvdmVyIHRoZSBhcmd1bWVudHMsIHdlJ3JlIGdvaW5nIHRvIGFnZ3JlZ2F0ZSBhIHNldCBvZlxyXG4gICAgICAvLyBpbnB1dHMgYW5kIG1vZGlmaWVycy4gVGhlIElucHV0cyB3aWxsIHVsdGltYXRlbHkgYmUgY29sbGFwc2VkIGRvd25cclxuICAgICAgLy8gaW50byBhIHNpbmdsZSBzdHJpbmcgdGhhdCBhY3RzIGFzIHRoZSBmaXJzdCBjb25zb2xlLmxvZyBwYXJhbWV0ZXJcclxuICAgICAgLy8gd2hpbGUgdGhlIG1vZGlmaWVycyBhcmUgdGhlbiBTUFJFQUQgaW50byBjb25zb2xlLmxvZyBhcyAyLi4uTi5cclxuICAgICAgLy8gLS1cclxuICAgICAgLy8gTk9URTogQWZ0ZXIgZWFjaCBpbnB1dC9tb2RpZmllciBwYWlyLCBJJ20gYWRkaW5nIGEgUkVTRVQgcGFpcmluZy5cclxuICAgICAgLy8gVGhpcyBpbXBsaWNpdGx5IHJlc2V0cyB0aGUgQ1NTIGFmdGVyIGV2ZXJ5IGZvcm1hdHRlZCBwYWlyaW5nLlxyXG4gICAgICB2YXIgaW5wdXRzID0gW107XHJcbiAgICAgIHZhciBtb2RpZmllcnMgPSBbXTtcclxuXHJcbiAgICAgIC8vIEFkZCB0aGUgY29iYWx0LWV4dCBoZWFkZXJcclxuICAgICAgaW5wdXRzLnB1c2goXCIlY1wiICsgXCJjb2JhbHQtZXh0QFwiICsgdmVyc2lvbiwgUkVTRVRfSU5QVVQpO1xyXG4gICAgICBtb2RpZmllcnMucHVzaChcclxuICAgICAgICBcImRpc3BsYXk6IGlubGluZS1ibG9jazsgYmFja2dyb3VuZC1jb2xvcjogYmxhY2s7IGNvbG9yOiB3aGl0ZTsgZm9udC13ZWlnaHQ6IGJvbGQ7IHBhZGRpbmc6IDNweCA3cHg7IGJvcmRlci1yYWRpdXM6IDNweDtcIixcclxuICAgICAgICBSRVNFVF9DU1NcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgLy8gV2hlbiB0aGUgZm9ybWF0dGluZyB1dGlsaXR5IG1ldGhvZHMgYXJlIGNhbGxlZCwgdGhleSByZXR1cm5cclxuICAgICAgICAvLyBhIHNwZWNpYWwgdG9rZW4uIFRoaXMgaW5kaWNhdGVzIHRoYXQgd2Ugc2hvdWxkIHB1bGwgdGhlXHJcbiAgICAgICAgLy8gY29ycmVzcG9uZGluZyB2YWx1ZSBvdXQgb2YgdGhlIFFVRVVFIGluc3RlYWQgb2YgdHJ5aW5nIHRvXHJcbiAgICAgICAgLy8gb3V0cHV0IHRoZSBnaXZlbiBhcmd1bWVudCBkaXJlY3RseS5cclxuICAgICAgICBpZiAoYXJndW1lbnRzW2ldID09PSBsb2dnZXJfVE9LRU4pIHtcclxuICAgICAgICAgIHZhciBpdGVtID0gcXVldWUuc2hpZnQoKTtcclxuXHJcbiAgICAgICAgICBpbnB1dHMucHVzaChcIiVjXCIgKyBpdGVtLnZhbHVlLCBSRVNFVF9JTlBVVCk7XHJcbiAgICAgICAgICBtb2RpZmllcnMucHVzaChpdGVtLmNzcywgUkVTRVRfQ1NTKTtcclxuXHJcbiAgICAgICAgICAvLyBGb3IgZXZlcnkgb3RoZXIgYXJndW1lbnQgdHlwZSwgb3V0cHV0IHRoZSB2YWx1ZSBkaXJlY3RseS5cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdmFyIGFyZyA9IGFyZ3VtZW50c1tpXTtcclxuXHJcbiAgICAgICAgICBpZiAodHlwZW9mIGFyZyA9PT0gXCJvYmplY3RcIiB8fCB0eXBlb2YgYXJnID09PSBcImZ1bmN0aW9uXCIpIHtcclxuICAgICAgICAgICAgaW5wdXRzLnB1c2goXCIlb1wiLCBSRVNFVF9JTlBVVCk7XHJcbiAgICAgICAgICAgIG1vZGlmaWVycy5wdXNoKGFyZywgUkVTRVRfQ1NTKTtcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIGlucHV0cy5wdXNoKFwiJWNcIiArIGFyZywgUkVTRVRfSU5QVVQpO1xyXG4gICAgICAgICAgICBtb2RpZmllcnMucHVzaChSRVNFVF9DU1MsIFJFU0VUX0NTUyk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zb2xlRnVuY3Rpb24oaW5wdXRzLmpvaW4oXCJcIiksIC4uLm1vZGlmaWVycyk7XHJcblxyXG4gICAgICAvLyBPbmNlIHdlIG91dHB1dCB0aGUgYWdncmVnYXRlZCB2YWx1ZSwgcmVzZXQgdGhlIHF1ZXVlLiBUaGlzIHNob3VsZCBoYXZlXHJcbiAgICAgIC8vIGFscmVhZHkgYmVlbiBlbXB0aWVkIGJ5IHRoZSAuc2hpZnQoKSBjYWxsczsgYnV0IHRoZSBleHBsaWNpdCByZXNldFxyXG4gICAgICAvLyBoZXJlIGFjdHMgYXMgYm90aCBhIG1hcmtlciBvZiBpbnRlbnRpb24gYXMgd2VsbCBhcyBhIGZhaWwtc2FmZS5cclxuICAgICAgcXVldWUgPSBbXTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gY29uc29sZUZ1bmN0aW9uUHJveHk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4ge1xyXG4gICAgbG9nOiB1c2luZyhjb25zb2xlLmxvZyksXHJcbiAgICB3YXJuOiB1c2luZyhjb25zb2xlLndhcm4pLFxyXG4gICAgZXJyb3I6IHVzaW5nKGNvbnNvbGUuZXJyb3IpLFxyXG4gICAgdHJhY2U6IHVzaW5nKGNvbnNvbGUudHJhY2UpLFxyXG5cclxuICAgIGFzQWxlcnQ6IGFsZXJ0Rm9ybWF0dGluZyxcclxuICAgIGFzV2FybmluZzogd2FybmluZ0Zvcm1hdHRpbmcsXHJcbiAgICBhc1RpdGxlOiB0aXRsZUZvcm1hdHRpbmcsXHJcbiAgfTtcclxufSkoKTtcclxuIiwiZXhwb3J0cy5pbnRlcm9wRGVmYXVsdCA9IGZ1bmN0aW9uIChhKSB7XG4gIHJldHVybiBhICYmIGEuX19lc01vZHVsZSA/IGEgOiB7ZGVmYXVsdDogYX07XG59O1xuXG5leHBvcnRzLmRlZmluZUludGVyb3BGbGFnID0gZnVuY3Rpb24gKGEpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGEsICdfX2VzTW9kdWxlJywge3ZhbHVlOiB0cnVlfSk7XG59O1xuXG5leHBvcnRzLmV4cG9ydEFsbCA9IGZ1bmN0aW9uIChzb3VyY2UsIGRlc3QpIHtcbiAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBpZiAoXG4gICAgICBrZXkgPT09ICdkZWZhdWx0JyB8fFxuICAgICAga2V5ID09PSAnX19lc01vZHVsZScgfHxcbiAgICAgIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkZXN0LCBrZXkpXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGtleSwge1xuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc291cmNlW2tleV07XG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICByZXR1cm4gZGVzdDtcbn07XG5cbmV4cG9ydHMuZXhwb3J0ID0gZnVuY3Rpb24gKGRlc3QsIGRlc3ROYW1lLCBnZXQpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGRlc3ROYW1lLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGdldCxcbiAgfSk7XG59O1xuIiwiaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSBcIi4vbG9nZ2VyXCI7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVzb3VyY2UodXJsKSB7XHJcbiAgbG9nZ2VyLmxvZyhcInJlZGlyZWN0aW5nIHRvIGNvYmFsdCB3ZWJzaXRlIGZvciBcIiArIHVybCArIFwiLi4uXCIpO1xyXG5cclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgd2luZG93Lm9wZW4oXCJodHRwczovL2NvYmFsdC50b29scy8jXCIgKyB1cmwsIFwiX2JsYW5rXCIpO1xyXG4gICAgcmVzb2x2ZSh0cnVlKTtcclxuICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHdhdGNoUGFnZShjYWxsYmFjaykge1xyXG4gIGxldCBzY2hlZHVsZWQgPSBmYWxzZTtcclxuXHJcbiAgY29uc3Qgb2JzZXJ2ZXJDYWxsYmFjayA9ICgpID0+IHtcclxuICAgIGlmICghc2NoZWR1bGVkKSB7XHJcbiAgICAgIHNjaGVkdWxlZCA9IHRydWU7XHJcbiAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XHJcbiAgICAgICAgY2FsbGJhY2soKTtcclxuICAgICAgICBzY2hlZHVsZWQgPSBmYWxzZTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigobXV0YXRpb25zTGlzdCkgPT4ge1xyXG4gICAgZm9yIChjb25zdCBtdXRhdGlvbiBvZiBtdXRhdGlvbnNMaXN0KSB7XHJcbiAgICAgIGlmIChtdXRhdGlvbi50eXBlID09PSAnY2hpbGRMaXN0Jykge1xyXG4gICAgICAgIG9ic2VydmVyQ2FsbGJhY2soKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LCB7XHJcbiAgICBjaGlsZExpc3Q6IHRydWUsXHJcbiAgICBzdWJ0cmVlOiB0cnVlLFxyXG4gIH0pO1xyXG59XHJcbiJdLCJuYW1lcyI6W10sInZlcnNpb24iOjMsImZpbGUiOiJ0d2l0dGVyLkhBU0hfUkVGXzA4ZjBiNTc5YWMyNTFjN2YuanMubWFwIn0=
