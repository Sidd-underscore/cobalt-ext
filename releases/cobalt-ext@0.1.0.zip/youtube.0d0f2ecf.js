// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"1dmY8":[function(require,module,exports) {
var _logger = require("../common/logger");
var _utils = require("../common/utils");
(0, _logger.logger).log("YouTube detected!");
const downloadIcon = (classNames)=>{
    // Use the meta theme color to determine if the user is using dark mode
    var isDarkMode = document.head.querySelector('meta[name="theme-color"]').getAttribute("content") != "rgba(255, 255, 255, 0.98)";
    return `
    <svg viewBox="0 0 48 48" class="${classNames}">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M38 44H10V42H38V44Z" fill="${isDarkMode ? "white" : "black"}" fill-rule="evenodd" clip-rule="evenodd"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M23 34.5V4.5H25V34.5H23Z" fill="${isDarkMode ? "white" : "black"}" fill-rule="evenodd" clip-rule="evenodd"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M24 35.4142L10.5858 22L12 20.5858L24 32.5858L36 20.5858L37.4142 22L24 35.4142Z" fill="${isDarkMode ? "white" : "black"}" fill-rule="evenodd" clip-rule="evenodd"></path>
    </svg>
    `;
};
function addDownloadButton() {
    const isLiveVideo = document.querySelector('[should-stamp-chat=""]');
    const isShortsVideo = window.location.href.includes("/shorts/");
    if (!isLiveVideo) {
        if (!isShortsVideo) {
            var toolBar = document.querySelector("ytd-watch-flexy #top-level-buttons-computed");
            if (toolBar) {
                // Get a template, normal button (usually the share button) and the we clone it and modify it to our liking
                const templateButton = toolBar.querySelector('yt-button-view-model button-view-model button[aria-label="Share"]').parentElement.parentElement;
                if (!templateButton.parentElement.querySelector('[cobalt-ext="youtube"]')) {
                    const downloadButton = templateButton.cloneNode(true);
                    console.log(downloadButton);
                    const downloadButtonInner = downloadButton.querySelector("button");
                    toolBar.insertAdjacentElement("beforeend", downloadButton);
                    downloadButton.setAttribute("cobalt-ext", "youtube");
                    downloadButton.querySelector("yt-icon").parentElement.innerHTML = downloadIcon(downloadButton.querySelector("yt-icon").classList.toString());
                    downloadButtonInner.title = "download with cobalt";
                    downloadButtonInner.setAttribute("aria-label", "download with cobalt");
                    downloadButton.querySelector(".yt-spec-button-shape-next__button-text-content").textContent = "Download";
                    const styles = document.createElement("style");
                    styles.innerHTML = `
            @media screen and (max-width: 1448px) {
              [cobalt-ext="youtube"] .yt-spec-button-shape-next__button-text-content {
                  display: none;
              }

              [cobalt-ext="youtube"] .yt-spec-button-shape-next__icon {
                  margin: -6px !important;
              }
            }`;
                    document.head.appendChild(styles);
                    toolBar.insertAdjacentElement("beforeend", downloadButton);
                    // Let YouTube compute the overflow menu
                    document.dispatchEvent(new Event("yt-rendererstamper-finished"));
                    document.dispatchEvent(new Event("yt-renderidom-finished"));
                    document.dispatchEvent(new Event("yt-masthead-height-changed"));
                    downloadButton.addEventListener("click", (e)=>{
                        (0, _utils.getResource)(window.location.href);
                    });
                }
            }
        } else {
            const toolBars = document.querySelectorAll(".action-container");
            if (toolBars) toolBars.forEach((toolBar)=>{
                if (!toolBar.querySelector('[cobalt-ext="youtube"]')) {
                    // Get a template, normal button (the share button)
                    const template = toolBar.querySelectorAll("div.button-container")[2];
                    // Apply all necessary styles and accessibility features to the button wrapper
                    const downloadButton = document.createElement("div"); // cloneNode() doesn't work in the scenario because of YouTube rendering system. I hate it here too.
                    downloadButton.classList.add(...template.classList);
                    downloadButton.setAttribute("cobalt-ext", "youtube");
                    downloadButton.title = "Download short with cobalt";
                    downloadButton.style.paddingTop = "16px";
                    // Create the elements that reside inside the button but don't have any specific properties we need to change
                    const downloadButtonInner = document.createElement("ytd-cobalt-button-renderer");
                    downloadButtonInner.classList.add(...document.querySelector("#share-button ytd-button-renderer").classList);
                    downloadButtonInner.setAttribute("vertically-aligned", "");
                    const buttonShape = document.createElement("yt-cobalt-button-shape");
                    const buttonLabel = document.createElement("label");
                    buttonLabel.classList.add(...template.querySelector("yt-button-shape > label").classList);
                    // This is the actual button inside of the button wrapper
                    const buttonLabelInner = document.createElement("button");
                    buttonLabelInner.classList.add(...template.querySelector("yt-button-shape > label > button").classList);
                    buttonLabelInner.setAttribute("aria-label", "Download video with cobalt");
                    buttonLabelInner.setAttribute("type", "button");
                    buttonLabelInner.title = "Download video with cobalt";
                    // Feedback shape is responsible for some niche mobile/touch UI response
                    const buttonFeedbackShape = document.createElement("yt-touch-feedback-shape");
                    buttonFeedbackShape.style.borderRadius = "inherit";
                    const buttonFeedbackShapeInner = document.createElement("div");
                    buttonFeedbackShapeInner.classList.add(...template.querySelector("yt-button-shape label yt-touch-feedback-shape div").classList);
                    buttonFeedbackShapeInner.setAttribute("aria-hidden", true);
                    const buttonFeedbackShapeInnerInner1 = document.createElement("div");
                    buttonFeedbackShapeInnerInner1.classList.add(...template.querySelectorAll("yt-button-shape label yt-touch-feedback-shape div div")[0].classList);
                    const buttonFeedbackShapeInnerInner2 = document.createElement("div");
                    buttonFeedbackShapeInnerInner2.classList.add(...template.querySelectorAll("yt-button-shape label yt-touch-feedback-shape div div")[1].classList);
                    // Put the feedback shape together
                    buttonFeedbackShapeInnerInner1.insertAdjacentElement("afterend", buttonFeedbackShapeInnerInner2);
                    buttonFeedbackShapeInner.appendChild(buttonFeedbackShapeInnerInner1);
                    buttonFeedbackShape.appendChild(buttonFeedbackShapeInner);
                    buttonLabelInner.appendChild(buttonFeedbackShape);
                    // Create the download icon
                    const buttonLabelIconOuter = document.createElement("div");
                    buttonLabelIconOuter.classList.add(...template.querySelector("yt-button-shape > label > button > div").classList, "yt-cobalt-button-icon");
                    buttonLabelIconOuter.setAttribute("aria-hidden", true);
                    const buttonLabelIconInner = document.createElement("yt-cobalt-icon");
                    buttonLabelIconInner.classList.add(...template.querySelector("yt-button-shape > label > button > div > yt-icon").classList);
                    buttonLabelIconInner.classList.add("yt-icon", "yt-icon-shape", "yt-spec-icon-shape");
                    buttonLabelIconInner.style.width = "24px";
                    buttonLabelIconInner.style.height = "24px";
                    buttonLabelIconInner.style.display = "block";
                    buttonLabelIconInner.innerHTML = downloadIcon(buttonLabelIconInner.classList.toString());
                    const buttonIconLabelOuter = document.createElement("div");
                    buttonIconLabelOuter.classList.add(...template.querySelector("yt-button-shape > label > div").classList);
                    buttonIconLabelOuter.setAttribute("aria-hidden", true);
                    const buttonIconLabelInner = document.createElement("span");
                    buttonIconLabelInner.classList.add(...template.querySelector("yt-button-shape > label > div > span").classList);
                    buttonIconLabelInner.setAttribute("role", "text");
                    buttonIconLabelInner.innerText = "Save"; // "Save" instead of "Download" because "Download" is too long lol
                    // Put everything together (I hate this so much)
                    buttonIconLabelOuter.appendChild(buttonIconLabelInner);
                    buttonLabelIconOuter.appendChild(buttonLabelIconInner);
                    buttonLabelInner.appendChild(buttonLabelIconOuter);
                    buttonLabel.appendChild(buttonLabelInner);
                    buttonLabel.appendChild(buttonIconLabelOuter);
                    buttonShape.appendChild(buttonLabel);
                    downloadButtonInner.appendChild(buttonShape);
                    downloadButton.appendChild(downloadButtonInner);
                    downloadButton.addEventListener("click", (e)=>{
                        (0, _utils.getResource)(window.location.href);
                    });
                    toolBar?.querySelector("#share-button").insertAdjacentElement("afterend", downloadButton);
                    // YouTube slightly changes the look of the action buttons (like, comment, etc) when the description and comment section panels are expanded
                    // Both of these event listeners run in parallel to ensure that the correct button styles are applied even when simply toggling between the panels
                    // Reverse-engineering YouTue's code is a pain, but this is the best I could come up with
                    document.addEventListener("yt-action", (e)=>{
                        if (e.detail && e.detail.args && e?.detail?.args[1] === "ENGAGEMENT_PANEL_VISIBILITY_EXPANDED" && (e?.detail?.args[2] === "engagement-panel-comments-section" || e?.detail?.args[2] === "engagement-panel-structured-description")) {
                            (0, _logger.logger).log("engagement panel shown", e);
                            buttonLabelInner.classList.add("yt-spec-button-shape-next--overlay-dark");
                            downloadButton.style.paddingTop = "0px";
                        }
                    });
                    document.addEventListener("yt-action", (e)=>{
                        if (e.detail && e.detail.args && e?.detail?.args[1] === "ENGAGEMENT_PANEL_VISIBILITY_HIDDEN" && (e?.detail?.args[2] === "engagement-panel-comments-section" || e?.detail?.args[2] === "engagement-panel-structured-description")) {
                            (0, _logger.logger).log("engagement panel hidden", e);
                            buttonLabelInner.classList.remove("yt-spec-button-shape-next--overlay-dark");
                            downloadButton.style.paddingTop = "16px";
                        }
                    });
                }
            });
        }
    }
}
(0, _utils.watchPage)(addDownloadButton);

},{"../common/logger":"73tk1","../common/utils":"39Pbd"}],"73tk1":[function(require,module,exports) {
// This is a modified version of the "echo" logger concept from https://www.bennadel.com/blog/3941-styling-console-log-output-formatting-with-css.htm
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "logger", ()=>logger);
var _manifestJson = require("../manifest.json");
const logger = function() {
    var queue = [];
    var logger_TOKEN = {};
    var RESET_INPUT = "%c ";
    var RESET_CSS = "";
    function alertFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: #e0005a ; color: #ffffff ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function warningFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: gold ; color: black ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function titleFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: black ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    // I provide an logger-based proxy to the given Console Function. This uses an
    // internal queue to aggregate values before calling the given Console
    // Function with the desired formatting.
    function using(consoleFunction) {
        function consoleFunctionProxy() {
            // As we loop over the arguments, we're going to aggregate a set of
            // inputs and modifiers. The Inputs will ultimately be collapsed down
            // into a single string that acts as the first console.log parameter
            // while the modifiers are then SPREAD into console.log as 2...N.
            // --
            // NOTE: After each input/modifier pair, I'm adding a RESET pairing.
            // This implicitly resets the CSS after every formatted pairing.
            var inputs = [];
            var modifiers = [];
            // Add the cobalt-ext header
            inputs.push("%ccobalt-ext@" + (0, _manifestJson.version), RESET_INPUT);
            modifiers.push("display: inline-block; background-color: black; color: white; font-weight: bold; padding: 3px 7px; border-radius: 3px;", RESET_CSS);
            for(var i = 0; i < arguments.length; i++)// When the formatting utility methods are called, they return
            // a special token. This indicates that we should pull the
            // corresponding value out of the QUEUE instead of trying to
            // output the given argument directly.
            if (arguments[i] === logger_TOKEN) {
                var item = queue.shift();
                inputs.push("%c" + item.value, RESET_INPUT);
                modifiers.push(item.css, RESET_CSS);
            // For every other argument type, output the value directly.
            } else {
                var arg = arguments[i];
                if (typeof arg === "object" || typeof arg === "function") {
                    inputs.push("%o", RESET_INPUT);
                    modifiers.push(arg, RESET_CSS);
                } else {
                    inputs.push("%c" + arg, RESET_INPUT);
                    modifiers.push(RESET_CSS, RESET_CSS);
                }
            }
            consoleFunction(inputs.join(""), ...modifiers);
            // Once we output the aggregated value, reset the queue. This should have
            // already been emptied by the .shift() calls; but the explicit reset
            // here acts as both a marker of intention as well as a fail-safe.
            queue = [];
        }
        return consoleFunctionProxy;
    }
    return {
        log: using(console.log),
        warn: using(console.warn),
        error: using(console.error),
        trace: using(console.trace),
        asAlert: alertFormatting,
        asWarning: warningFormatting,
        asTitle: titleFormatting
    };
}();

},{"@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS","./utils.js":"39Pbd"}],"aNjyS":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"39Pbd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "getResource", ()=>getResource);
parcelHelpers.export(exports, "watchPage", ()=>watchPage);
var _logger = require("./logger");
async function getResource(url) {
    (0, _logger.logger).log("redirecting to cobalt website for " + url + "...");
    return new Promise((resolve, reject)=>{
        window.open("https://cobalt.tools/#" + url, "_blank");
        resolve(true);
    });
}
function watchPage(callback) {
    let scheduled = false;
    const observerCallback = ()=>{
        if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(()=>{
                callback();
                scheduled = false;
            });
        }
    };
    const observer = new MutationObserver((mutationsList)=>{
        for (const mutation of mutationsList)if (mutation.type === "childList") {
            observerCallback();
            break;
        }
    });
    observer.observe(document, {
        childList: true,
        subtree: true
    });
}

},{"./logger":"73tk1","@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS"}]},["1dmY8"], "1dmY8", "parcelRequirea3c5")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQSxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDO0FBRVgsTUFBTSxlQUFlLENBQUM7SUFDcEIsdUVBQXVFO0lBQ3ZFLElBQUksYUFDRixTQUFTLElBQUksQ0FDVixhQUFhLENBQUMsNEJBQ2QsWUFBWSxDQUFDLGNBQWM7SUFFaEMsT0FBTyxDQUFDO29DQUMwQixFQUFFLFdBQVc7b0ZBQ21DLEVBQzFFLGFBQWEsVUFBVSxRQUN4Qjt5RkFDZ0YsRUFDL0UsYUFBYSxVQUFVLFFBQ3hCOytJQUNzSSxFQUNySSxhQUFhLFVBQVUsUUFDeEI7O0lBRUwsQ0FBQztBQUNMO0FBRUEsU0FBUztJQUNQLE1BQU0sY0FBYyxTQUFTLGFBQWEsQ0FBQztJQUMzQyxNQUFNLGdCQUFnQixPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBRXBELElBQUksQ0FBQztRQUNILElBQUksQ0FBQyxlQUFlO1lBQ2xCLElBQUksVUFBVSxTQUFTLGFBQWEsQ0FDbEM7WUFFRixJQUFJLFNBQVM7Z0JBQ1gsMkdBQTJHO2dCQUMzRyxNQUFNLGlCQUFpQixRQUFRLGFBQWEsQ0FDMUMscUVBQ0EsYUFBYSxDQUFDLGFBQWE7Z0JBRTdCLElBQ0UsQ0FBQyxlQUFlLGFBQWEsQ0FBQyxhQUFhLENBQUMsMkJBQzVDO29CQUNBLE1BQU0saUJBQWlCLGVBQWUsU0FBUyxDQUFDO29CQUNoRCxRQUFRLEdBQUcsQ0FBQztvQkFDWixNQUFNLHNCQUFzQixlQUFlLGFBQWEsQ0FBQztvQkFDekQsUUFBUSxxQkFBcUIsQ0FBQyxhQUFhO29CQUUzQyxlQUFlLFlBQVksQ0FBQyxjQUFjO29CQUMxQyxlQUFlLGFBQWEsQ0FBQyxXQUFXLGFBQWEsQ0FBQyxTQUFTLEdBQzdELGFBQ0UsZUFBZSxhQUFhLENBQUMsV0FBVyxTQUFTLENBQUMsUUFBUTtvQkFHOUQsb0JBQW9CLEtBQUssR0FBRztvQkFDNUIsb0JBQW9CLFlBQVksQ0FDOUIsY0FDQTtvQkFHRixlQUFlLGFBQWEsQ0FDMUIsbURBQ0EsV0FBVyxHQUFHO29CQUVoQixNQUFNLFNBQVMsU0FBUyxhQUFhLENBQUM7b0JBQ3RDLE9BQU8sU0FBUyxHQUFHLENBQUM7Ozs7Ozs7OzthQVNqQixDQUFDO29CQUVKLFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQztvQkFFMUIsUUFBUSxxQkFBcUIsQ0FBQyxhQUFhO29CQUUzQyx3Q0FBd0M7b0JBQ3hDLFNBQVMsYUFBYSxDQUFDLElBQUksTUFBTTtvQkFDakMsU0FBUyxhQUFhLENBQUMsSUFBSSxNQUFNO29CQUNqQyxTQUFTLGFBQWEsQ0FBQyxJQUFJLE1BQU07b0JBRWpDLGVBQWUsZ0JBQWdCLENBQUMsU0FBUyxDQUFDO3dCQUN4QyxDQUFBLEdBQUEsa0JBQVcsQUFBRCxFQUFFLE9BQU8sUUFBUSxDQUFDLElBQUk7b0JBQ2xDO2dCQUNGO1lBQ0Y7UUFDRixPQUFPO1lBQ0wsTUFBTSxXQUFXLFNBQVMsZ0JBQWdCLENBQUM7WUFDM0MsSUFBSSxVQUNGLFNBQVMsT0FBTyxDQUFDLENBQUM7Z0JBQ2hCLElBQUksQ0FBQyxRQUFRLGFBQWEsQ0FBQywyQkFBMkI7b0JBQ3BELG1EQUFtRDtvQkFDbkQsTUFBTSxXQUFXLFFBQVEsZ0JBQWdCLENBQ3ZDLHVCQUNELENBQUMsRUFBRTtvQkFFSiw4RUFBOEU7b0JBQzlFLE1BQU0saUJBQWlCLFNBQVMsYUFBYSxDQUFDLFFBQVEsb0dBQW9HO29CQUMxSixlQUFlLFNBQVMsQ0FBQyxHQUFHLElBQUksU0FBUyxTQUFTO29CQUNsRCxlQUFlLFlBQVksQ0FBQyxjQUFjO29CQUMxQyxlQUFlLEtBQUssR0FBRztvQkFDdkIsZUFBZSxLQUFLLENBQUMsVUFBVSxHQUFHO29CQUVsQyw2R0FBNkc7b0JBQzdHLE1BQU0sc0JBQXNCLFNBQVMsYUFBYSxDQUNoRDtvQkFFRixvQkFBb0IsU0FBUyxDQUFDLEdBQUcsSUFDNUIsU0FBUyxhQUFhLENBQUMscUNBQ3ZCLFNBQVM7b0JBRWQsb0JBQW9CLFlBQVksQ0FBQyxzQkFBc0I7b0JBQ3ZELE1BQU0sY0FBYyxTQUFTLGFBQWEsQ0FDeEM7b0JBR0YsTUFBTSxjQUFjLFNBQVMsYUFBYSxDQUFDO29CQUMzQyxZQUFZLFNBQVMsQ0FBQyxHQUFHLElBQ3BCLFNBQVMsYUFBYSxDQUFDLDJCQUEyQixTQUFTO29CQUdoRSx5REFBeUQ7b0JBQ3pELE1BQU0sbUJBQW1CLFNBQVMsYUFBYSxDQUFDO29CQUNoRCxpQkFBaUIsU0FBUyxDQUFDLEdBQUcsSUFDekIsU0FBUyxhQUFhLENBQUMsb0NBQ3ZCLFNBQVM7b0JBRWQsaUJBQWlCLFlBQVksQ0FDM0IsY0FDQTtvQkFFRixpQkFBaUIsWUFBWSxDQUFDLFFBQVE7b0JBQ3RDLGlCQUFpQixLQUFLLEdBQUc7b0JBRXpCLHdFQUF3RTtvQkFDeEUsTUFBTSxzQkFBc0IsU0FBUyxhQUFhLENBQ2hEO29CQUVGLG9CQUFvQixLQUFLLENBQUMsWUFBWSxHQUFHO29CQUV6QyxNQUFNLDJCQUEyQixTQUFTLGFBQWEsQ0FBQztvQkFDeEQseUJBQXlCLFNBQVMsQ0FBQyxHQUFHLElBQ2pDLFNBQVMsYUFBYSxDQUN2QixxREFDQSxTQUFTO29CQUViLHlCQUF5QixZQUFZLENBQUMsZUFBZTtvQkFFckQsTUFBTSxpQ0FDSixTQUFTLGFBQWEsQ0FBQztvQkFDekIsK0JBQStCLFNBQVMsQ0FBQyxHQUFHLElBQ3ZDLFNBQVMsZ0JBQWdCLENBQzFCLHdEQUNELENBQUMsRUFBRSxDQUFDLFNBQVM7b0JBR2hCLE1BQU0saUNBQ0osU0FBUyxhQUFhLENBQUM7b0JBQ3pCLCtCQUErQixTQUFTLENBQUMsR0FBRyxJQUN2QyxTQUFTLGdCQUFnQixDQUMxQix3REFDRCxDQUFDLEVBQUUsQ0FBQyxTQUFTO29CQUdoQixrQ0FBa0M7b0JBQ2xDLCtCQUErQixxQkFBcUIsQ0FDbEQsWUFDQTtvQkFFRix5QkFBeUIsV0FBVyxDQUNsQztvQkFFRixvQkFBb0IsV0FBVyxDQUFDO29CQUNoQyxpQkFBaUIsV0FBVyxDQUFDO29CQUU3QiwyQkFBMkI7b0JBQzNCLE1BQU0sdUJBQXVCLFNBQVMsYUFBYSxDQUFDO29CQUNwRCxxQkFBcUIsU0FBUyxDQUFDLEdBQUcsSUFDN0IsU0FBUyxhQUFhLENBQ3ZCLDBDQUNBLFNBQVMsRUFDWDtvQkFFRixxQkFBcUIsWUFBWSxDQUFDLGVBQWU7b0JBRWpELE1BQU0sdUJBQ0osU0FBUyxhQUFhLENBQUM7b0JBQ3pCLHFCQUFxQixTQUFTLENBQUMsR0FBRyxJQUM3QixTQUFTLGFBQWEsQ0FDdkIsb0RBQ0EsU0FBUztvQkFFYixxQkFBcUIsU0FBUyxDQUFDLEdBQUcsQ0FDaEMsV0FDQSxpQkFDQTtvQkFFRixxQkFBcUIsS0FBSyxDQUFDLEtBQUssR0FBRztvQkFDbkMscUJBQXFCLEtBQUssQ0FBQyxNQUFNLEdBQUc7b0JBQ3BDLHFCQUFxQixLQUFLLENBQUMsT0FBTyxHQUFHO29CQUNyQyxxQkFBcUIsU0FBUyxHQUFHLGFBQy9CLHFCQUFxQixTQUFTLENBQUMsUUFBUTtvQkFHekMsTUFBTSx1QkFBdUIsU0FBUyxhQUFhLENBQUM7b0JBQ3BELHFCQUFxQixTQUFTLENBQUMsR0FBRyxJQUM3QixTQUFTLGFBQWEsQ0FBQyxpQ0FDdkIsU0FBUztvQkFHZCxxQkFBcUIsWUFBWSxDQUFDLGVBQWU7b0JBRWpELE1BQU0sdUJBQXVCLFNBQVMsYUFBYSxDQUFDO29CQUNwRCxxQkFBcUIsU0FBUyxDQUFDLEdBQUcsSUFDN0IsU0FBUyxhQUFhLENBQUMsd0NBQ3ZCLFNBQVM7b0JBR2QscUJBQXFCLFlBQVksQ0FBQyxRQUFRO29CQUMxQyxxQkFBcUIsU0FBUyxHQUFHLFFBQVEsa0VBQWtFO29CQUUzRyxnREFBZ0Q7b0JBQ2hELHFCQUFxQixXQUFXLENBQUM7b0JBQ2pDLHFCQUFxQixXQUFXLENBQUM7b0JBQ2pDLGlCQUFpQixXQUFXLENBQUM7b0JBQzdCLFlBQVksV0FBVyxDQUFDO29CQUN4QixZQUFZLFdBQVcsQ0FBQztvQkFDeEIsWUFBWSxXQUFXLENBQUM7b0JBQ3hCLG9CQUFvQixXQUFXLENBQUM7b0JBQ2hDLGVBQWUsV0FBVyxDQUFDO29CQUUzQixlQUFlLGdCQUFnQixDQUFDLFNBQVMsQ0FBQzt3QkFDeEMsQ0FBQSxHQUFBLGtCQUFXLEFBQUQsRUFBRSxPQUFPLFFBQVEsQ0FBQyxJQUFJO29CQUNsQztvQkFFQSxTQUNJLGNBQWMsaUJBQ2Ysc0JBQXNCLFlBQVk7b0JBRXJDLDRJQUE0STtvQkFDNUksa0pBQWtKO29CQUNsSix5RkFBeUY7b0JBQ3pGLFNBQVMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDO3dCQUN0QyxJQUNFLEVBQUUsTUFBTSxJQUNSLEVBQUUsTUFBTSxDQUFDLElBQUksSUFDYixHQUFHLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FBSywwQ0FDdEIsQ0FBQSxHQUFHLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FBSyx1Q0FDdEIsR0FBRyxRQUFRLElBQUksQ0FBQyxFQUFFLEtBQ2hCLHlDQUF3QyxHQUM1Qzs0QkFDQSxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDLDBCQUEwQjs0QkFDckMsaUJBQWlCLFNBQVMsQ0FBQyxHQUFHLENBQzVCOzRCQUVGLGVBQWUsS0FBSyxDQUFDLFVBQVUsR0FBRzt3QkFDcEM7b0JBQ0Y7b0JBQ0EsU0FBUyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUM7d0JBQ3RDLElBQ0UsRUFBRSxNQUFNLElBQ1IsRUFBRSxNQUFNLENBQUMsSUFBSSxJQUNiLEdBQUcsUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLHdDQUN0QixDQUFBLEdBQUcsUUFBUSxJQUFJLENBQUMsRUFBRSxLQUFLLHVDQUN0QixHQUFHLFFBQVEsSUFBSSxDQUFDLEVBQUUsS0FDaEIseUNBQXdDLEdBQzVDOzRCQUNBLENBQUEsR0FBQSxjQUFNLEFBQUQsRUFBRSxHQUFHLENBQUMsMkJBQTJCOzRCQUN0QyxpQkFBaUIsU0FBUyxDQUFDLE1BQU0sQ0FDL0I7NEJBRUYsZUFBZSxLQUFLLENBQUMsVUFBVSxHQUFHO3dCQUNwQztvQkFDRjtnQkFDRjtZQUNGO1FBRUo7O0FBRUo7QUFFQSxDQUFBLEdBQUEsZ0JBQVMsQUFBRCxFQUFFOzs7QUMvUlYscUpBQXFKOzs7NENBSXhJO0FBRmI7QUFFTyxNQUFNLFNBQVMsQUFBQztJQUNyQixJQUFJLFFBQVEsRUFBRTtJQUNkLElBQUksZUFBZSxDQUFDO0lBQ3BCLElBQUksY0FBYztJQUNsQixJQUFJLFlBQVk7SUFFaEIsU0FBUyxnQkFBZ0IsS0FBSztRQUM1QixNQUFNLElBQUksQ0FBQztZQUNULE9BQU87WUFDUCxLQUFLO1FBQ1A7UUFFQSxPQUFPO0lBQ1Q7SUFFQSxTQUFTLGtCQUFrQixLQUFLO1FBQzlCLE1BQU0sSUFBSSxDQUFDO1lBQ1QsT0FBTztZQUNQLEtBQUs7UUFDUDtRQUVBLE9BQU87SUFDVDtJQUVBLFNBQVMsZ0JBQWdCLEtBQUs7UUFDNUIsTUFBTSxJQUFJLENBQUM7WUFDVCxPQUFPO1lBQ1AsS0FBSztRQUNQO1FBRUEsT0FBTztJQUNUO0lBRUEsOEVBQThFO0lBQzlFLHNFQUFzRTtJQUN0RSx3Q0FBd0M7SUFDeEMsU0FBUyxNQUFNLGVBQWU7UUFDNUIsU0FBUztZQUNQLG1FQUFtRTtZQUNuRSxxRUFBcUU7WUFDckUsb0VBQW9FO1lBQ3BFLGlFQUFpRTtZQUNqRSxLQUFLO1lBQ0wsb0VBQW9FO1lBQ3BFLGdFQUFnRTtZQUNoRSxJQUFJLFNBQVMsRUFBRTtZQUNmLElBQUksWUFBWSxFQUFFO1lBRWxCLDRCQUE0QjtZQUM1QixPQUFPLElBQUksQ0FBQyxrQkFBdUIsQ0FBQSxHQUFBLHFCQUFPLEFBQUQsR0FBRztZQUM1QyxVQUFVLElBQUksQ0FDWiwwSEFDQTtZQUdGLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLE1BQU0sRUFBRSxJQUNwQyw4REFBOEQ7WUFDOUQsMERBQTBEO1lBQzFELDREQUE0RDtZQUM1RCxzQ0FBc0M7WUFDdEMsSUFBSSxTQUFTLENBQUMsRUFBRSxLQUFLLGNBQWM7Z0JBQ2pDLElBQUksT0FBTyxNQUFNLEtBQUs7Z0JBRXRCLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQUU7Z0JBQy9CLFVBQVUsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFO1lBRXpCLDREQUE0RDtZQUM5RCxPQUFPO2dCQUNMLElBQUksTUFBTSxTQUFTLENBQUMsRUFBRTtnQkFFdEIsSUFBSSxPQUFPLFFBQVEsWUFBWSxPQUFPLFFBQVEsWUFBWTtvQkFDeEQsT0FBTyxJQUFJLENBQUMsTUFBTTtvQkFDbEIsVUFBVSxJQUFJLENBQUMsS0FBSztnQkFDdEIsT0FBTztvQkFDTCxPQUFPLElBQUksQ0FBQyxPQUFPLEtBQUs7b0JBQ3hCLFVBQVUsSUFBSSxDQUFDLFdBQVc7Z0JBQzVCO1lBQ0Y7WUFHRixnQkFBZ0IsT0FBTyxJQUFJLENBQUMsUUFBUTtZQUVwQyx5RUFBeUU7WUFDekUscUVBQXFFO1lBQ3JFLGtFQUFrRTtZQUNsRSxRQUFRLEVBQUU7UUFDWjtRQUVBLE9BQU87SUFDVDtJQUVBLE9BQU87UUFDTCxLQUFLLE1BQU0sUUFBUSxHQUFHO1FBQ3RCLE1BQU0sTUFBTSxRQUFRLElBQUk7UUFDeEIsT0FBTyxNQUFNLFFBQVEsS0FBSztRQUMxQixPQUFPLE1BQU0sUUFBUSxLQUFLO1FBRTFCLFNBQVM7UUFDVCxXQUFXO1FBQ1gsU0FBUztJQUNYO0FBQ0Y7OztBQ3pHQSxRQUFRLGNBQWMsR0FBRyxTQUFVLENBQUM7SUFDbEMsT0FBTyxLQUFLLEVBQUUsVUFBVSxHQUFHLElBQUk7UUFBQyxTQUFTO0lBQUM7QUFDNUM7QUFFQSxRQUFRLGlCQUFpQixHQUFHLFNBQVUsQ0FBQztJQUNyQyxPQUFPLGNBQWMsQ0FBQyxHQUFHLGNBQWM7UUFBQyxPQUFPO0lBQUk7QUFDckQ7QUFFQSxRQUFRLFNBQVMsR0FBRyxTQUFVLE1BQU0sRUFBRSxJQUFJO0lBQ3hDLE9BQU8sSUFBSSxDQUFDLFFBQVEsT0FBTyxDQUFDLFNBQVUsR0FBRztRQUN2QyxJQUNFLFFBQVEsYUFDUixRQUFRLGdCQUNSLE9BQU8sU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxNQUUzQztRQUdGLE9BQU8sY0FBYyxDQUFDLE1BQU0sS0FBSztZQUMvQixZQUFZO1lBQ1osS0FBSztnQkFDSCxPQUFPLE1BQU0sQ0FBQyxJQUFJO1lBQ3BCO1FBQ0Y7SUFDRjtJQUVBLE9BQU87QUFDVDtBQUVBLFFBQVEsTUFBTSxHQUFHLFNBQVUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHO0lBQzVDLE9BQU8sY0FBYyxDQUFDLE1BQU0sVUFBVTtRQUNwQyxZQUFZO1FBQ1osS0FBSztJQUNQO0FBQ0Y7Ozs7O0FDaENBLGlEQUFzQjtBQVN0QiwrQ0FBZ0I7QUFYaEI7QUFFTyxlQUFlLFlBQVksR0FBRztJQUNuQyxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDLHVDQUF1QyxNQUFNO0lBRXhELE9BQU8sSUFBSSxRQUFRLENBQUMsU0FBUztRQUMzQixPQUFPLElBQUksQ0FBQywyQkFBMkIsS0FBSztRQUM1QyxRQUFRO0lBQ1Y7QUFDRjtBQUVPLFNBQVMsVUFBVSxRQUFRO0lBQ2hDLElBQUksWUFBWTtJQUVoQixNQUFNLG1CQUFtQjtRQUN2QixJQUFJLENBQUMsV0FBVztZQUNkLFlBQVk7WUFDWixzQkFBc0I7Z0JBQ3BCO2dCQUNBLFlBQVk7WUFDZDtRQUNGO0lBQ0Y7SUFFQSxNQUFNLFdBQVcsSUFBSSxpQkFBaUIsQ0FBQztRQUNyQyxLQUFLLE1BQU0sWUFBWSxjQUNyQixJQUFJLFNBQVMsSUFBSSxLQUFLLGFBQWE7WUFDakM7WUFDQTtRQUNGO0lBRUo7SUFFQSxTQUFTLE9BQU8sQ0FBQyxVQUFVO1FBQ3pCLFdBQVc7UUFDWCxTQUFTO0lBQ1g7QUFDRiIsInNvdXJjZXMiOlsic3JjL3NlcnZpY2VzL3lvdXR1YmUuanMiLCJzcmMvY29tbW9uL2xvZ2dlci5qcyIsIm5vZGVfbW9kdWxlcy9AcGFyY2VsL2NvbmZpZy13ZWJleHRlbnNpb24vbm9kZV9tb2R1bGVzL0BwYXJjZWwvdHJhbnNmb3JtZXItanMvc3JjL2VzbW9kdWxlLWhlbHBlcnMuanMiLCJzcmMvY29tbW9uL3V0aWxzLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGxvZ2dlciB9IGZyb20gXCIuLi9jb21tb24vbG9nZ2VyXCI7XHJcbmltcG9ydCB7IGdldFJlc291cmNlLCB3YXRjaFBhZ2UgfSBmcm9tIFwiLi4vY29tbW9uL3V0aWxzXCI7XHJcblxyXG5sb2dnZXIubG9nKFwiWW91VHViZSBkZXRlY3RlZCFcIik7XHJcblxyXG5jb25zdCBkb3dubG9hZEljb24gPSAoY2xhc3NOYW1lcykgPT4ge1xyXG4gIC8vIFVzZSB0aGUgbWV0YSB0aGVtZSBjb2xvciB0byBkZXRlcm1pbmUgaWYgdGhlIHVzZXIgaXMgdXNpbmcgZGFyayBtb2RlXHJcbiAgdmFyIGlzRGFya01vZGUgPVxyXG4gICAgZG9jdW1lbnQuaGVhZFxyXG4gICAgICAucXVlcnlTZWxlY3RvcignbWV0YVtuYW1lPVwidGhlbWUtY29sb3JcIl0nKVxyXG4gICAgICAuZ2V0QXR0cmlidXRlKFwiY29udGVudFwiKSAhPSBcInJnYmEoMjU1LCAyNTUsIDI1NSwgMC45OClcIjtcclxuXHJcbiAgcmV0dXJuIGBcclxuICAgIDxzdmcgdmlld0JveD1cIjAgMCA0OCA0OFwiIGNsYXNzPVwiJHtjbGFzc05hbWVzfVwiPlxyXG4gICAgICAgIDxwYXRoIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBjbGlwLXJ1bGU9XCJldmVub2RkXCIgZD1cIk0zOCA0NEgxMFY0MkgzOFY0NFpcIiBmaWxsPVwiJHtcclxuICAgICAgICAgIGlzRGFya01vZGUgPyBcIndoaXRlXCIgOiBcImJsYWNrXCJcclxuICAgICAgICB9XCIgZmlsbC1ydWxlPVwiZXZlbm9kZFwiIGNsaXAtcnVsZT1cImV2ZW5vZGRcIj48L3BhdGg+XHJcbiAgICAgICAgPHBhdGggZmlsbC1ydWxlPVwiZXZlbm9kZFwiIGNsaXAtcnVsZT1cImV2ZW5vZGRcIiBkPVwiTTIzIDM0LjVWNC41SDI1VjM0LjVIMjNaXCIgZmlsbD1cIiR7XHJcbiAgICAgICAgICBpc0RhcmtNb2RlID8gXCJ3aGl0ZVwiIDogXCJibGFja1wiXHJcbiAgICAgICAgfVwiIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBjbGlwLXJ1bGU9XCJldmVub2RkXCI+PC9wYXRoPlxyXG4gICAgICAgIDxwYXRoIGZpbGwtcnVsZT1cImV2ZW5vZGRcIiBjbGlwLXJ1bGU9XCJldmVub2RkXCIgZD1cIk0yNCAzNS40MTQyTDEwLjU4NTggMjJMMTIgMjAuNTg1OEwyNCAzMi41ODU4TDM2IDIwLjU4NThMMzcuNDE0MiAyMkwyNCAzNS40MTQyWlwiIGZpbGw9XCIke1xyXG4gICAgICAgICAgaXNEYXJrTW9kZSA/IFwid2hpdGVcIiA6IFwiYmxhY2tcIlxyXG4gICAgICAgIH1cIiBmaWxsLXJ1bGU9XCJldmVub2RkXCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiPjwvcGF0aD5cclxuICAgIDwvc3ZnPlxyXG4gICAgYDtcclxufTtcclxuXHJcbmZ1bmN0aW9uIGFkZERvd25sb2FkQnV0dG9uKCkge1xyXG4gIGNvbnN0IGlzTGl2ZVZpZGVvID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignW3Nob3VsZC1zdGFtcC1jaGF0PVwiXCJdJyk7XHJcbiAgY29uc3QgaXNTaG9ydHNWaWRlbyA9IHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluY2x1ZGVzKFwiL3Nob3J0cy9cIik7XHJcblxyXG4gIGlmICghaXNMaXZlVmlkZW8pIHtcclxuICAgIGlmICghaXNTaG9ydHNWaWRlbykge1xyXG4gICAgICB2YXIgdG9vbEJhciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXHJcbiAgICAgICAgXCJ5dGQtd2F0Y2gtZmxleHkgI3RvcC1sZXZlbC1idXR0b25zLWNvbXB1dGVkXCJcclxuICAgICAgKTtcclxuICAgICAgaWYgKHRvb2xCYXIpIHtcclxuICAgICAgICAvLyBHZXQgYSB0ZW1wbGF0ZSwgbm9ybWFsIGJ1dHRvbiAodXN1YWxseSB0aGUgc2hhcmUgYnV0dG9uKSBhbmQgdGhlIHdlIGNsb25lIGl0IGFuZCBtb2RpZnkgaXQgdG8gb3VyIGxpa2luZ1xyXG4gICAgICAgIGNvbnN0IHRlbXBsYXRlQnV0dG9uID0gdG9vbEJhci5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgJ3l0LWJ1dHRvbi12aWV3LW1vZGVsIGJ1dHRvbi12aWV3LW1vZGVsIGJ1dHRvblthcmlhLWxhYmVsPVwiU2hhcmVcIl0nXHJcbiAgICAgICAgKS5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQ7XHJcblxyXG4gICAgICAgIGlmIChcclxuICAgICAgICAgICF0ZW1wbGF0ZUJ1dHRvbi5wYXJlbnRFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tjb2JhbHQtZXh0PVwieW91dHViZVwiXScpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBjb25zdCBkb3dubG9hZEJ1dHRvbiA9IHRlbXBsYXRlQnV0dG9uLmNsb25lTm9kZSh0cnVlKTtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGRvd25sb2FkQnV0dG9uKTtcclxuICAgICAgICAgIGNvbnN0IGRvd25sb2FkQnV0dG9uSW5uZXIgPSBkb3dubG9hZEJ1dHRvbi5xdWVyeVNlbGVjdG9yKFwiYnV0dG9uXCIpO1xyXG4gICAgICAgICAgdG9vbEJhci5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJiZWZvcmVlbmRcIiwgZG93bmxvYWRCdXR0b24pO1xyXG5cclxuICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnNldEF0dHJpYnV0ZShcImNvYmFsdC1leHRcIiwgXCJ5b3V0dWJlXCIpO1xyXG4gICAgICAgICAgZG93bmxvYWRCdXR0b24ucXVlcnlTZWxlY3RvcihcInl0LWljb25cIikucGFyZW50RWxlbWVudC5pbm5lckhUTUwgPVxyXG4gICAgICAgICAgICBkb3dubG9hZEljb24oXHJcbiAgICAgICAgICAgICAgZG93bmxvYWRCdXR0b24ucXVlcnlTZWxlY3RvcihcInl0LWljb25cIikuY2xhc3NMaXN0LnRvU3RyaW5nKClcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICBkb3dubG9hZEJ1dHRvbklubmVyLnRpdGxlID0gXCJkb3dubG9hZCB3aXRoIGNvYmFsdFwiO1xyXG4gICAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zZXRBdHRyaWJ1dGUoXHJcbiAgICAgICAgICAgIFwiYXJpYS1sYWJlbFwiLFxyXG4gICAgICAgICAgICBcImRvd25sb2FkIHdpdGggY29iYWx0XCJcclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgZG93bmxvYWRCdXR0b24ucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICAgXCIueXQtc3BlYy1idXR0b24tc2hhcGUtbmV4dF9fYnV0dG9uLXRleHQtY29udGVudFwiXHJcbiAgICAgICAgICApLnRleHRDb250ZW50ID0gXCJEb3dubG9hZFwiO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHN0eWxlcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzdHlsZVwiKTtcclxuICAgICAgICAgIHN0eWxlcy5pbm5lckhUTUwgPSBgXHJcbiAgICAgICAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDE0NDhweCkge1xyXG4gICAgICAgICAgICAgIFtjb2JhbHQtZXh0PVwieW91dHViZVwiXSAueXQtc3BlYy1idXR0b24tc2hhcGUtbmV4dF9fYnV0dG9uLXRleHQtY29udGVudCB7XHJcbiAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICBbY29iYWx0LWV4dD1cInlvdXR1YmVcIl0gLnl0LXNwZWMtYnV0dG9uLXNoYXBlLW5leHRfX2ljb24ge1xyXG4gICAgICAgICAgICAgICAgICBtYXJnaW46IC02cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1gO1xyXG5cclxuICAgICAgICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGVzKTtcclxuXHJcbiAgICAgICAgICB0b29sQmFyLmluc2VydEFkamFjZW50RWxlbWVudChcImJlZm9yZWVuZFwiLCBkb3dubG9hZEJ1dHRvbik7XHJcblxyXG4gICAgICAgICAgLy8gTGV0IFlvdVR1YmUgY29tcHV0ZSB0aGUgb3ZlcmZsb3cgbWVudVxyXG4gICAgICAgICAgZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJ5dC1yZW5kZXJlcnN0YW1wZXItZmluaXNoZWRcIikpO1xyXG4gICAgICAgICAgZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJ5dC1yZW5kZXJpZG9tLWZpbmlzaGVkXCIpKTtcclxuICAgICAgICAgIGRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwieXQtbWFzdGhlYWQtaGVpZ2h0LWNoYW5nZWRcIikpO1xyXG5cclxuICAgICAgICAgIGRvd25sb2FkQnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICBnZXRSZXNvdXJjZSh3aW5kb3cubG9jYXRpb24uaHJlZik7XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGNvbnN0IHRvb2xCYXJzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5hY3Rpb24tY29udGFpbmVyXCIpO1xyXG4gICAgICBpZiAodG9vbEJhcnMpIHtcclxuICAgICAgICB0b29sQmFycy5mb3JFYWNoKCh0b29sQmFyKSA9PiB7XHJcbiAgICAgICAgICBpZiAoIXRvb2xCYXIucXVlcnlTZWxlY3RvcignW2NvYmFsdC1leHQ9XCJ5b3V0dWJlXCJdJykpIHtcclxuICAgICAgICAgICAgLy8gR2V0IGEgdGVtcGxhdGUsIG5vcm1hbCBidXR0b24gKHRoZSBzaGFyZSBidXR0b24pXHJcbiAgICAgICAgICAgIGNvbnN0IHRlbXBsYXRlID0gdG9vbEJhci5xdWVyeVNlbGVjdG9yQWxsKFxyXG4gICAgICAgICAgICAgIFwiZGl2LmJ1dHRvbi1jb250YWluZXJcIlxyXG4gICAgICAgICAgICApWzJdO1xyXG5cclxuICAgICAgICAgICAgLy8gQXBwbHkgYWxsIG5lY2Vzc2FyeSBzdHlsZXMgYW5kIGFjY2Vzc2liaWxpdHkgZmVhdHVyZXMgdG8gdGhlIGJ1dHRvbiB3cmFwcGVyXHJcbiAgICAgICAgICAgIGNvbnN0IGRvd25sb2FkQnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTsgLy8gY2xvbmVOb2RlKCkgZG9lc24ndCB3b3JrIGluIHRoZSBzY2VuYXJpbyBiZWNhdXNlIG9mIFlvdVR1YmUgcmVuZGVyaW5nIHN5c3RlbS4gSSBoYXRlIGl0IGhlcmUgdG9vLlxyXG4gICAgICAgICAgICBkb3dubG9hZEJ1dHRvbi5jbGFzc0xpc3QuYWRkKC4uLnRlbXBsYXRlLmNsYXNzTGlzdCk7XHJcbiAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uLnNldEF0dHJpYnV0ZShcImNvYmFsdC1leHRcIiwgXCJ5b3V0dWJlXCIpO1xyXG4gICAgICAgICAgICBkb3dubG9hZEJ1dHRvbi50aXRsZSA9IFwiRG93bmxvYWQgc2hvcnQgd2l0aCBjb2JhbHRcIjtcclxuICAgICAgICAgICAgZG93bmxvYWRCdXR0b24uc3R5bGUucGFkZGluZ1RvcCA9IFwiMTZweFwiO1xyXG5cclxuICAgICAgICAgICAgLy8gQ3JlYXRlIHRoZSBlbGVtZW50cyB0aGF0IHJlc2lkZSBpbnNpZGUgdGhlIGJ1dHRvbiBidXQgZG9uJ3QgaGF2ZSBhbnkgc3BlY2lmaWMgcHJvcGVydGllcyB3ZSBuZWVkIHRvIGNoYW5nZVxyXG4gICAgICAgICAgICBjb25zdCBkb3dubG9hZEJ1dHRvbklubmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcclxuICAgICAgICAgICAgICBcInl0ZC1jb2JhbHQtYnV0dG9uLXJlbmRlcmVyXCJcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIjc2hhcmUtYnV0dG9uIHl0ZC1idXR0b24tcmVuZGVyZXJcIilcclxuICAgICAgICAgICAgICAgIC5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgZG93bmxvYWRCdXR0b25Jbm5lci5zZXRBdHRyaWJ1dGUoXCJ2ZXJ0aWNhbGx5LWFsaWduZWRcIiwgXCJcIik7XHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvblNoYXBlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcclxuICAgICAgICAgICAgICBcInl0LWNvYmFsdC1idXR0b24tc2hhcGVcIlxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uTGFiZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwibGFiZWxcIik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgICAgICAgLi4udGVtcGxhdGUucXVlcnlTZWxlY3RvcihcInl0LWJ1dHRvbi1zaGFwZSA+IGxhYmVsXCIpLmNsYXNzTGlzdFxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgLy8gVGhpcyBpcyB0aGUgYWN0dWFsIGJ1dHRvbiBpbnNpZGUgb2YgdGhlIGJ1dHRvbiB3cmFwcGVyXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkxhYmVsSW5uZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbElubmVyLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgICAgICAgLi4udGVtcGxhdGUucXVlcnlTZWxlY3RvcihcInl0LWJ1dHRvbi1zaGFwZSA+IGxhYmVsID4gYnV0dG9uXCIpXHJcbiAgICAgICAgICAgICAgICAuY2xhc3NMaXN0XHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSW5uZXIuc2V0QXR0cmlidXRlKFxyXG4gICAgICAgICAgICAgIFwiYXJpYS1sYWJlbFwiLFxyXG4gICAgICAgICAgICAgIFwiRG93bmxvYWQgdmlkZW8gd2l0aCBjb2JhbHRcIlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbElubmVyLnNldEF0dHJpYnV0ZShcInR5cGVcIiwgXCJidXR0b25cIik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSW5uZXIudGl0bGUgPSBcIkRvd25sb2FkIHZpZGVvIHdpdGggY29iYWx0XCI7XHJcblxyXG4gICAgICAgICAgICAvLyBGZWVkYmFjayBzaGFwZSBpcyByZXNwb25zaWJsZSBmb3Igc29tZSBuaWNoZSBtb2JpbGUvdG91Y2ggVUkgcmVzcG9uc2VcclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uRmVlZGJhY2tTaGFwZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXHJcbiAgICAgICAgICAgICAgXCJ5dC10b3VjaC1mZWVkYmFjay1zaGFwZVwiXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGJ1dHRvbkZlZWRiYWNrU2hhcGUuc3R5bGUuYm9yZGVyUmFkaXVzID0gXCJpbmhlcml0XCI7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBidXR0b25GZWVkYmFja1NoYXBlSW5uZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlSW5uZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi50ZW1wbGF0ZS5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICAgXCJ5dC1idXR0b24tc2hhcGUgbGFiZWwgeXQtdG91Y2gtZmVlZGJhY2stc2hhcGUgZGl2XCJcclxuICAgICAgICAgICAgICApLmNsYXNzTGlzdFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlSW5uZXIuc2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBidXR0b25GZWVkYmFja1NoYXBlSW5uZXJJbm5lcjEgPVxyXG4gICAgICAgICAgICAgIGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkZlZWRiYWNrU2hhcGVJbm5lcklubmVyMS5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLnRlbXBsYXRlLnF1ZXJ5U2VsZWN0b3JBbGwoXHJcbiAgICAgICAgICAgICAgICBcInl0LWJ1dHRvbi1zaGFwZSBsYWJlbCB5dC10b3VjaC1mZWVkYmFjay1zaGFwZSBkaXYgZGl2XCJcclxuICAgICAgICAgICAgICApWzBdLmNsYXNzTGlzdFxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVySW5uZXIyID1cclxuICAgICAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlSW5uZXJJbm5lcjIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi50ZW1wbGF0ZS5xdWVyeVNlbGVjdG9yQWxsKFxyXG4gICAgICAgICAgICAgICAgXCJ5dC1idXR0b24tc2hhcGUgbGFiZWwgeXQtdG91Y2gtZmVlZGJhY2stc2hhcGUgZGl2IGRpdlwiXHJcbiAgICAgICAgICAgICAgKVsxXS5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIC8vIFB1dCB0aGUgZmVlZGJhY2sgc2hhcGUgdG9nZXRoZXJcclxuICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVySW5uZXIxLmluc2VydEFkamFjZW50RWxlbWVudChcclxuICAgICAgICAgICAgICBcImFmdGVyZW5kXCIsXHJcbiAgICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZUlubmVySW5uZXIyXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIGJ1dHRvbkZlZWRiYWNrU2hhcGVJbm5lci5hcHBlbmRDaGlsZChcclxuICAgICAgICAgICAgICBidXR0b25GZWVkYmFja1NoYXBlSW5uZXJJbm5lcjFcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgYnV0dG9uRmVlZGJhY2tTaGFwZS5hcHBlbmRDaGlsZChidXR0b25GZWVkYmFja1NoYXBlSW5uZXIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbElubmVyLmFwcGVuZENoaWxkKGJ1dHRvbkZlZWRiYWNrU2hhcGUpO1xyXG5cclxuICAgICAgICAgICAgLy8gQ3JlYXRlIHRoZSBkb3dubG9hZCBpY29uXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkxhYmVsSWNvbk91dGVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uT3V0ZXIuY2xhc3NMaXN0LmFkZChcclxuICAgICAgICAgICAgICAuLi50ZW1wbGF0ZS5xdWVyeVNlbGVjdG9yKFxyXG4gICAgICAgICAgICAgICAgXCJ5dC1idXR0b24tc2hhcGUgPiBsYWJlbCA+IGJ1dHRvbiA+IGRpdlwiXHJcbiAgICAgICAgICAgICAgKS5jbGFzc0xpc3QsXHJcbiAgICAgICAgICAgICAgXCJ5dC1jb2JhbHQtYnV0dG9uLWljb25cIlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbEljb25PdXRlci5zZXRBdHRyaWJ1dGUoXCJhcmlhLWhpZGRlblwiLCB0cnVlKTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IGJ1dHRvbkxhYmVsSWNvbklubmVyID1cclxuICAgICAgICAgICAgICBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwieXQtY29iYWx0LWljb25cIik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSWNvbklubmVyLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgICAgICAgLi4udGVtcGxhdGUucXVlcnlTZWxlY3RvcihcclxuICAgICAgICAgICAgICAgIFwieXQtYnV0dG9uLXNoYXBlID4gbGFiZWwgPiBidXR0b24gPiBkaXYgPiB5dC1pY29uXCJcclxuICAgICAgICAgICAgICApLmNsYXNzTGlzdFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbEljb25Jbm5lci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIFwieXQtaWNvblwiLFxyXG4gICAgICAgICAgICAgIFwieXQtaWNvbi1zaGFwZVwiLFxyXG4gICAgICAgICAgICAgIFwieXQtc3BlYy1pY29uLXNoYXBlXCJcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uSW5uZXIuc3R5bGUud2lkdGggPSBcIjI0cHhcIjtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWxJY29uSW5uZXIuc3R5bGUuaGVpZ2h0ID0gXCIyNHB4XCI7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSWNvbklubmVyLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSWNvbklubmVyLmlubmVySFRNTCA9IGRvd25sb2FkSWNvbihcclxuICAgICAgICAgICAgICBidXR0b25MYWJlbEljb25Jbm5lci5jbGFzc0xpc3QudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgY29uc3QgYnV0dG9uSWNvbkxhYmVsT3V0ZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICAgICAgICBidXR0b25JY29uTGFiZWxPdXRlci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLnRlbXBsYXRlLnF1ZXJ5U2VsZWN0b3IoXCJ5dC1idXR0b24tc2hhcGUgPiBsYWJlbCA+IGRpdlwiKVxyXG4gICAgICAgICAgICAgICAgLmNsYXNzTGlzdFxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgYnV0dG9uSWNvbkxhYmVsT3V0ZXIuc2V0QXR0cmlidXRlKFwiYXJpYS1oaWRkZW5cIiwgdHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBidXR0b25JY29uTGFiZWxJbm5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xyXG4gICAgICAgICAgICBidXR0b25JY29uTGFiZWxJbm5lci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgIC4uLnRlbXBsYXRlLnF1ZXJ5U2VsZWN0b3IoXCJ5dC1idXR0b24tc2hhcGUgPiBsYWJlbCA+IGRpdiA+IHNwYW5cIilcclxuICAgICAgICAgICAgICAgIC5jbGFzc0xpc3RcclxuICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgIGJ1dHRvbkljb25MYWJlbElubmVyLnNldEF0dHJpYnV0ZShcInJvbGVcIiwgXCJ0ZXh0XCIpO1xyXG4gICAgICAgICAgICBidXR0b25JY29uTGFiZWxJbm5lci5pbm5lclRleHQgPSBcIlNhdmVcIjsgLy8gXCJTYXZlXCIgaW5zdGVhZCBvZiBcIkRvd25sb2FkXCIgYmVjYXVzZSBcIkRvd25sb2FkXCIgaXMgdG9vIGxvbmcgbG9sXHJcblxyXG4gICAgICAgICAgICAvLyBQdXQgZXZlcnl0aGluZyB0b2dldGhlciAoSSBoYXRlIHRoaXMgc28gbXVjaClcclxuICAgICAgICAgICAgYnV0dG9uSWNvbkxhYmVsT3V0ZXIuYXBwZW5kQ2hpbGQoYnV0dG9uSWNvbkxhYmVsSW5uZXIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbEljb25PdXRlci5hcHBlbmRDaGlsZChidXR0b25MYWJlbEljb25Jbm5lcik7XHJcbiAgICAgICAgICAgIGJ1dHRvbkxhYmVsSW5uZXIuYXBwZW5kQ2hpbGQoYnV0dG9uTGFiZWxJY29uT3V0ZXIpO1xyXG4gICAgICAgICAgICBidXR0b25MYWJlbC5hcHBlbmRDaGlsZChidXR0b25MYWJlbElubmVyKTtcclxuICAgICAgICAgICAgYnV0dG9uTGFiZWwuYXBwZW5kQ2hpbGQoYnV0dG9uSWNvbkxhYmVsT3V0ZXIpO1xyXG4gICAgICAgICAgICBidXR0b25TaGFwZS5hcHBlbmRDaGlsZChidXR0b25MYWJlbCk7XHJcbiAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uSW5uZXIuYXBwZW5kQ2hpbGQoYnV0dG9uU2hhcGUpO1xyXG4gICAgICAgICAgICBkb3dubG9hZEJ1dHRvbi5hcHBlbmRDaGlsZChkb3dubG9hZEJ1dHRvbklubmVyKTtcclxuXHJcbiAgICAgICAgICAgIGRvd25sb2FkQnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGdldFJlc291cmNlKHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcclxuICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICB0b29sQmFyXHJcbiAgICAgICAgICAgICAgPy5xdWVyeVNlbGVjdG9yKFwiI3NoYXJlLWJ1dHRvblwiKVxyXG4gICAgICAgICAgICAgIC5pbnNlcnRBZGphY2VudEVsZW1lbnQoXCJhZnRlcmVuZFwiLCBkb3dubG9hZEJ1dHRvbik7XHJcblxyXG4gICAgICAgICAgICAvLyBZb3VUdWJlIHNsaWdodGx5IGNoYW5nZXMgdGhlIGxvb2sgb2YgdGhlIGFjdGlvbiBidXR0b25zIChsaWtlLCBjb21tZW50LCBldGMpIHdoZW4gdGhlIGRlc2NyaXB0aW9uIGFuZCBjb21tZW50IHNlY3Rpb24gcGFuZWxzIGFyZSBleHBhbmRlZFxyXG4gICAgICAgICAgICAvLyBCb3RoIG9mIHRoZXNlIGV2ZW50IGxpc3RlbmVycyBydW4gaW4gcGFyYWxsZWwgdG8gZW5zdXJlIHRoYXQgdGhlIGNvcnJlY3QgYnV0dG9uIHN0eWxlcyBhcmUgYXBwbGllZCBldmVuIHdoZW4gc2ltcGx5IHRvZ2dsaW5nIGJldHdlZW4gdGhlIHBhbmVsc1xyXG4gICAgICAgICAgICAvLyBSZXZlcnNlLWVuZ2luZWVyaW5nIFlvdVR1ZSdzIGNvZGUgaXMgYSBwYWluLCBidXQgdGhpcyBpcyB0aGUgYmVzdCBJIGNvdWxkIGNvbWUgdXAgd2l0aFxyXG4gICAgICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwieXQtYWN0aW9uXCIsIChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAgZS5kZXRhaWwgJiZcclxuICAgICAgICAgICAgICAgIGUuZGV0YWlsLmFyZ3MgJiZcclxuICAgICAgICAgICAgICAgIGU/LmRldGFpbD8uYXJnc1sxXSA9PT0gXCJFTkdBR0VNRU5UX1BBTkVMX1ZJU0lCSUxJVFlfRVhQQU5ERURcIiAmJlxyXG4gICAgICAgICAgICAgICAgKGU/LmRldGFpbD8uYXJnc1syXSA9PT0gXCJlbmdhZ2VtZW50LXBhbmVsLWNvbW1lbnRzLXNlY3Rpb25cIiB8fFxyXG4gICAgICAgICAgICAgICAgICBlPy5kZXRhaWw/LmFyZ3NbMl0gPT09XHJcbiAgICAgICAgICAgICAgICAgICAgXCJlbmdhZ2VtZW50LXBhbmVsLXN0cnVjdHVyZWQtZGVzY3JpcHRpb25cIilcclxuICAgICAgICAgICAgICApIHtcclxuICAgICAgICAgICAgICAgIGxvZ2dlci5sb2coXCJlbmdhZ2VtZW50IHBhbmVsIHNob3duXCIsIGUpO1xyXG4gICAgICAgICAgICAgICAgYnV0dG9uTGFiZWxJbm5lci5jbGFzc0xpc3QuYWRkKFxyXG4gICAgICAgICAgICAgICAgICBcInl0LXNwZWMtYnV0dG9uLXNoYXBlLW5leHQtLW92ZXJsYXktZGFya1wiXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgZG93bmxvYWRCdXR0b24uc3R5bGUucGFkZGluZ1RvcCA9IFwiMHB4XCI7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInl0LWFjdGlvblwiLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmIChcclxuICAgICAgICAgICAgICAgIGUuZGV0YWlsICYmXHJcbiAgICAgICAgICAgICAgICBlLmRldGFpbC5hcmdzICYmXHJcbiAgICAgICAgICAgICAgICBlPy5kZXRhaWw/LmFyZ3NbMV0gPT09IFwiRU5HQUdFTUVOVF9QQU5FTF9WSVNJQklMSVRZX0hJRERFTlwiICYmXHJcbiAgICAgICAgICAgICAgICAoZT8uZGV0YWlsPy5hcmdzWzJdID09PSBcImVuZ2FnZW1lbnQtcGFuZWwtY29tbWVudHMtc2VjdGlvblwiIHx8XHJcbiAgICAgICAgICAgICAgICAgIGU/LmRldGFpbD8uYXJnc1syXSA9PT1cclxuICAgICAgICAgICAgICAgICAgICBcImVuZ2FnZW1lbnQtcGFuZWwtc3RydWN0dXJlZC1kZXNjcmlwdGlvblwiKVxyXG4gICAgICAgICAgICAgICkge1xyXG4gICAgICAgICAgICAgICAgbG9nZ2VyLmxvZyhcImVuZ2FnZW1lbnQgcGFuZWwgaGlkZGVuXCIsIGUpO1xyXG4gICAgICAgICAgICAgICAgYnV0dG9uTGFiZWxJbm5lci5jbGFzc0xpc3QucmVtb3ZlKFxyXG4gICAgICAgICAgICAgICAgICBcInl0LXNwZWMtYnV0dG9uLXNoYXBlLW5leHQtLW92ZXJsYXktZGFya1wiXHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgZG93bmxvYWRCdXR0b24uc3R5bGUucGFkZGluZ1RvcCA9IFwiMTZweFwiO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbndhdGNoUGFnZShhZGREb3dubG9hZEJ1dHRvbik7XHJcbiIsIi8vIFRoaXMgaXMgYSBtb2RpZmllZCB2ZXJzaW9uIG9mIHRoZSBcImVjaG9cIiBsb2dnZXIgY29uY2VwdCBmcm9tIGh0dHBzOi8vd3d3LmJlbm5hZGVsLmNvbS9ibG9nLzM5NDEtc3R5bGluZy1jb25zb2xlLWxvZy1vdXRwdXQtZm9ybWF0dGluZy13aXRoLWNzcy5odG1cclxuXHJcbmltcG9ydCB7IHZlcnNpb24gfSBmcm9tIFwiLi4vbWFuaWZlc3QuanNvblwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IGxvZ2dlciA9IChmdW5jdGlvbiAoKSB7XHJcbiAgdmFyIHF1ZXVlID0gW107XHJcbiAgdmFyIGxvZ2dlcl9UT0tFTiA9IHt9O1xyXG4gIHZhciBSRVNFVF9JTlBVVCA9IFwiJWMgXCI7XHJcbiAgdmFyIFJFU0VUX0NTUyA9IFwiXCI7XHJcblxyXG4gIGZ1bmN0aW9uIGFsZXJ0Rm9ybWF0dGluZyh2YWx1ZSkge1xyXG4gICAgcXVldWUucHVzaCh7XHJcbiAgICAgIHZhbHVlOiB2YWx1ZSxcclxuICAgICAgY3NzOiBcImRpc3BsYXk6IGlubGluZS1ibG9jayA7IGJhY2tncm91bmQtY29sb3I6ICNlMDAwNWEgOyBjb2xvcjogI2ZmZmZmZiA7IGZvbnQtd2VpZ2h0OiBib2xkIDsgcGFkZGluZzogM3B4IDdweCAzcHggN3B4IDsgYm9yZGVyLXJhZGl1czogM3B4IDNweCAzcHggM3B4IDtcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBsb2dnZXJfVE9LRU47XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiB3YXJuaW5nRm9ybWF0dGluZyh2YWx1ZSkge1xyXG4gICAgcXVldWUucHVzaCh7XHJcbiAgICAgIHZhbHVlOiB2YWx1ZSxcclxuICAgICAgY3NzOiBcImRpc3BsYXk6IGlubGluZS1ibG9jayA7IGJhY2tncm91bmQtY29sb3I6IGdvbGQgOyBjb2xvcjogYmxhY2sgOyBmb250LXdlaWdodDogYm9sZCA7IHBhZGRpbmc6IDNweCA3cHggM3B4IDdweCA7IGJvcmRlci1yYWRpdXM6IDNweCAzcHggM3B4IDNweCA7XCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9nZ2VyX1RPS0VOO1xyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gdGl0bGVGb3JtYXR0aW5nKHZhbHVlKSB7XHJcbiAgICBxdWV1ZS5wdXNoKHtcclxuICAgICAgdmFsdWU6IHZhbHVlLFxyXG4gICAgICBjc3M6IFwiZGlzcGxheTogaW5saW5lLWJsb2NrIDsgYmFja2dyb3VuZC1jb2xvcjogYmxhY2sgOyBjb2xvcjogd2hpdGUgOyBmb250LXdlaWdodDogYm9sZCA7IHBhZGRpbmc6IDNweCA3cHggM3B4IDdweCA7IGJvcmRlci1yYWRpdXM6IDNweCAzcHggM3B4IDNweCA7XCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbG9nZ2VyX1RPS0VOO1xyXG4gIH1cclxuXHJcbiAgLy8gSSBwcm92aWRlIGFuIGxvZ2dlci1iYXNlZCBwcm94eSB0byB0aGUgZ2l2ZW4gQ29uc29sZSBGdW5jdGlvbi4gVGhpcyB1c2VzIGFuXHJcbiAgLy8gaW50ZXJuYWwgcXVldWUgdG8gYWdncmVnYXRlIHZhbHVlcyBiZWZvcmUgY2FsbGluZyB0aGUgZ2l2ZW4gQ29uc29sZVxyXG4gIC8vIEZ1bmN0aW9uIHdpdGggdGhlIGRlc2lyZWQgZm9ybWF0dGluZy5cclxuICBmdW5jdGlvbiB1c2luZyhjb25zb2xlRnVuY3Rpb24pIHtcclxuICAgIGZ1bmN0aW9uIGNvbnNvbGVGdW5jdGlvblByb3h5KCkge1xyXG4gICAgICAvLyBBcyB3ZSBsb29wIG92ZXIgdGhlIGFyZ3VtZW50cywgd2UncmUgZ29pbmcgdG8gYWdncmVnYXRlIGEgc2V0IG9mXHJcbiAgICAgIC8vIGlucHV0cyBhbmQgbW9kaWZpZXJzLiBUaGUgSW5wdXRzIHdpbGwgdWx0aW1hdGVseSBiZSBjb2xsYXBzZWQgZG93blxyXG4gICAgICAvLyBpbnRvIGEgc2luZ2xlIHN0cmluZyB0aGF0IGFjdHMgYXMgdGhlIGZpcnN0IGNvbnNvbGUubG9nIHBhcmFtZXRlclxyXG4gICAgICAvLyB3aGlsZSB0aGUgbW9kaWZpZXJzIGFyZSB0aGVuIFNQUkVBRCBpbnRvIGNvbnNvbGUubG9nIGFzIDIuLi5OLlxyXG4gICAgICAvLyAtLVxyXG4gICAgICAvLyBOT1RFOiBBZnRlciBlYWNoIGlucHV0L21vZGlmaWVyIHBhaXIsIEknbSBhZGRpbmcgYSBSRVNFVCBwYWlyaW5nLlxyXG4gICAgICAvLyBUaGlzIGltcGxpY2l0bHkgcmVzZXRzIHRoZSBDU1MgYWZ0ZXIgZXZlcnkgZm9ybWF0dGVkIHBhaXJpbmcuXHJcbiAgICAgIHZhciBpbnB1dHMgPSBbXTtcclxuICAgICAgdmFyIG1vZGlmaWVycyA9IFtdO1xyXG5cclxuICAgICAgLy8gQWRkIHRoZSBjb2JhbHQtZXh0IGhlYWRlclxyXG4gICAgICBpbnB1dHMucHVzaChcIiVjXCIgKyBcImNvYmFsdC1leHRAXCIgKyB2ZXJzaW9uLCBSRVNFVF9JTlBVVCk7XHJcbiAgICAgIG1vZGlmaWVycy5wdXNoKFxyXG4gICAgICAgIFwiZGlzcGxheTogaW5saW5lLWJsb2NrOyBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjazsgY29sb3I6IHdoaXRlOyBmb250LXdlaWdodDogYm9sZDsgcGFkZGluZzogM3B4IDdweDsgYm9yZGVyLXJhZGl1czogM3B4O1wiLFxyXG4gICAgICAgIFJFU0VUX0NTU1xyXG4gICAgICApO1xyXG5cclxuICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAvLyBXaGVuIHRoZSBmb3JtYXR0aW5nIHV0aWxpdHkgbWV0aG9kcyBhcmUgY2FsbGVkLCB0aGV5IHJldHVyblxyXG4gICAgICAgIC8vIGEgc3BlY2lhbCB0b2tlbi4gVGhpcyBpbmRpY2F0ZXMgdGhhdCB3ZSBzaG91bGQgcHVsbCB0aGVcclxuICAgICAgICAvLyBjb3JyZXNwb25kaW5nIHZhbHVlIG91dCBvZiB0aGUgUVVFVUUgaW5zdGVhZCBvZiB0cnlpbmcgdG9cclxuICAgICAgICAvLyBvdXRwdXQgdGhlIGdpdmVuIGFyZ3VtZW50IGRpcmVjdGx5LlxyXG4gICAgICAgIGlmIChhcmd1bWVudHNbaV0gPT09IGxvZ2dlcl9UT0tFTikge1xyXG4gICAgICAgICAgdmFyIGl0ZW0gPSBxdWV1ZS5zaGlmdCgpO1xyXG5cclxuICAgICAgICAgIGlucHV0cy5wdXNoKFwiJWNcIiArIGl0ZW0udmFsdWUsIFJFU0VUX0lOUFVUKTtcclxuICAgICAgICAgIG1vZGlmaWVycy5wdXNoKGl0ZW0uY3NzLCBSRVNFVF9DU1MpO1xyXG5cclxuICAgICAgICAgIC8vIEZvciBldmVyeSBvdGhlciBhcmd1bWVudCB0eXBlLCBvdXRwdXQgdGhlIHZhbHVlIGRpcmVjdGx5LlxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB2YXIgYXJnID0gYXJndW1lbnRzW2ldO1xyXG5cclxuICAgICAgICAgIGlmICh0eXBlb2YgYXJnID09PSBcIm9iamVjdFwiIHx8IHR5cGVvZiBhcmcgPT09IFwiZnVuY3Rpb25cIikge1xyXG4gICAgICAgICAgICBpbnB1dHMucHVzaChcIiVvXCIsIFJFU0VUX0lOUFVUKTtcclxuICAgICAgICAgICAgbW9kaWZpZXJzLnB1c2goYXJnLCBSRVNFVF9DU1MpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgaW5wdXRzLnB1c2goXCIlY1wiICsgYXJnLCBSRVNFVF9JTlBVVCk7XHJcbiAgICAgICAgICAgIG1vZGlmaWVycy5wdXNoKFJFU0VUX0NTUywgUkVTRVRfQ1NTKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnNvbGVGdW5jdGlvbihpbnB1dHMuam9pbihcIlwiKSwgLi4ubW9kaWZpZXJzKTtcclxuXHJcbiAgICAgIC8vIE9uY2Ugd2Ugb3V0cHV0IHRoZSBhZ2dyZWdhdGVkIHZhbHVlLCByZXNldCB0aGUgcXVldWUuIFRoaXMgc2hvdWxkIGhhdmVcclxuICAgICAgLy8gYWxyZWFkeSBiZWVuIGVtcHRpZWQgYnkgdGhlIC5zaGlmdCgpIGNhbGxzOyBidXQgdGhlIGV4cGxpY2l0IHJlc2V0XHJcbiAgICAgIC8vIGhlcmUgYWN0cyBhcyBib3RoIGEgbWFya2VyIG9mIGludGVudGlvbiBhcyB3ZWxsIGFzIGEgZmFpbC1zYWZlLlxyXG4gICAgICBxdWV1ZSA9IFtdO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBjb25zb2xlRnVuY3Rpb25Qcm94eTtcclxuICB9XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICBsb2c6IHVzaW5nKGNvbnNvbGUubG9nKSxcclxuICAgIHdhcm46IHVzaW5nKGNvbnNvbGUud2FybiksXHJcbiAgICBlcnJvcjogdXNpbmcoY29uc29sZS5lcnJvciksXHJcbiAgICB0cmFjZTogdXNpbmcoY29uc29sZS50cmFjZSksXHJcblxyXG4gICAgYXNBbGVydDogYWxlcnRGb3JtYXR0aW5nLFxyXG4gICAgYXNXYXJuaW5nOiB3YXJuaW5nRm9ybWF0dGluZyxcclxuICAgIGFzVGl0bGU6IHRpdGxlRm9ybWF0dGluZyxcclxuICB9O1xyXG59KSgpO1xyXG4iLCJleHBvcnRzLmludGVyb3BEZWZhdWx0ID0gZnVuY3Rpb24gKGEpIHtcbiAgcmV0dXJuIGEgJiYgYS5fX2VzTW9kdWxlID8gYSA6IHtkZWZhdWx0OiBhfTtcbn07XG5cbmV4cG9ydHMuZGVmaW5lSW50ZXJvcEZsYWcgPSBmdW5jdGlvbiAoYSkge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYSwgJ19fZXNNb2R1bGUnLCB7dmFsdWU6IHRydWV9KTtcbn07XG5cbmV4cG9ydHMuZXhwb3J0QWxsID0gZnVuY3Rpb24gKHNvdXJjZSwgZGVzdCkge1xuICBPYmplY3Qua2V5cyhzb3VyY2UpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgIGlmIChcbiAgICAgIGtleSA9PT0gJ2RlZmF1bHQnIHx8XG4gICAgICBrZXkgPT09ICdfX2VzTW9kdWxlJyB8fFxuICAgICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGRlc3QsIGtleSlcbiAgICApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZGVzdCwga2V5LCB7XG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBzb3VyY2Vba2V5XTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIHJldHVybiBkZXN0O1xufTtcblxuZXhwb3J0cy5leHBvcnQgPSBmdW5jdGlvbiAoZGVzdCwgZGVzdE5hbWUsIGdldCkge1xuICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZGVzdCwgZGVzdE5hbWUsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZ2V0LFxuICB9KTtcbn07XG4iLCJpbXBvcnQgeyBsb2dnZXIgfSBmcm9tIFwiLi9sb2dnZXJcIjtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSZXNvdXJjZSh1cmwpIHtcclxuICBsb2dnZXIubG9nKFwicmVkaXJlY3RpbmcgdG8gY29iYWx0IHdlYnNpdGUgZm9yIFwiICsgdXJsICsgXCIuLi5cIik7XHJcblxyXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICB3aW5kb3cub3BlbihcImh0dHBzOi8vY29iYWx0LnRvb2xzLyNcIiArIHVybCwgXCJfYmxhbmtcIik7XHJcbiAgICByZXNvbHZlKHRydWUpO1xyXG4gIH0pO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gd2F0Y2hQYWdlKGNhbGxiYWNrKSB7XHJcbiAgbGV0IHNjaGVkdWxlZCA9IGZhbHNlO1xyXG5cclxuICBjb25zdCBvYnNlcnZlckNhbGxiYWNrID0gKCkgPT4ge1xyXG4gICAgaWYgKCFzY2hlZHVsZWQpIHtcclxuICAgICAgc2NoZWR1bGVkID0gdHJ1ZTtcclxuICAgICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcclxuICAgICAgICBjYWxsYmFjaygpO1xyXG4gICAgICAgIHNjaGVkdWxlZCA9IGZhbHNlO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKChtdXRhdGlvbnNMaXN0KSA9PiB7XHJcbiAgICBmb3IgKGNvbnN0IG11dGF0aW9uIG9mIG11dGF0aW9uc0xpc3QpIHtcclxuICAgICAgaWYgKG11dGF0aW9uLnR5cGUgPT09ICdjaGlsZExpc3QnKSB7XHJcbiAgICAgICAgb2JzZXJ2ZXJDYWxsYmFjaygpO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4gIG9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQsIHtcclxuICAgIGNoaWxkTGlzdDogdHJ1ZSxcclxuICAgIHN1YnRyZWU6IHRydWUsXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwidmVyc2lvbiI6MywiZmlsZSI6InlvdXR1YmUuSEFTSF9SRUZfNGI5OTk4MDAyMjBiNTUxMC5qcy5tYXAifQ==
