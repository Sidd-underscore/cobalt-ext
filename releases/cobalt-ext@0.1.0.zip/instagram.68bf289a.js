// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"l4uCa":[function(require,module,exports) {
var _logger = require("../common/logger");
var _utils = require("../common/utils");
(0, _logger.logger).log("Instagram detected!");
const downloadIcon = (classNames)=>{
    return `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-label="Download video with cobalt" class="${classNames}">
            <title>Download video with cobalt</title>
            <path d="M3 21C3 20.4477 3.44772 20 4 20H20C20.5523 20 21 20.4477 21 21C21 21.5523 20.5523 22 20 22H4C3.44772 22 3 21.5523 3 21Z" fill="white"/>
            <path d="M16.2071 11.7071C16.5976 11.3166 16.5976 10.6834 16.2071 10.2929C15.8166 9.90237 15.1834 9.90237 14.7929 10.2929L13 12.0858V13C13 13.5523 12.5523 14 12 14C11.4477 14 11 13.5523 11 13V12.0858L9.20711 10.2929C8.81658 9.90237 8.18342 9.90237 7.79289 10.2929C7.40237 10.6834 7.40237 11.3166 7.79289 11.7071L11.2929 15.2071C11.6834 15.5976 12.3166 15.5976 12.7071 15.2071L16.2071 11.7071Z" fill="white"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C11.4477 2 11 2.44772 11 3V12.0858L12 13.0858L13 12.0858V3C13 2.44772 12.5523 2 12 2Z" fill="white"/>
            <path d="M11 13C11 13.5523 11.4477 14 12 14C12.5523 14 13 13.5523 13 13V12.0858L12 13.0858L11 12.0858V13Z" fill="white"/>
        </svg>
      `;
};
function findReelLink(button) {
    function findAnchor(parentElement) {
        if (!parentElement || parentElement === document) return null;
        const anchors = Array.from(parentElement.getElementsByTagName("a"));
        const reelLinkAnchor = anchors.find((a)=>a.href.includes("liked_by"));
        if (reelLinkAnchor) return reelLinkAnchor.href.replace("liked_by/", "");
        return findAnchor(parentElement.parentElement);
    }
    return findAnchor(button.parentElement);
}
function addDownloadButton() {
    const muteButtonSelector = 'button[aria-label="Toggle audio"]';
    const muteButton = document.querySelectorAll(muteButtonSelector);
    muteButton.forEach((button)=>{
        if (!button.parentElement.querySelector('[cobalt-ext="instagram"]')) {
            const reelId = window.location.href.includes("/reel/") || window.location.href.includes("/p/") ? window.location.href : findReelLink(button);
            const downloadButton = document.createElement("button");
            downloadButton.classList.add(...button.classList);
            downloadButton.setAttribute("aria-label", "Download video with cobalt");
            downloadButton.setAttribute("type", "button");
            downloadButton.setAttribute("cobalt-ext", "instagram");
            const downloadButtonInner = document.createElement("div");
            downloadButtonInner.classList.add(...button.querySelector("div").classList);
            downloadButtonInner.style.padding = "7px";
            const svgClassNames = button.querySelector("div").querySelector("svg").classList.toString();
            downloadButtonInner.innerHTML = downloadIcon(svgClassNames);
            downloadButton.appendChild(downloadButtonInner);
            downloadButton.addEventListener("click", (e)=>{
                (0, _utils.getResource)(reelId);
            });
            button.parentElement.appendChild(downloadButton);
        }
    });
}
(0, _utils.watchPage)(addDownloadButton);

},{"../common/logger":"73tk1","../common/utils":"39Pbd"}],"73tk1":[function(require,module,exports) {
// This is a modified version of the "echo" logger concept from https://www.bennadel.com/blog/3941-styling-console-log-output-formatting-with-css.htm
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "logger", ()=>logger);
var _utilsJs = require("./utils.js");
const logger = function() {
    var queue = [];
    var logger_TOKEN = {};
    var RESET_INPUT = "%c ";
    var RESET_CSS = "";
    function alertFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: #e0005a ; color: #ffffff ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function warningFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: gold ; color: black ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    function titleFormatting(value) {
        queue.push({
            value: value,
            css: "display: inline-block ; background-color: black ; color: white ; font-weight: bold ; padding: 3px 7px 3px 7px ; border-radius: 3px 3px 3px 3px ;"
        });
        return logger_TOKEN;
    }
    // I provide an logger-based proxy to the given Console Function. This uses an
    // internal queue to aggregate values before calling the given Console
    // Function with the desired formatting.
    function using(consoleFunction) {
        function consoleFunctionProxy() {
            // As we loop over the arguments, we're going to aggregate a set of
            // inputs and modifiers. The Inputs will ultimately be collapsed down
            // into a single string that acts as the first console.log parameter
            // while the modifiers are then SPREAD into console.log as 2...N.
            // --
            // NOTE: After each input/modifier pair, I'm adding a RESET pairing.
            // This implicitly resets the CSS after every formatted pairing.
            var inputs = [];
            var modifiers = [];
            // Add the cobalt-ext header
            inputs.push("%ccobalt-ext@" + (0, _utilsJs.version), RESET_INPUT);
            modifiers.push("display: inline-block; background-color: black; color: white; font-weight: bold; padding: 3px 7px; border-radius: 3px;", RESET_CSS);
            for(var i = 0; i < arguments.length; i++)// When the formatting utility methods are called, they return
            // a special token. This indicates that we should pull the
            // corresponding value out of the QUEUE instead of trying to
            // output the given argument directly.
            if (arguments[i] === logger_TOKEN) {
                var item = queue.shift();
                inputs.push("%c" + item.value, RESET_INPUT);
                modifiers.push(item.css, RESET_CSS);
            // For every other argument type, output the value directly.
            } else {
                var arg = arguments[i];
                if (typeof arg === "object" || typeof arg === "function") {
                    inputs.push("%o", RESET_INPUT);
                    modifiers.push(arg, RESET_CSS);
                } else {
                    inputs.push("%c" + arg, RESET_INPUT);
                    modifiers.push(RESET_CSS, RESET_CSS);
                }
            }
            consoleFunction(inputs.join(""), ...modifiers);
            // Once we output the aggregated value, reset the queue. This should have
            // already been emptied by the .shift() calls; but the explicit reset
            // here acts as both a marker of intention as well as a fail-safe.
            queue = [];
        }
        return consoleFunctionProxy;
    }
    return {
        log: using(console.log),
        warn: using(console.warn),
        error: using(console.error),
        trace: using(console.trace),
        asAlert: alertFormatting,
        asWarning: warningFormatting,
        asTitle: titleFormatting
    };
}();

},{"@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS","./utils.js":"39Pbd"}],"aNjyS":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"39Pbd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "version", ()=>version);
parcelHelpers.export(exports, "getResource", ()=>getResource);
parcelHelpers.export(exports, "watchPage", ()=>watchPage);
var _logger = require("./logger");
const version = "0.1.0";
async function getResource(url) {
    (0, _logger.logger).log("redirecting to cobalt website for " + url + "...");
    return new Promise((resolve, reject)=>{
        window.open("https://cobalt.tools/#" + url, "_blank");
        resolve(true);
    });
}
function watchPage(callback) {
    let scheduled = false;
    const observerCallback = ()=>{
        if (!scheduled) {
            scheduled = true;
            requestAnimationFrame(()=>{
                callback();
                scheduled = false;
            });
        }
    };
    const observer = new MutationObserver((mutationsList)=>{
        for (const mutation of mutationsList)if (mutation.type === "childList") {
            observerCallback();
            break;
        }
    });
    observer.observe(document, {
        childList: true,
        subtree: true
    });
}

},{"./logger":"73tk1","@parcel/transformer-js/src/esmodule-helpers.js":"aNjyS"}]},["l4uCa"], "l4uCa", "parcelRequirea3c5")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQSxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDO0FBRVgsTUFBTSxlQUFlLENBQUM7SUFDcEIsT0FBTyxDQUFDO21IQUN5RyxFQUFFLFdBQVc7Ozs7Ozs7TUFPMUgsQ0FBQztBQUNQO0FBRUEsU0FBUyxhQUFhLE1BQU07SUFDMUIsU0FBUyxXQUFXLGFBQWE7UUFDL0IsSUFBSSxDQUFDLGlCQUFpQixrQkFBa0IsVUFDdEMsT0FBTztRQUdULE1BQU0sVUFBVSxNQUFNLElBQUksQ0FBQyxjQUFjLG9CQUFvQixDQUFDO1FBQzlELE1BQU0saUJBQWlCLFFBQVEsSUFBSSxDQUFDLENBQUMsSUFBTSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDM0QsSUFBSSxnQkFDRixPQUFPLGVBQWUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhO1FBR2xELE9BQU8sV0FBVyxjQUFjLGFBQWE7SUFDL0M7SUFFQSxPQUFPLFdBQVcsT0FBTyxhQUFhO0FBQ3hDO0FBRUEsU0FBUztJQUNQLE1BQU0scUJBQXFCO0lBQzNCLE1BQU0sYUFBYSxTQUFTLGdCQUFnQixDQUFDO0lBRTdDLFdBQVcsT0FBTyxDQUFDLENBQUM7UUFDbEIsSUFBSSxDQUFDLE9BQU8sYUFBYSxDQUFDLGFBQWEsQ0FBQyw2QkFBNkI7WUFDbkUsTUFBTSxTQUNKLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFDOUIsT0FBTyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUMxQixPQUFPLFFBQVEsQ0FBQyxJQUFJLEdBQ3BCLGFBQWE7WUFFbkIsTUFBTSxpQkFBaUIsU0FBUyxhQUFhLENBQUM7WUFDOUMsZUFBZSxTQUFTLENBQUMsR0FBRyxJQUFJLE9BQU8sU0FBUztZQUNoRCxlQUFlLFlBQVksQ0FBQyxjQUFjO1lBQzFDLGVBQWUsWUFBWSxDQUFDLFFBQVE7WUFDcEMsZUFBZSxZQUFZLENBQUMsY0FBYztZQUUxQyxNQUFNLHNCQUFzQixTQUFTLGFBQWEsQ0FBQztZQUNuRCxvQkFBb0IsU0FBUyxDQUFDLEdBQUcsSUFDNUIsT0FBTyxhQUFhLENBQUMsT0FBTyxTQUFTO1lBRzFDLG9CQUFvQixLQUFLLENBQUMsT0FBTyxHQUFHO1lBRXBDLE1BQU0sZ0JBQWdCLE9BQ25CLGFBQWEsQ0FBQyxPQUNkLGFBQWEsQ0FBQyxPQUNkLFNBQVMsQ0FBQyxRQUFRO1lBRXJCLG9CQUFvQixTQUFTLEdBQUcsYUFBYTtZQUU3QyxlQUFlLFdBQVcsQ0FBQztZQUUzQixlQUFlLGdCQUFnQixDQUFDLFNBQVMsQ0FBQztnQkFDeEMsQ0FBQSxHQUFBLGtCQUFXLEFBQUQsRUFBRTtZQUNkO1lBRUEsT0FBTyxhQUFhLENBQUMsV0FBVyxDQUFDO1FBQ25DO0lBQ0Y7QUFDRjtBQUVBLENBQUEsR0FBQSxnQkFBUyxBQUFELEVBQUU7OztBQzlFVixxSkFBcUo7Ozs0Q0FJeEk7QUFGYjtBQUVPLE1BQU0sU0FBUyxBQUFDO0lBQ3JCLElBQUksUUFBUSxFQUFFO0lBQ2QsSUFBSSxlQUFlLENBQUM7SUFDcEIsSUFBSSxjQUFjO0lBQ2xCLElBQUksWUFBWTtJQUVoQixTQUFTLGdCQUFnQixLQUFLO1FBQzVCLE1BQU0sSUFBSSxDQUFDO1lBQ1QsT0FBTztZQUNQLEtBQUs7UUFDUDtRQUVBLE9BQU87SUFDVDtJQUVBLFNBQVMsa0JBQWtCLEtBQUs7UUFDOUIsTUFBTSxJQUFJLENBQUM7WUFDVCxPQUFPO1lBQ1AsS0FBSztRQUNQO1FBRUEsT0FBTztJQUNUO0lBRUEsU0FBUyxnQkFBZ0IsS0FBSztRQUM1QixNQUFNLElBQUksQ0FBQztZQUNULE9BQU87WUFDUCxLQUFLO1FBQ1A7UUFFQSxPQUFPO0lBQ1Q7SUFFQSw4RUFBOEU7SUFDOUUsc0VBQXNFO0lBQ3RFLHdDQUF3QztJQUN4QyxTQUFTLE1BQU0sZUFBZTtRQUM1QixTQUFTO1lBQ1AsbUVBQW1FO1lBQ25FLHFFQUFxRTtZQUNyRSxvRUFBb0U7WUFDcEUsaUVBQWlFO1lBQ2pFLEtBQUs7WUFDTCxvRUFBb0U7WUFDcEUsZ0VBQWdFO1lBQ2hFLElBQUksU0FBUyxFQUFFO1lBQ2YsSUFBSSxZQUFZLEVBQUU7WUFFbEIsNEJBQTRCO1lBQzVCLE9BQU8sSUFBSSxDQUFDLGtCQUF1QixDQUFBLEdBQUEsZ0JBQU8sQUFBRCxHQUFHO1lBQzVDLFVBQVUsSUFBSSxDQUNaLDBIQUNBO1lBR0YsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsTUFBTSxFQUFFLElBQ3BDLDhEQUE4RDtZQUM5RCwwREFBMEQ7WUFDMUQsNERBQTREO1lBQzVELHNDQUFzQztZQUN0QyxJQUFJLFNBQVMsQ0FBQyxFQUFFLEtBQUssY0FBYztnQkFDakMsSUFBSSxPQUFPLE1BQU0sS0FBSztnQkFFdEIsT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLEtBQUssRUFBRTtnQkFDL0IsVUFBVSxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUU7WUFFekIsNERBQTREO1lBQzlELE9BQU87Z0JBQ0wsSUFBSSxNQUFNLFNBQVMsQ0FBQyxFQUFFO2dCQUV0QixJQUFJLE9BQU8sUUFBUSxZQUFZLE9BQU8sUUFBUSxZQUFZO29CQUN4RCxPQUFPLElBQUksQ0FBQyxNQUFNO29CQUNsQixVQUFVLElBQUksQ0FBQyxLQUFLO2dCQUN0QixPQUFPO29CQUNMLE9BQU8sSUFBSSxDQUFDLE9BQU8sS0FBSztvQkFDeEIsVUFBVSxJQUFJLENBQUMsV0FBVztnQkFDNUI7WUFDRjtZQUdGLGdCQUFnQixPQUFPLElBQUksQ0FBQyxRQUFRO1lBRXBDLHlFQUF5RTtZQUN6RSxxRUFBcUU7WUFDckUsa0VBQWtFO1lBQ2xFLFFBQVEsRUFBRTtRQUNaO1FBRUEsT0FBTztJQUNUO0lBRUEsT0FBTztRQUNMLEtBQUssTUFBTSxRQUFRLEdBQUc7UUFDdEIsTUFBTSxNQUFNLFFBQVEsSUFBSTtRQUN4QixPQUFPLE1BQU0sUUFBUSxLQUFLO1FBQzFCLE9BQU8sTUFBTSxRQUFRLEtBQUs7UUFFMUIsU0FBUztRQUNULFdBQVc7UUFDWCxTQUFTO0lBQ1g7QUFDRjs7O0FDekdBLFFBQVEsY0FBYyxHQUFHLFNBQVUsQ0FBQztJQUNsQyxPQUFPLEtBQUssRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUFDLFNBQVM7SUFBQztBQUM1QztBQUVBLFFBQVEsaUJBQWlCLEdBQUcsU0FBVSxDQUFDO0lBQ3JDLE9BQU8sY0FBYyxDQUFDLEdBQUcsY0FBYztRQUFDLE9BQU87SUFBSTtBQUNyRDtBQUVBLFFBQVEsU0FBUyxHQUFHLFNBQVUsTUFBTSxFQUFFLElBQUk7SUFDeEMsT0FBTyxJQUFJLENBQUMsUUFBUSxPQUFPLENBQUMsU0FBVSxHQUFHO1FBQ3ZDLElBQ0UsUUFBUSxhQUNSLFFBQVEsZ0JBQ1IsT0FBTyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLE1BRTNDO1FBR0YsT0FBTyxjQUFjLENBQUMsTUFBTSxLQUFLO1lBQy9CLFlBQVk7WUFDWixLQUFLO2dCQUNILE9BQU8sTUFBTSxDQUFDLElBQUk7WUFDcEI7UUFDRjtJQUNGO0lBRUEsT0FBTztBQUNUO0FBRUEsUUFBUSxNQUFNLEdBQUcsU0FBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFDNUMsT0FBTyxjQUFjLENBQUMsTUFBTSxVQUFVO1FBQ3BDLFlBQVk7UUFDWixLQUFLO0lBQ1A7QUFDRjs7Ozs7NkNDaENhO0FBRWIsaURBQXNCO0FBU3RCLCtDQUFnQjtBQWJoQjtBQUVPLE1BQU0sVUFBVTtBQUVoQixlQUFlLFlBQVksR0FBRztJQUNuQyxDQUFBLEdBQUEsY0FBTSxBQUFELEVBQUUsR0FBRyxDQUFDLHVDQUF1QyxNQUFNO0lBRXhELE9BQU8sSUFBSSxRQUFRLENBQUMsU0FBUztRQUMzQixPQUFPLElBQUksQ0FBQywyQkFBMkIsS0FBSztRQUM1QyxRQUFRO0lBQ1Y7QUFDRjtBQUVPLFNBQVMsVUFBVSxRQUFRO0lBQ2hDLElBQUksWUFBWTtJQUVoQixNQUFNLG1CQUFtQjtRQUN2QixJQUFJLENBQUMsV0FBVztZQUNkLFlBQVk7WUFDWixzQkFBc0I7Z0JBQ3BCO2dCQUNBLFlBQVk7WUFDZDtRQUNGO0lBQ0Y7SUFFQSxNQUFNLFdBQVcsSUFBSSxpQkFBaUIsQ0FBQztRQUNyQyxLQUFLLE1BQU0sWUFBWSxjQUNyQixJQUFJLFNBQVMsSUFBSSxLQUFLLGFBQWE7WUFDakM7WUFDQTtRQUNGO0lBRUo7SUFFQSxTQUFTLE9BQU8sQ0FBQyxVQUFVO1FBQ3pCLFdBQVc7UUFDWCxTQUFTO0lBQ1g7QUFDRiIsInNvdXJjZXMiOlsic3JjL3NlcnZpY2VzL2luc3RhZ3JhbS5qcyIsInNyYy9jb21tb24vbG9nZ2VyLmpzIiwibm9kZV9tb2R1bGVzL0BwYXJjZWwvY29uZmlnLXdlYmV4dGVuc2lvbi9ub2RlX21vZHVsZXMvQHBhcmNlbC90cmFuc2Zvcm1lci1qcy9zcmMvZXNtb2R1bGUtaGVscGVycy5qcyIsInNyYy9jb21tb24vdXRpbHMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSBcIi4uL2NvbW1vbi9sb2dnZXJcIjtcclxuaW1wb3J0IHsgZ2V0UmVzb3VyY2UsIHdhdGNoUGFnZSB9IGZyb20gXCIuLi9jb21tb24vdXRpbHNcIjtcclxuXHJcbmxvZ2dlci5sb2coXCJJbnN0YWdyYW0gZGV0ZWN0ZWQhXCIpO1xyXG5cclxuY29uc3QgZG93bmxvYWRJY29uID0gKGNsYXNzTmFtZXMpID0+IHtcclxuICByZXR1cm4gYFxyXG4gICAgICAgIDxzdmcgd2lkdGg9XCIxNFwiIGhlaWdodD1cIjE0XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIGZpbGw9XCJub25lXCIgYXJpYS1sYWJlbD1cIkRvd25sb2FkIHZpZGVvIHdpdGggY29iYWx0XCIgY2xhc3M9XCIke2NsYXNzTmFtZXN9XCI+XHJcbiAgICAgICAgICAgIDx0aXRsZT5Eb3dubG9hZCB2aWRlbyB3aXRoIGNvYmFsdDwvdGl0bGU+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMyAyMUMzIDIwLjQ0NzcgMy40NDc3MiAyMCA0IDIwSDIwQzIwLjU1MjMgMjAgMjEgMjAuNDQ3NyAyMSAyMUMyMSAyMS41NTIzIDIwLjU1MjMgMjIgMjAgMjJINEMzLjQ0NzcyIDIyIDMgMjEuNTUyMyAzIDIxWlwiIGZpbGw9XCJ3aGl0ZVwiLz5cclxuICAgICAgICAgICAgPHBhdGggZD1cIk0xNi4yMDcxIDExLjcwNzFDMTYuNTk3NiAxMS4zMTY2IDE2LjU5NzYgMTAuNjgzNCAxNi4yMDcxIDEwLjI5MjlDMTUuODE2NiA5LjkwMjM3IDE1LjE4MzQgOS45MDIzNyAxNC43OTI5IDEwLjI5MjlMMTMgMTIuMDg1OFYxM0MxMyAxMy41NTIzIDEyLjU1MjMgMTQgMTIgMTRDMTEuNDQ3NyAxNCAxMSAxMy41NTIzIDExIDEzVjEyLjA4NThMOS4yMDcxMSAxMC4yOTI5QzguODE2NTggOS45MDIzNyA4LjE4MzQyIDkuOTAyMzcgNy43OTI4OSAxMC4yOTI5QzcuNDAyMzcgMTAuNjgzNCA3LjQwMjM3IDExLjMxNjYgNy43OTI4OSAxMS43MDcxTDExLjI5MjkgMTUuMjA3MUMxMS42ODM0IDE1LjU5NzYgMTIuMzE2NiAxNS41OTc2IDEyLjcwNzEgMTUuMjA3MUwxNi4yMDcxIDExLjcwNzFaXCIgZmlsbD1cIndoaXRlXCIvPlxyXG4gICAgICAgICAgICA8cGF0aCBmaWxsLXJ1bGU9XCJldmVub2RkXCIgY2xpcC1ydWxlPVwiZXZlbm9kZFwiIGQ9XCJNMTIgMkMxMS40NDc3IDIgMTEgMi40NDc3MiAxMSAzVjEyLjA4NThMMTIgMTMuMDg1OEwxMyAxMi4wODU4VjNDMTMgMi40NDc3MiAxMi41NTIzIDIgMTIgMlpcIiBmaWxsPVwid2hpdGVcIi8+XHJcbiAgICAgICAgICAgIDxwYXRoIGQ9XCJNMTEgMTNDMTEgMTMuNTUyMyAxMS40NDc3IDE0IDEyIDE0QzEyLjU1MjMgMTQgMTMgMTMuNTUyMyAxMyAxM1YxMi4wODU4TDEyIDEzLjA4NThMMTEgMTIuMDg1OFYxM1pcIiBmaWxsPVwid2hpdGVcIi8+XHJcbiAgICAgICAgPC9zdmc+XHJcbiAgICAgIGA7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBmaW5kUmVlbExpbmsoYnV0dG9uKSB7XHJcbiAgZnVuY3Rpb24gZmluZEFuY2hvcihwYXJlbnRFbGVtZW50KSB7XHJcbiAgICBpZiAoIXBhcmVudEVsZW1lbnQgfHwgcGFyZW50RWxlbWVudCA9PT0gZG9jdW1lbnQpIHtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgYW5jaG9ycyA9IEFycmF5LmZyb20ocGFyZW50RWxlbWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcImFcIikpO1xyXG4gICAgY29uc3QgcmVlbExpbmtBbmNob3IgPSBhbmNob3JzLmZpbmQoKGEpID0+IGEuaHJlZi5pbmNsdWRlcyhcImxpa2VkX2J5XCIpKTtcclxuICAgIGlmIChyZWVsTGlua0FuY2hvcikge1xyXG4gICAgICByZXR1cm4gcmVlbExpbmtBbmNob3IuaHJlZi5yZXBsYWNlKFwibGlrZWRfYnkvXCIsIFwiXCIpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBmaW5kQW5jaG9yKHBhcmVudEVsZW1lbnQucGFyZW50RWxlbWVudCk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gZmluZEFuY2hvcihidXR0b24ucGFyZW50RWxlbWVudCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIGFkZERvd25sb2FkQnV0dG9uKCkge1xyXG4gIGNvbnN0IG11dGVCdXR0b25TZWxlY3RvciA9ICdidXR0b25bYXJpYS1sYWJlbD1cIlRvZ2dsZSBhdWRpb1wiXSc7XHJcbiAgY29uc3QgbXV0ZUJ1dHRvbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwobXV0ZUJ1dHRvblNlbGVjdG9yKTtcclxuXHJcbiAgbXV0ZUJ1dHRvbi5mb3JFYWNoKChidXR0b24pID0+IHtcclxuICAgIGlmICghYnV0dG9uLnBhcmVudEVsZW1lbnQucXVlcnlTZWxlY3RvcignW2NvYmFsdC1leHQ9XCJpbnN0YWdyYW1cIl0nKSkge1xyXG4gICAgICBjb25zdCByZWVsSWQgPVxyXG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmLmluY2x1ZGVzKFwiL3JlZWwvXCIpIHx8XHJcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLmhyZWYuaW5jbHVkZXMoXCIvcC9cIilcclxuICAgICAgICAgID8gd2luZG93LmxvY2F0aW9uLmhyZWZcclxuICAgICAgICAgIDogZmluZFJlZWxMaW5rKGJ1dHRvbik7XHJcblxyXG4gICAgICBjb25zdCBkb3dubG9hZEJ1dHRvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJidXR0b25cIik7XHJcbiAgICAgIGRvd25sb2FkQnV0dG9uLmNsYXNzTGlzdC5hZGQoLi4uYnV0dG9uLmNsYXNzTGlzdCk7XHJcbiAgICAgIGRvd25sb2FkQnV0dG9uLnNldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIiwgXCJEb3dubG9hZCB2aWRlbyB3aXRoIGNvYmFsdFwiKTtcclxuICAgICAgZG93bmxvYWRCdXR0b24uc2V0QXR0cmlidXRlKFwidHlwZVwiLCBcImJ1dHRvblwiKTtcclxuICAgICAgZG93bmxvYWRCdXR0b24uc2V0QXR0cmlidXRlKFwiY29iYWx0LWV4dFwiLCBcImluc3RhZ3JhbVwiKTtcclxuXHJcbiAgICAgIGNvbnN0IGRvd25sb2FkQnV0dG9uSW5uZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xyXG4gICAgICBkb3dubG9hZEJ1dHRvbklubmVyLmNsYXNzTGlzdC5hZGQoXHJcbiAgICAgICAgLi4uYnV0dG9uLnF1ZXJ5U2VsZWN0b3IoXCJkaXZcIikuY2xhc3NMaXN0XHJcbiAgICAgICk7XHJcblxyXG4gICAgICBkb3dubG9hZEJ1dHRvbklubmVyLnN0eWxlLnBhZGRpbmcgPSBcIjdweFwiO1xyXG5cclxuICAgICAgY29uc3Qgc3ZnQ2xhc3NOYW1lcyA9IGJ1dHRvblxyXG4gICAgICAgIC5xdWVyeVNlbGVjdG9yKFwiZGl2XCIpXHJcbiAgICAgICAgLnF1ZXJ5U2VsZWN0b3IoXCJzdmdcIilcclxuICAgICAgICAuY2xhc3NMaXN0LnRvU3RyaW5nKCk7XHJcblxyXG4gICAgICBkb3dubG9hZEJ1dHRvbklubmVyLmlubmVySFRNTCA9IGRvd25sb2FkSWNvbihzdmdDbGFzc05hbWVzKTtcclxuXHJcbiAgICAgIGRvd25sb2FkQnV0dG9uLmFwcGVuZENoaWxkKGRvd25sb2FkQnV0dG9uSW5uZXIpO1xyXG5cclxuICAgICAgZG93bmxvYWRCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChlKSA9PiB7XHJcbiAgICAgICAgZ2V0UmVzb3VyY2UocmVlbElkKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBidXR0b24ucGFyZW50RWxlbWVudC5hcHBlbmRDaGlsZChkb3dubG9hZEJ1dHRvbik7XHJcbiAgICB9XHJcbiAgfSk7XHJcbn1cclxuXHJcbndhdGNoUGFnZShhZGREb3dubG9hZEJ1dHRvbik7IiwiLy8gVGhpcyBpcyBhIG1vZGlmaWVkIHZlcnNpb24gb2YgdGhlIFwiZWNob1wiIGxvZ2dlciBjb25jZXB0IGZyb20gaHR0cHM6Ly93d3cuYmVubmFkZWwuY29tL2Jsb2cvMzk0MS1zdHlsaW5nLWNvbnNvbGUtbG9nLW91dHB1dC1mb3JtYXR0aW5nLXdpdGgtY3NzLmh0bVxyXG5cclxuaW1wb3J0IHsgdmVyc2lvbiB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgbG9nZ2VyID0gKGZ1bmN0aW9uICgpIHtcclxuICB2YXIgcXVldWUgPSBbXTtcclxuICB2YXIgbG9nZ2VyX1RPS0VOID0ge307XHJcbiAgdmFyIFJFU0VUX0lOUFVUID0gXCIlYyBcIjtcclxuICB2YXIgUkVTRVRfQ1NTID0gXCJcIjtcclxuXHJcbiAgZnVuY3Rpb24gYWxlcnRGb3JtYXR0aW5nKHZhbHVlKSB7XHJcbiAgICBxdWV1ZS5wdXNoKHtcclxuICAgICAgdmFsdWU6IHZhbHVlLFxyXG4gICAgICBjc3M6IFwiZGlzcGxheTogaW5saW5lLWJsb2NrIDsgYmFja2dyb3VuZC1jb2xvcjogI2UwMDA1YSA7IGNvbG9yOiAjZmZmZmZmIDsgZm9udC13ZWlnaHQ6IGJvbGQgOyBwYWRkaW5nOiAzcHggN3B4IDNweCA3cHggOyBib3JkZXItcmFkaXVzOiAzcHggM3B4IDNweCAzcHggO1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIGxvZ2dlcl9UT0tFTjtcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHdhcm5pbmdGb3JtYXR0aW5nKHZhbHVlKSB7XHJcbiAgICBxdWV1ZS5wdXNoKHtcclxuICAgICAgdmFsdWU6IHZhbHVlLFxyXG4gICAgICBjc3M6IFwiZGlzcGxheTogaW5saW5lLWJsb2NrIDsgYmFja2dyb3VuZC1jb2xvcjogZ29sZCA7IGNvbG9yOiBibGFjayA7IGZvbnQtd2VpZ2h0OiBib2xkIDsgcGFkZGluZzogM3B4IDdweCAzcHggN3B4IDsgYm9yZGVyLXJhZGl1czogM3B4IDNweCAzcHggM3B4IDtcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBsb2dnZXJfVE9LRU47XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiB0aXRsZUZvcm1hdHRpbmcodmFsdWUpIHtcclxuICAgIHF1ZXVlLnB1c2goe1xyXG4gICAgICB2YWx1ZTogdmFsdWUsXHJcbiAgICAgIGNzczogXCJkaXNwbGF5OiBpbmxpbmUtYmxvY2sgOyBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjayA7IGNvbG9yOiB3aGl0ZSA7IGZvbnQtd2VpZ2h0OiBib2xkIDsgcGFkZGluZzogM3B4IDdweCAzcHggN3B4IDsgYm9yZGVyLXJhZGl1czogM3B4IDNweCAzcHggM3B4IDtcIixcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBsb2dnZXJfVE9LRU47XHJcbiAgfVxyXG5cclxuICAvLyBJIHByb3ZpZGUgYW4gbG9nZ2VyLWJhc2VkIHByb3h5IHRvIHRoZSBnaXZlbiBDb25zb2xlIEZ1bmN0aW9uLiBUaGlzIHVzZXMgYW5cclxuICAvLyBpbnRlcm5hbCBxdWV1ZSB0byBhZ2dyZWdhdGUgdmFsdWVzIGJlZm9yZSBjYWxsaW5nIHRoZSBnaXZlbiBDb25zb2xlXHJcbiAgLy8gRnVuY3Rpb24gd2l0aCB0aGUgZGVzaXJlZCBmb3JtYXR0aW5nLlxyXG4gIGZ1bmN0aW9uIHVzaW5nKGNvbnNvbGVGdW5jdGlvbikge1xyXG4gICAgZnVuY3Rpb24gY29uc29sZUZ1bmN0aW9uUHJveHkoKSB7XHJcbiAgICAgIC8vIEFzIHdlIGxvb3Agb3ZlciB0aGUgYXJndW1lbnRzLCB3ZSdyZSBnb2luZyB0byBhZ2dyZWdhdGUgYSBzZXQgb2ZcclxuICAgICAgLy8gaW5wdXRzIGFuZCBtb2RpZmllcnMuIFRoZSBJbnB1dHMgd2lsbCB1bHRpbWF0ZWx5IGJlIGNvbGxhcHNlZCBkb3duXHJcbiAgICAgIC8vIGludG8gYSBzaW5nbGUgc3RyaW5nIHRoYXQgYWN0cyBhcyB0aGUgZmlyc3QgY29uc29sZS5sb2cgcGFyYW1ldGVyXHJcbiAgICAgIC8vIHdoaWxlIHRoZSBtb2RpZmllcnMgYXJlIHRoZW4gU1BSRUFEIGludG8gY29uc29sZS5sb2cgYXMgMi4uLk4uXHJcbiAgICAgIC8vIC0tXHJcbiAgICAgIC8vIE5PVEU6IEFmdGVyIGVhY2ggaW5wdXQvbW9kaWZpZXIgcGFpciwgSSdtIGFkZGluZyBhIFJFU0VUIHBhaXJpbmcuXHJcbiAgICAgIC8vIFRoaXMgaW1wbGljaXRseSByZXNldHMgdGhlIENTUyBhZnRlciBldmVyeSBmb3JtYXR0ZWQgcGFpcmluZy5cclxuICAgICAgdmFyIGlucHV0cyA9IFtdO1xyXG4gICAgICB2YXIgbW9kaWZpZXJzID0gW107XHJcblxyXG4gICAgICAvLyBBZGQgdGhlIGNvYmFsdC1leHQgaGVhZGVyXHJcbiAgICAgIGlucHV0cy5wdXNoKFwiJWNcIiArIFwiY29iYWx0LWV4dEBcIiArIHZlcnNpb24sIFJFU0VUX0lOUFVUKTtcclxuICAgICAgbW9kaWZpZXJzLnB1c2goXHJcbiAgICAgICAgXCJkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IGJhY2tncm91bmQtY29sb3I6IGJsYWNrOyBjb2xvcjogd2hpdGU7IGZvbnQtd2VpZ2h0OiBib2xkOyBwYWRkaW5nOiAzcHggN3B4OyBib3JkZXItcmFkaXVzOiAzcHg7XCIsXHJcbiAgICAgICAgUkVTRVRfQ1NTXHJcbiAgICAgICk7XHJcblxyXG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgIC8vIFdoZW4gdGhlIGZvcm1hdHRpbmcgdXRpbGl0eSBtZXRob2RzIGFyZSBjYWxsZWQsIHRoZXkgcmV0dXJuXHJcbiAgICAgICAgLy8gYSBzcGVjaWFsIHRva2VuLiBUaGlzIGluZGljYXRlcyB0aGF0IHdlIHNob3VsZCBwdWxsIHRoZVxyXG4gICAgICAgIC8vIGNvcnJlc3BvbmRpbmcgdmFsdWUgb3V0IG9mIHRoZSBRVUVVRSBpbnN0ZWFkIG9mIHRyeWluZyB0b1xyXG4gICAgICAgIC8vIG91dHB1dCB0aGUgZ2l2ZW4gYXJndW1lbnQgZGlyZWN0bHkuXHJcbiAgICAgICAgaWYgKGFyZ3VtZW50c1tpXSA9PT0gbG9nZ2VyX1RPS0VOKSB7XHJcbiAgICAgICAgICB2YXIgaXRlbSA9IHF1ZXVlLnNoaWZ0KCk7XHJcblxyXG4gICAgICAgICAgaW5wdXRzLnB1c2goXCIlY1wiICsgaXRlbS52YWx1ZSwgUkVTRVRfSU5QVVQpO1xyXG4gICAgICAgICAgbW9kaWZpZXJzLnB1c2goaXRlbS5jc3MsIFJFU0VUX0NTUyk7XHJcblxyXG4gICAgICAgICAgLy8gRm9yIGV2ZXJ5IG90aGVyIGFyZ3VtZW50IHR5cGUsIG91dHB1dCB0aGUgdmFsdWUgZGlyZWN0bHkuXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHZhciBhcmcgPSBhcmd1bWVudHNbaV07XHJcblxyXG4gICAgICAgICAgaWYgKHR5cGVvZiBhcmcgPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGFyZyA9PT0gXCJmdW5jdGlvblwiKSB7XHJcbiAgICAgICAgICAgIGlucHV0cy5wdXNoKFwiJW9cIiwgUkVTRVRfSU5QVVQpO1xyXG4gICAgICAgICAgICBtb2RpZmllcnMucHVzaChhcmcsIFJFU0VUX0NTUyk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBpbnB1dHMucHVzaChcIiVjXCIgKyBhcmcsIFJFU0VUX0lOUFVUKTtcclxuICAgICAgICAgICAgbW9kaWZpZXJzLnB1c2goUkVTRVRfQ1NTLCBSRVNFVF9DU1MpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc29sZUZ1bmN0aW9uKGlucHV0cy5qb2luKFwiXCIpLCAuLi5tb2RpZmllcnMpO1xyXG5cclxuICAgICAgLy8gT25jZSB3ZSBvdXRwdXQgdGhlIGFnZ3JlZ2F0ZWQgdmFsdWUsIHJlc2V0IHRoZSBxdWV1ZS4gVGhpcyBzaG91bGQgaGF2ZVxyXG4gICAgICAvLyBhbHJlYWR5IGJlZW4gZW1wdGllZCBieSB0aGUgLnNoaWZ0KCkgY2FsbHM7IGJ1dCB0aGUgZXhwbGljaXQgcmVzZXRcclxuICAgICAgLy8gaGVyZSBhY3RzIGFzIGJvdGggYSBtYXJrZXIgb2YgaW50ZW50aW9uIGFzIHdlbGwgYXMgYSBmYWlsLXNhZmUuXHJcbiAgICAgIHF1ZXVlID0gW107XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGNvbnNvbGVGdW5jdGlvblByb3h5O1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHtcclxuICAgIGxvZzogdXNpbmcoY29uc29sZS5sb2cpLFxyXG4gICAgd2FybjogdXNpbmcoY29uc29sZS53YXJuKSxcclxuICAgIGVycm9yOiB1c2luZyhjb25zb2xlLmVycm9yKSxcclxuICAgIHRyYWNlOiB1c2luZyhjb25zb2xlLnRyYWNlKSxcclxuXHJcbiAgICBhc0FsZXJ0OiBhbGVydEZvcm1hdHRpbmcsXHJcbiAgICBhc1dhcm5pbmc6IHdhcm5pbmdGb3JtYXR0aW5nLFxyXG4gICAgYXNUaXRsZTogdGl0bGVGb3JtYXR0aW5nLFxyXG4gIH07XHJcbn0pKCk7XHJcbiIsImV4cG9ydHMuaW50ZXJvcERlZmF1bHQgPSBmdW5jdGlvbiAoYSkge1xuICByZXR1cm4gYSAmJiBhLl9fZXNNb2R1bGUgPyBhIDoge2RlZmF1bHQ6IGF9O1xufTtcblxuZXhwb3J0cy5kZWZpbmVJbnRlcm9wRmxhZyA9IGZ1bmN0aW9uIChhKSB7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhLCAnX19lc01vZHVsZScsIHt2YWx1ZTogdHJ1ZX0pO1xufTtcblxuZXhwb3J0cy5leHBvcnRBbGwgPSBmdW5jdGlvbiAoc291cmNlLCBkZXN0KSB7XG4gIE9iamVjdC5rZXlzKHNvdXJjZSkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgaWYgKFxuICAgICAga2V5ID09PSAnZGVmYXVsdCcgfHxcbiAgICAgIGtleSA9PT0gJ19fZXNNb2R1bGUnIHx8XG4gICAgICBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZGVzdCwga2V5KVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShkZXN0LCBrZXksIHtcbiAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgcmV0dXJuIHNvdXJjZVtrZXldO1xuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgcmV0dXJuIGRlc3Q7XG59O1xuXG5leHBvcnRzLmV4cG9ydCA9IGZ1bmN0aW9uIChkZXN0LCBkZXN0TmFtZSwgZ2V0KSB7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShkZXN0LCBkZXN0TmFtZSwge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBnZXQsXG4gIH0pO1xufTtcbiIsImltcG9ydCB7IGxvZ2dlciB9IGZyb20gXCIuL2xvZ2dlclwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IHZlcnNpb24gPSBcIjAuMS4wXCI7XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVzb3VyY2UodXJsKSB7XHJcbiAgbG9nZ2VyLmxvZyhcInJlZGlyZWN0aW5nIHRvIGNvYmFsdCB3ZWJzaXRlIGZvciBcIiArIHVybCArIFwiLi4uXCIpO1xyXG5cclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgd2luZG93Lm9wZW4oXCJodHRwczovL2NvYmFsdC50b29scy8jXCIgKyB1cmwsIFwiX2JsYW5rXCIpO1xyXG4gICAgcmVzb2x2ZSh0cnVlKTtcclxuICB9KTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHdhdGNoUGFnZShjYWxsYmFjaykge1xyXG4gIGxldCBzY2hlZHVsZWQgPSBmYWxzZTtcclxuXHJcbiAgY29uc3Qgb2JzZXJ2ZXJDYWxsYmFjayA9ICgpID0+IHtcclxuICAgIGlmICghc2NoZWR1bGVkKSB7XHJcbiAgICAgIHNjaGVkdWxlZCA9IHRydWU7XHJcbiAgICAgIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XHJcbiAgICAgICAgY2FsbGJhY2soKTtcclxuICAgICAgICBzY2hlZHVsZWQgPSBmYWxzZTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigobXV0YXRpb25zTGlzdCkgPT4ge1xyXG4gICAgZm9yIChjb25zdCBtdXRhdGlvbiBvZiBtdXRhdGlvbnNMaXN0KSB7XHJcbiAgICAgIGlmIChtdXRhdGlvbi50eXBlID09PSAnY2hpbGRMaXN0Jykge1xyXG4gICAgICAgIG9ic2VydmVyQ2FsbGJhY2soKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBvYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LCB7XHJcbiAgICBjaGlsZExpc3Q6IHRydWUsXHJcbiAgICBzdWJ0cmVlOiB0cnVlLFxyXG4gIH0pO1xyXG59XHJcbiJdLCJuYW1lcyI6W10sInZlcnNpb24iOjMsImZpbGUiOiJpbnN0YWdyYW0uSEFTSF9SRUZfZDIxN2Q3OThiYzllNWRlZi5qcy5tYXAifQ==
